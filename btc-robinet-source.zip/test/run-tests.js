'use strict';
/**
 * Suite de tests BTC ROBINET (Étape 11).
 * Lancement : npm test
 *
 * Les tests démarrent l'application sur une base SQLite temporaire, en mode
 * FaucetPay simulé et captcha "math", puis exercent l'API HTTP réelle.
 * Aucun paiement réel n'est effectué.
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'btc-robinet-test-'));
process.env.DB_PATH = path.join(TMP, 'test.db');
process.env.SESSION_SECRET = 'test'.repeat(12);
process.env.CAPTCHA_MODE = 'math';
process.env.FAUCETPAY_MODE = 'mock';
process.env.PAYOUTS_LIVE = 'false';
process.env.FAUCET_REWARD_SATS = '25';
process.env.FAUCET_COOLDOWN_SECONDS = '30';
process.env.FAUCET_DAILY_LIMIT = '3';
process.env.MIN_WITHDRAW_SATS = '100';
process.env.NODE_ENV = 'test';

const config = require('../src/lib/config');
const { createApp } = require('../src/app');
const { hashPassword, randomCode } = require('../src/lib/security');

let passed = 0;
let failed = 0;
const results = [];

let currentSection = '';

function check(name, condition, info = '') {
  if (condition) {
    passed++;
    results.push({ name, ok: true, info, section: currentSection });
    console.log(`  \x1b[32m✔\x1b[0m ${name}`);
  } else {
    failed++;
    results.push({ name, ok: false, info, section: currentSection });
    console.log(`  \x1b[31m✘\x1b[0m ${name} ${info ? '— ' + info : ''}`);
  }
}

function section(title) {
  currentSection = title;
  console.log(`\n\x1b[1m${title}\x1b[0m`);
}

(async () => {
  const app = createApp({ config });
  await app.init();
  const { db, services } = app;

  const server = http.createServer((req, res) => {
    app.handle(req, res).catch((e) => {
      if (!res.headersSent) res.writeHead(500);
      res.end(JSON.stringify({ error: e.message }));
    });
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;

  /** Client HTTP minimal gérant les cookies. */
  function makeClient() {
    const jar = {};
    return {
      jar,
      async raw(method, url, body, extraHeaders = {}) {
        const headers = { ...extraHeaders };
        const cookie = Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
        if (cookie) headers.Cookie = cookie;
        let payload;
        if (body !== undefined) {
          headers['Content-Type'] = 'application/json';
          payload = JSON.stringify(body);
        }
        const res = await fetch(base + url, { method, headers, body: payload, redirect: 'manual' });
        const setCookie = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
        for (const c of setCookie) {
          const [pair] = c.split(';');
          const i = pair.indexOf('=');
          jar[pair.slice(0, i).trim()] = pair.slice(i + 1).trim();
        }
        const text = await res.text();
        let json = null;
        try { json = JSON.parse(text); } catch { /* HTML */ }
        return { status: res.status, json, text, headers: res.headers };
      },
      get(url) { return this.raw('GET', url); },
      post(url, body = {}, headers = {}) { return this.raw('POST', url, body, headers); },
    };
  }

  /** Convertit une URL absolue renvoyée par l'API en chemin utilisable par le client de test. */
  function pathOf(absoluteUrl) {
    const u = new URL(absoluteUrl);
    return u.pathname + u.search;
  }

  async function solveCaptcha(client) {
    const c = await client.get('/api/auth/captcha');
    const { challenge, signature, question } = c.json;
    const m = /(\d+)\s*([+×])\s*(\d+)/.exec(question);
    const answer = m[2] === '+' ? Number(m[1]) + Number(m[3]) : Number(m[1]) * Number(m[3]);
    return { captcha_challenge: challenge, captcha_signature: signature, captcha_answer: answer };
  }

  /* =================================================================== */
  section('1. Démarrage & configuration');
  /* =================================================================== */
  const pub = await makeClient().get('/api/public/config');
  check('Configuration publique accessible', pub.status === 200 && pub.json.site_name === 'BTC ROBINET');
  check('Aucune clé API exposée au navigateur', !JSON.stringify(pub.json).toLowerCase().includes('api_key'));
  check('Mode paiement annoncé = simulation', pub.json.payments.live === false && pub.json.payments.mode === 'mock');
  const homePage = await makeClient().get('/');
  check('Page d\'accueil servie', homePage.status === 200 && homePage.text.includes('BTC ROBINET'));

  /* =================================================================== */
  section('2. Inscription & sécurité du mot de passe');
  /* =================================================================== */
  const alice = makeClient();
  const cap1 = await solveCaptcha(alice);
  const weak = await alice.post('/api/auth/register', {
    username: 'alice', email: 'alice@example.com', password: 'court', payout_address: 'alice@faucetpay.io', ...cap1,
  });
  check('Mot de passe trop court refusé', weak.status === 400 && /8 caractères/.test(weak.json.error));

  const cap2 = await solveCaptcha(alice);
  const badCap = await alice.post('/api/auth/register', {
    username: 'alice', email: 'alice@example.com', password: 'MotDePasse123', payout_address: 'alice@faucetpay.io',
    captcha_challenge: cap2.captcha_challenge, captcha_signature: cap2.captcha_signature, captcha_answer: 999999,
  });
  check('Captcha incorrect rejeté', badCap.status === 400 && badCap.json.code === 'captcha');

  const cap3 = await solveCaptcha(alice);
  const reg = await alice.post('/api/auth/register', {
    username: 'alice', email: 'alice@example.com', password: 'MotDePasse123', payout_address: 'alice@faucetpay.io', ...cap3,
  });
  check('Inscription réussie', reg.status === 201 && reg.json.user.username === 'alice', JSON.stringify(reg.json));
  check('Mot de passe jamais renvoyé par l\'API', !JSON.stringify(reg.json).includes('MotDePasse123') && !('password_hash' in reg.json.user));
  check('Code de parrainage généré', /^[A-Z0-9]{7}$/.test(reg.json.user.referral_code));
  check('Cookie de session posé (HttpOnly)', Boolean(alice.jar.btr_session));
  const aliceCsrf = reg.json.csrf;

  const dbUser = await db.get('SELECT password_hash FROM users WHERE username = ?', ['alice']);
  check('Mot de passe stocké haché (PBKDF2-SHA256, jamais en clair)', dbUser.password_hash.startsWith('pbkdf2$210000$') && !dbUser.password_hash.includes('MotDePasse123'));

  const cap4 = await solveCaptcha(alice);
  const dup = await alice.post('/api/auth/register', {
    username: 'alice2', email: 'alice@example.com', password: 'MotDePasse123', payout_address: 'x@y.z', ...cap4,
  });
  check('Email en double refusé', dup.status === 409);

  const gmailClient = makeClient(); // client séparé : ne pas écraser la session d'Alice
  const cap5 = await solveCaptcha(gmailClient);
  const gmailDup = await gmailClient.post('/api/auth/register', {
    username: 'alice3', email: 'ali.ce@gmail.com', password: 'MotDePasse123', payout_address: 'x@y.z', ...cap5,
  });
  const gmailCheck = await db.get("SELECT COUNT(*) AS n FROM users WHERE email LIKE '%gmail%'");
  check('Anti multi-compte : variante email contrôlée', typeof gmailDup.status === 'number' && gmailCheck.n === (gmailDup.status === 201 ? 1 : 0));

  /* =================================================================== */
  section('3. Connexion / déconnexion');
  /* =================================================================== */
  const anon = makeClient();
  const badLogin = await anon.post('/api/auth/login', { login: 'alice', password: 'mauvais' });
  check('Mauvais mot de passe refusé (401)', badLogin.status === 401);

  const bob = makeClient(); // futur filleul
  const capB = await solveCaptcha(bob);
  const regBob = await bob.post('/api/auth/register', {
    username: 'bob', email: 'bob@example.com', password: 'MotDePasse123', payout_address: 'bob@faucetpay.io',
    ref: reg.json.user.referral_code, ...capB,
  });
  check('Inscription avec code de parrainage', regBob.status === 201);

  // Bob (filleul d'Alice) réclame une fois : cela doit générer une commission
  const capBob = await solveCaptcha(bob);
  const bobClaim = await bob.post('/api/faucet/claim', { ...capBob, nonce: 'bob-1' }, { 'X-CSRF-Token': regBob.json.csrf });
  check('Filleul peut réclamer normalement', bobClaim.status === 200 && bobClaim.json.amount_sats >= 25, JSON.stringify(bobClaim.json).slice(0, 160));
  check('Commission de parrainage renvoyée au filleul (info)', bobClaim.json.referral === null || typeof bobClaim.json.referral === 'object');

  const capL = await solveCaptcha(anon);
  const login = await anon.post('/api/auth/login', { login: 'alice@example.com', password: 'MotDePasse123' });
  check('Connexion par email réussie', login.status === 200 && login.json.user.username === 'alice');
  const me = await anon.get('/api/me');
  check('Session valide (/api/me)', me.json.authenticated === true && me.json.user.username === 'alice');
  check('Jeton CSRF fourni au client', typeof me.json.csrf === 'string' && me.json.csrf.length > 20);

  const loggedOut = await makeClient();
  const capL2 = await solveCaptcha(loggedOut);
  await loggedOut.post('/api/auth/login', { login: 'alice', password: 'MotDePasse123' });
  await loggedOut.post('/api/auth/logout', {});
  const afterLogout = await loggedOut.get('/api/me');
  check('Déconnexion invalide la session', afterLogout.json.authenticated === false);

  const badSession = makeClient();
  badSession.jar.btr_session = 'faux-token-invalide';
  const forged = await badSession.get('/api/me');
  check('Cookie de session forgé rejeté', forged.json.authenticated === false);

  /* =================================================================== */
  section('4. Protection CSRF');
  /* =================================================================== */
  const noCsrf = await alice.post('/api/faucet/claim', {});
  check('Réclamation sans jeton CSRF bloquée', noCsrf.status === 403 && noCsrf.json.code === 'csrf');

  /* =================================================================== */
  section('5. Robinet BTC — réclamation, minuterie, limites');
  /* =================================================================== */
  const state0 = await alice.get('/api/faucet/state');
  check('État du robinet disponible', state0.status === 200 && state0.json.reward_sats === 25);
  check('Récompense configurable affichée', state0.json.reward_sats === 25 && state0.json.daily_limit === 3);
  const balanceBeforeClaim = state0.json.balance_sats;
  const refBefore = await db.get('SELECT COALESCE(SUM(earned_sats),0) AS e FROM referrals WHERE referrer_id = ?', [reg.json.user.id]);
  check('Solde cohérent : uniquement les commissions de parrainage (aucune réclamation)',
    balanceBeforeClaim === refBefore.e && state0.json.claims_today === 0,
    `solde=${balanceBeforeClaim}, commissions=${refBefore.e}`);

  const cap6 = await solveCaptcha(alice);
  const claim1 = await alice.post('/api/faucet/claim', { ...cap6, nonce: 'n1' }, { 'X-CSRF-Token': aliceCsrf });
  check('Première réclamation créditée', claim1.status === 200 && claim1.json.amount_sats >= 25, JSON.stringify(claim1.json));
  check('Solde mis à jour après réclamation',
    claim1.json.balance_sats === balanceBeforeClaim + claim1.json.amount_sats,
    `attendu=${balanceBeforeClaim + claim1.json.amount_sats}, obtenu=${claim1.json.balance_sats}`);

  const cap7 = await solveCaptcha(alice);
  const claim2 = await alice.post('/api/faucet/claim', { ...cap7, nonce: 'n2' }, { 'X-CSRF-Token': aliceCsrf });
  check('Deuxième réclamation immédiate bloquée (cooldown)', claim2.status === 429 && claim2.json.code === 'cooldown');
  check('Temps d\'attente communiqué', typeof claim2.json.details.retry_after === 'number');

  const replay = await alice.post('/api/faucet/claim', { ...cap6, nonce: 'n1' }, { 'X-CSRF-Token': aliceCsrf });
  check('Rejeu de la même requête bloqué', replay.status === 429 || replay.status === 409);

  const dbClaims = await db.get('SELECT COUNT(*) AS n FROM claims WHERE user_id = ?', [reg.json.user.id]);
  check('Une seule réclamation enregistrée en base', dbClaims.n === 1);

  // Commission de parrainage : Alice est la parraineuse de Bob
  const refRow = await db.get('SELECT * FROM referrals WHERE referrer_id = ?', [reg.json.user.id]);
  check('Lien de parrainage enregistré', Boolean(refRow));
  check('Commission de parrainage créditée', refRow.earned_sats > 0, `earned=${refRow.earned_sats}`);

  // Accélération du temps pour tester cooldown + limite journalière
  await db.run(`UPDATE claims SET created_at = datetime('now','-5 minutes'), claim_slot = claim_slot - 1000 WHERE user_id = ?`, [reg.json.user.id]);
  const cap8 = await solveCaptcha(alice);
  const claim3 = await alice.post('/api/faucet/claim', { ...cap8, nonce: 'n3' }, { 'X-CSRF-Token': aliceCsrf });
  check('Réclamation après expiration du cooldown acceptée', claim3.status === 200 && claim3.json.amount_sats > 0);

  await db.run(`UPDATE claims SET created_at = datetime('now','-5 minutes'), claim_slot = claim_slot - 1000 WHERE user_id = ?`, [reg.json.user.id]);
  const cap9 = await solveCaptcha(alice);
  const claim4 = await alice.post('/api/faucet/claim', { ...cap9, nonce: 'n4' }, { 'X-CSRF-Token': aliceCsrf });
  check('Plafond de réclamations par jour respecté', claim4.status === 200 || (claim4.status === 429 && claim4.json.code === 'daily_limit'));

  await db.run(`UPDATE claims SET created_at = datetime('now','-5 minutes'), claim_slot = claim_slot - 1000 WHERE user_id = ?`, [reg.json.user.id]);
  const cap10 = await solveCaptcha(alice);
  const claim5 = await alice.post('/api/faucet/claim', { ...cap10, nonce: 'n5' }, { 'X-CSRF-Token': aliceCsrf });
  check('4e réclamation du jour refusée (limite = 3)', claim5.status === 429 && claim5.json.code === 'daily_limit', JSON.stringify(claim5.json));

  const hist = await alice.get('/api/claims/history');
  check('Historique des réclamations disponible', hist.status === 200 && hist.json.items.length >= 1);
  check('Total des gains cohérent', hist.json.total_sats >= 25);

  // Concurrence : 8 réclamations simultanées pour le même compte
  const carol = makeClient();
  const capC = await solveCaptcha(carol);
  const regCarol = await carol.post('/api/auth/register', {
    username: 'carol', email: 'carol@example.com', password: 'MotDePasse123', payout_address: 'carol@faucetpay.io', ...capC,
  });
  const carolCsrf = regCarol.json.csrf;
  const caps = await Promise.all(Array.from({ length: 8 }, () => solveCaptcha(carol)));
  const racing = await Promise.all(caps.map((c, i) =>
    carol.post('/api/faucet/claim', { ...c, nonce: `race-${i}` }, { 'X-CSRF-Token': carolCsrf })
  ));
  const successes = racing.filter((r) => r.status === 200).length;
  const dbCarol = await db.get('SELECT COUNT(*) AS n FROM claims WHERE user_id = ?', [regCarol.json.user.id]);
  check('8 réclamations simultanées → 1 seul crédit', successes === 1 && dbCarol.n === 1, `succès=${successes}, en base=${dbCarol.n}`);
  const carolBal = await db.get('SELECT balance_sats FROM users WHERE id = ?', [regCarol.json.user.id]);
  check('Solde cohérent avec les crédits (pas de double crédit)', carolBal.balance_sats === racing.find((r) => r.status === 200).json.amount_sats);

  /* =================================================================== */
  section('6. FaucetPay — adresse, solde, retraits simulés');
  /* =================================================================== */
  const fp = services.faucetpay;
  check('Mode mock : aucun paiement réel possible', fp.live === false && fp.mode === 'mock');
  const balMock = await fp.getBalance('BTC');
  check('Solde faucet (mock) récupérable', balMock.simulated === true && balMock.balance_sats > 0);

  // Injection d'un faux échec fournisseur pour tester le remboursement
  const goodSend = fp.sendPayout.bind(fp);

  const badAddr = await alice.post('/api/payouts/verify-address', { address: 'x' }, { 'X-CSRF-Token': aliceCsrf });
  check('Adresse invalide refusée', badAddr.status === 422 || badAddr.json.ok === false);

  const verifyOk = await alice.post('/api/payouts/verify-address', { address: 'alice@faucetpay.io' }, { 'X-CSRF-Token': aliceCsrf });
  check('Adresse FaucetPay acceptée (mock)', verifyOk.json.ok === true && Boolean(verifyOk.json.hash));

  const belowMin = await alice.post('/api/payouts/withdraw', { amount_sats: 1 }, { 'X-CSRF-Token': aliceCsrf });
  check('Retrait sous le minimum refusé', belowMin.status === 422 && belowMin.json.code === 'below_min');

  await db.run('UPDATE users SET balance_sats = balance_sats + 2000 WHERE id = ?', [reg.json.user.id]);
  const aliceBal = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [reg.json.user.id])).balance_sats;
  const tooMuch = await alice.post('/api/payouts/withdraw', { amount_sats: aliceBal + 5000 }, { 'X-CSRF-Token': aliceCsrf });
  check('Retrait supérieur au solde refusé', tooMuch.status === 422 && tooMuch.json.code === 'insufficient_balance');

  const okWithdraw = await alice.post('/api/payouts/withdraw', { amount_sats: 100, idempotency_key: 'idem-alice-1' }, { 'X-CSRF-Token': aliceCsrf });
  check('Retrait simulé accepté', okWithdraw.status === 200 && okWithdraw.json.payout.status === 'simulated', JSON.stringify(okWithdraw.json));
  check('Solde débité après retrait', okWithdraw.json.new_balance_sats === aliceBal - 100);
  const ledgerDebit = await db.get(`SELECT * FROM ledger WHERE user_id = ? AND type = 'debit_payout'`, [reg.json.user.id]);
  check('Mouvement inscrit au grand livre', Boolean(ledgerDebit) && ledgerDebit.amount_sats === -100);

  const replayWithdraw = await alice.post('/api/payouts/withdraw', { amount_sats: 100, idempotency_key: 'idem-alice-1' }, { 'X-CSRF-Token': aliceCsrf });
  const balAfterReplay = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [reg.json.user.id])).balance_sats;
  check('Double paiement impossible (clé d\'idempotence)', replayWithdraw.status !== 200 || replayWithdraw.json.duplicate === true || balAfterReplay === okWithdraw.json.new_balance_sats);
  const payoutCount = await db.get('SELECT COUNT(*) AS n FROM payouts WHERE user_id = ?', [reg.json.user.id]);
  check('Un seul paiement enregistré malgré le rejeu', payoutCount.n === 1, `count=${payoutCount.n}`);

  // Échec fournisseur => remboursement
  await db.run(`UPDATE users SET balance_sats = balance_sats + 500 WHERE id = ?`, [regCarol.json.user.id]);
  fp.sendPayout = async () => {
    const err = new Error('Destinataire non payable');
    err.name = 'FaucetPayError';
    err.status = 456;
    throw err;
  };
  const carolBefore = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [regCarol.json.user.id])).balance_sats;
  const failedW = await carol.post('/api/payouts/withdraw', { amount_sats: 200 }, { 'X-CSRF-Token': carolCsrf });
  const carolAfter = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [regCarol.json.user.id])).balance_sats;
  check('Erreur FaucetPay 456 => paiement en échec', failedW.status === 502 && /refusé|erreur/i.test(failedW.json.error), JSON.stringify(failedW.json));
  check('Remboursement automatique du solde', carolAfter === carolBefore, `avant=${carolBefore}, après=${carolAfter}`);
  const refundRow = await db.get(`SELECT * FROM ledger WHERE user_id = ? AND type = 'refund'`, [regCarol.json.user.id]);
  check('Remboursement tracé au grand livre', Boolean(refundRow) && refundRow.amount_sats === 200);

  // Solde faucet insuffisant côté fournisseur => aucun retrait
  fp.sendPayout = goodSend;
  const fakeFaucet = services.faucetpay;
  const originalGetBalance = fakeFaucet.getBalance.bind(fakeFaucet);
  fakeFaucet.getBalance = async () => ({ balance_sats: 10, currency: 'BTC', simulated: false });
  await db.run(`UPDATE users SET balance_sats = balance_sats + 1000 WHERE id = ?`, [regCarol.json.user.id]);
  await db.run(`UPDATE payouts SET created_at = datetime('now','-1 hour') WHERE user_id = ?`, [regCarol.json.user.id]);
  const carolBefore2 = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [regCarol.json.user.id])).balance_sats;
  const noFunds = await carol.post('/api/payouts/withdraw', { amount_sats: 300 }, { 'X-CSRF-Token': carolCsrf });
  const carolAfter2 = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [regCarol.json.user.id])).balance_sats;
  check('Aucun paiement si le faucet est à découvert', noFunds.status === 503 && noFunds.json.code === 'provider_insufficient_funds');
  check('Solde interne intact en cas de refus de financement', carolBefore2 === carolAfter2);
  fakeFaucet.getBalance = originalGetBalance;

  /* =================================================================== */
  section('7. Parrainage');
  /* =================================================================== */
  const refAlice = await alice.get('/api/referral');
  check('Lien de parrainage personnel', refAlice.json.link.includes('ref=' + reg.json.user.referral_code));
  check('Filleul listé', refAlice.json.referred.some((r) => r.username === 'bob'));
  check('Commission cumulée > 0', refAlice.json.total_earned_sats > 0);
  check('Historique des commissions disponible', refAlice.json.commissions.length >= 1);
  check('Pourcentage de commission configurable', refAlice.json.percent === 20);

  /* =================================================================== */
  section('8. Shortlinks (Étape 4)');
  /* =================================================================== */
  const { shortlinks, ptc, offerwalls } = services;
  const adminClient = makeClient();
  await db.run(
    `INSERT INTO users (username, email, password_hash, payout_address, referral_code, role, status)
     VALUES ('root2', 'root2@example.com', ?, 'root2@faucetpay.io', 'ROOT234', 'admin', 'active')`,
    [await hashPassword('AdminPassword123')]
  );
  await adminClient.post('/api/auth/login', { login: 'root2', password: 'AdminPassword123' });
  const adminCsrf2 = (await adminClient.get('/api/me')).json.csrf;

  const disabled = await adminClient.get('/api/admin/shortlinks');
  check('Admin : listes shortlinks accessibles', disabled.status === 200 && Array.isArray(disabled.json.partners));

  const noModule = await alice.post('/api/shortlinks/1/start', {}, { 'X-CSRF-Token': aliceCsrf });
  check('Module désactivé => clic refusé', noModule.status === 503 && noModule.json.code === 'module_off');

  const partnerRes = await adminClient.post('/api/admin/partners', {
    name: 'Reseau Demo', type: 'shortlink', network_url: 'https://demo-partenaire.test/go',
    callback_secret: 'secret-partenaire-123', cpm_usd: 3.5, revenue_share: 60,
  }, { 'X-CSRF-Token': adminCsrf2 });
  check('Création d\'un partenaire shortlink', partnerRes.status === 201 && partnerRes.json.id > 0);

  const linkRes = await adminClient.post('/api/admin/shortlinks', {
    partner_id: partnerRes.json.id, title: 'Lien de démonstration', target_url: 'https://exemple.test/offre',
    reward_sats: 15, daily_limit: 3,
  }, { 'X-CSRF-Token': adminCsrf2 });
  check('Création d\'un lien shortlink', linkRes.status === 201);

  // second partenaire SANS secret => mode démonstration (validation interne signée)
  const demoPartner = await adminClient.post('/api/admin/partners', {
    name: 'Demo interne', type: 'shortlink', network_url: '', cpm_usd: 0, revenue_share: 60,
  }, { 'X-CSRF-Token': adminCsrf2 });
  const demoLink = await adminClient.post('/api/admin/shortlinks', {
    partner_id: demoPartner.json.id, title: 'Lien interne (démo)', reward_sats: 10, daily_limit: 5,
  }, { 'X-CSRF-Token': adminCsrf2 });

  const slModule = await adminClient.post('/api/admin/modules/shortlinks/on', {}, { 'X-CSRF-Token': adminCsrf2 });
  check('Activation du module shortlinks', slModule.json.modules.shortlinks === true);

  const list = await alice.get('/api/shortlinks');
  check('Liste des liens pour le membre', list.status === 200 && list.json.items.length === 2 && list.json.enabled === true);

  const startReal = await alice.post(`/api/shortlinks/${linkRes.json.id}/start`, {}, { 'X-CSRF-Token': aliceCsrf });
  check('Démarrage : redirection vers le partenaire', startReal.status === 200 && startReal.json.redirect_url.startsWith('https://demo-partenaire.test/go?'));
  check('URL de retour signée (HMAC)', /token=.+&sig=/.test(startReal.json.return_url));

  const badSig = await alice.get(`/shortlink/return?token=${encodeURIComponent(startReal.json.session_token)}&sig=fausse`);
  check('Retour avec signature invalide => refusé', badSig.status === 302 && /erreur=/.test(badSig.headers.get('location') || ''));

  const early = await alice.get(pathOf(startReal.json.return_url));
  check('Retour trop rapide (délai minimal) => refusé', early.status === 302 && /trop%20courte|erreur/.test(early.headers.get('location') || ''));

  // Délai minimal respecté : on antidate la session de 30 secondes
  await db.run(`UPDATE shortlink_sessions SET created_at = datetime('now','-30 seconds') WHERE id = ?`, [startReal.json.session_token]);
  const balBeforeSl = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [reg.json.user.id])).balance_sats;
  const okReturn = await alice.get(pathOf(startReal.json.return_url));
  const balAfterSl = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [reg.json.user.id])).balance_sats;
  check('Retour validé => redirection avec gain', okReturn.status === 302 && /valide=1/.test(okReturn.headers.get('location') || ''));
  check('Récompense shortlink créditée (15 sats)', balAfterSl === balBeforeSl + 15, `avant=${balBeforeSl}, après=${balAfterSl}`);

  const replaySl = await alice.get(pathOf(startReal.json.return_url));
  const balReplay = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [reg.json.user.id])).balance_sats;
  check('Rejeu du même retour impossible (session déjà validée)', replaySl.status === 302 && balReplay === balAfterSl);

  const revenueRow = await db.get(`SELECT COALESCE(SUM(amount_usd),0) AS usd FROM finance_entries WHERE category='shortlinks'`);
  check('Revenu partenaire enregistré (cpm/1000)', revenueRow.usd > 0, `usd=${revenueRow.usd}`);

  const otherUserReturn = await makeClient().get(pathOf(startReal.json.return_url));
  check('Retour sans session => redirection connexion', otherUserReturn.status === 302 && /login/.test(otherUserReturn.headers.get('location') || ''));

  const demoStart = await alice.post(`/api/shortlinks/${demoLink.json.id}/start`, {}, { 'X-CSRF-Token': aliceCsrf });
  check('Lien en mode démonstration (sans secret partenaire)', demoStart.json.demo === true);

  /* =================================================================== */
  section('9. PTC (Étape 5)');
  /* =================================================================== */
  const ptcOff = await alice.get('/api/ptc');
  check('PTC désactivé par défaut', ptcOff.json.enabled === false);

  const adRes = await adminClient.post('/api/admin/ptc', {
    advertiser: 'Annonceur Démo', title: 'Découvrir un service', target_url: 'https://annonceur.test/pub',
    duration_sec: 10, reward_sats: 8, budget_sats: 100, daily_limit: 2,
  }, { 'X-CSRF-Token': adminCsrf2 });
  check('Création d\'une campagne PTC', adRes.status === 201 && adRes.json.id > 0);

  const badAd = await adminClient.post('/api/admin/ptc', {
    advertiser: 'X', title: 'Y', target_url: 'javascript:alert(1)', duration_sec: 10, reward_sats: 5,
  }, { 'X-CSRF-Token': adminCsrf2 });
  check('URL de campagne invalide rejetée', badAd.status === 400);

  await adminClient.post('/api/admin/modules/ptc/on', {}, { 'X-CSRF-Token': adminCsrf2 });
  const ptcList = await alice.get('/api/ptc');
  check('Campagne visible par le membre', ptcList.json.enabled === true && ptcList.json.items.length === 1);

  const ptcStart = await alice.post(`/api/ptc/${adRes.json.id}/start`, {}, { 'X-CSRF-Token': aliceCsrf });
  check('Ouverture d\'une vue PTC (jeton unique)', ptcStart.status === 200 && ptcStart.json.token && ptcStart.json.duration_sec === 10);

  const ptcEarly = await alice.post('/api/ptc/complete', { token: ptcStart.json.token, visible_seconds: 2 }, { 'X-CSRF-Token': aliceCsrf });
  check('Validation avant la durée minimale refusée', ptcEarly.status === 429 && ptcEarly.json.code === 'too_fast');

  await db.run(`UPDATE ptc_views SET started_at = datetime('now','-15 seconds') WHERE token = ?`, [ptcStart.json.token]);
  const balBeforePtc = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [reg.json.user.id])).balance_sats;
  const ptcOk = await alice.post('/api/ptc/complete', { token: ptcStart.json.token, visible_seconds: 12 }, { 'X-CSRF-Token': aliceCsrf });
  const balAfterPtc = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [reg.json.user.id])).balance_sats;
  check('Vue PTC validée après la durée', ptcOk.status === 200 && ptcOk.json.amount_sats === 8);
  check('Récompense PTC créditée', balAfterPtc === balBeforePtc + 8, `avant=${balBeforePtc}, après=${balAfterPtc}`);

  const ptcReplay = await alice.post('/api/ptc/complete', { token: ptcStart.json.token }, { 'X-CSRF-Token': aliceCsrf });
  check('Double validation PTC impossible', ptcReplay.status === 409);

  const adAfter = await db.get('SELECT spent_sats, budget_sats FROM ptc_ads WHERE id = ?', [adRes.json.id]);
  check('Budget annonceur débité', adAfter.spent_sats === 8, `spent=${adAfter.spent_sats}/${adAfter.budget_sats}`);

  await db.run(`UPDATE claims SET created_at = datetime('now','-1 minute') WHERE user_id = ? AND module='ptc'`, [reg.json.user.id]);
  const ptcStart2 = await alice.post(`/api/ptc/${adRes.json.id}/start`, {}, { 'X-CSRF-Token': aliceCsrf });
  await db.run(`UPDATE ptc_views SET started_at = datetime('now','-15 seconds') WHERE token = ?`, [ptcStart2.json.token]);
  const ptcNoVisible = await alice.post('/api/ptc/complete', { token: ptcStart2.json.token, visible_seconds: 1 }, { 'X-CSRF-Token': aliceCsrf });
  check('Onglet non visible pendant la durée => refusé', ptcNoVisible.status === 429 && ptcNoVisible.json.code === 'not_visible');

  /* =================================================================== */
  section('10. Offerwalls (Étape 6)');
  /* =================================================================== */
  const owPartner = await adminClient.post('/api/admin/partners', {
    name: 'Offerwall Demo', type: 'offerwall', network_url: 'https://offreur.test/wall',
    callback_secret: 'ow-secret-abc', revenue_share: 70,
  }, { 'X-CSRF-Token': adminCsrf2 });
  check('Création d\'un partenaire offerwall', owPartner.status === 201);

  const owDisabled = await offerwalls.handleCallback(owPartner.json.id, { transaction_id: 'tx-off', amount: 0.01, status: '1', user_id: 'x', signature: 'y' })
    .then(() => 'accepté').catch((e) => e.code);
  check('Callbacks refusés quand le module est désactivé', owDisabled === 'module_off');

  await adminClient.post('/api/admin/modules/offerwalls/on', {}, { 'X-CSRF-Token': adminCsrf2 });
  const owList = await alice.get('/api/offerwalls');
  check('Partenaire offerwall listé pour le membre', owList.json.enabled === true && owList.json.items.length === 1);
  const userToken = owList.json.token;

  const crypto2 = require('node:crypto');
  const sign = (token, tx, amount) => crypto2.createHmac('sha256', 'ow-secret-abc').update(`${token}${tx}${amount}`).digest('hex');

  const badSignature = await alice.get(`/api/offerwalls/${owPartner.json.id}/callback?user_id=${userToken}&transaction_id=tx-bad&amount=0.01&status=1&signature=deadbeef`);
  check('Callback avec signature invalide => 401', badSignature.status === 401);

  const balBeforeOw = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [reg.json.user.id])).balance_sats;
  const goodCb = await alice.get(
    `/api/offerwalls/${owPartner.json.id}/callback?user_id=${userToken}&transaction_id=tx-good-1&amount=0.01&status=1&offer_name=Installation&signature=${sign(userToken, 'tx-good-1', 0.01)}`
  );
  const balAfterOw = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [reg.json.user.id])).balance_sats;
  check('Callback signé => conversion créditée', goodCb.status === 200 && goodCb.json.credited_sats > 0, JSON.stringify(goodCb.json));
  check('Solde augmenté du montant de la conversion', balAfterOw === balBeforeOw + goodCb.json.credited_sats);

  const replayCb = await alice.get(
    `/api/offerwalls/${owPartner.json.id}/callback?user_id=${userToken}&transaction_id=tx-good-1&amount=0.01&status=1&signature=${sign(userToken, 'tx-good-1', 0.01)}`
  );
  const balReplayCb = (await db.get('SELECT balance_sats FROM users WHERE id = ?', [reg.json.user.id])).balance_sats;
  check('Rejeu du callback ignoré (idempotence transaction_id)', replayCb.json.duplicate === true && balReplayCb === balAfterOw);

  const notCompleted = await alice.get(
    `/api/offerwalls/${owPartner.json.id}/callback?user_id=${userToken}&transaction_id=tx-pending&amount=0.01&status=0&signature=${sign(userToken, 'tx-pending', 0.01)}`
  );
  check('Mission non complétée => aucun crédit', notCompleted.json.credited_sats === 0);

  const owStats = await adminClient.get('/api/admin/offerwalls');
  check('Admin : callbacks journalisés', owStats.json.callbacks.length >= 3);

  /* =================================================================== */
  section('11. Administration (suite : modules)');
  /* =================================================================== */
  const adminSl = await adminClient.get('/api/admin/shortlinks');
  check('Admin : statistiques shortlinks', adminSl.json.stats.n >= 1 && adminSl.json.stats.revenue_usd > 0);
  const adminPtc = await adminClient.get('/api/admin/ptc');
  check('Admin : campagnes PTC avec budget', adminPtc.json.ads.length === 1 && adminPtc.json.ads[0].spent_sats === 8);
  const pauseKind = await adminClient.post(`/api/admin/shortlinks/link/${linkRes.json.id}/paused`, {}, { 'X-CSRF-Token': adminCsrf2 });
  check('Suspension d\'un lien par l\'admin', pauseKind.status === 200);
  const afterPause = await alice.post(`/api/shortlinks/${linkRes.json.id}/start`, {}, { 'X-CSRF-Token': aliceCsrf });
  check('Lien suspendu inaccessible', afterPause.status === 404 || afterPause.status === 503);
  await adminClient.post(`/api/admin/shortlinks/link/${linkRes.json.id}/active`, {}, { 'X-CSRF-Token': adminCsrf2 });

  /* =================================================================== */
  section('12. Administration');
  /* =================================================================== */
  const notAdmin = await alice.get('/api/admin/overview');
  check('Accès admin refusé aux membres', notAdmin.status === 403);

  const adminPage = await alice.get('/admin');
  check('Page /admin protégée (redirection)', adminPage.status === 302);

  await db.run(
    `INSERT INTO users (username, email, password_hash, payout_address, referral_code, role, status)
     VALUES ('root', 'root@example.com', ?, 'root@faucetpay.io', 'ROOT123', 'admin', 'active')`,
    [await hashPassword('AdminPassword123')]
  );
  const admin = makeClient();
  await admin.post('/api/auth/login', { login: 'root', password: 'AdminPassword123' });
  const adminMe = await admin.get('/api/me');
  const adminCsrf = adminMe.json.csrf;
  check('Connexion administrateur', adminMe.json.user.role === 'admin');
  const adminPageOk = await admin.get('/admin');
  check('Page /admin accessible à l\'admin', adminPageOk.status === 200);

  const overview = await admin.get('/api/admin/overview');
  check('Tableau de bord admin', overview.status === 200 && overview.json.counts.users >= 3);
  check('Solde FaucetPay visible en admin', 'mode' in overview.json.provider);

  const setRes = await admin.post('/api/admin/settings', {
    faucet_reward_sats: 40, faucet_cooldown_seconds: 60, faucet_daily_limit: 5,
    min_withdraw_sats: 200, referral_percent: 25,
  }, { 'X-CSRF-Token': adminCsrf });
  check('Récompense modifiable en admin', setRes.json.settings.faucet_reward_sats === 40);
  check('Minuterie modifiable en admin', setRes.json.settings.faucet_cooldown_seconds === 60);
  const newState = await carol.get('/api/faucet/state');
  check('Nouvelle récompense appliquée immédiatement', newState.json.reward_sats === 40, JSON.stringify(newState.json).slice(0, 120));

  const clamp = await admin.post('/api/admin/settings', { faucet_reward_sats: 999999, referral_percent: 99 }, { 'X-CSRF-Token': adminCsrf });
  check('Valeurs aberrantes bornées', clamp.json.settings.faucet_reward_sats === 100000 && clamp.json.settings.referral_percent === 50);
  // Remise de valeurs réalistes pour la suite
  await admin.post('/api/admin/settings', { faucet_reward_sats: 25, referral_percent: 20 }, { 'X-CSRF-Token': adminCsrf });

  const sus = await admin.post(`/api/admin/users/${regCarol.json.user.id}/suspend`, {}, { 'X-CSRF-Token': adminCsrf });
  check('Suspension d\'un membre', sus.json.user.status === 'suspended');
  const susClaim = await carol.get('/api/faucet/state');
  check('Membre suspendu : session invalidée / réclamation bloquée',
    susClaim.status === 401 || susClaim.json.enabled === false, `status=${susClaim.status}`);
  await admin.post(`/api/admin/users/${regCarol.json.user.id}/activate`, {}, { 'X-CSRF-Token': adminCsrf });

  await admin.post(`/api/admin/users/${regBob.json.user.id}/adjust-balance`, { delta_sats: 1000, reason: 'Test admin' }, { 'X-CSRF-Token': adminCsrf });
  const bobBal = await db.get('SELECT balance_sats FROM users WHERE id = ?', [regBob.json.user.id]);
  check('Ajustement de solde manuel tracé', bobBal.balance_sats >= 1000);

  const mods = await admin.post('/api/admin/modules/faucet/off', {}, { 'X-CSRF-Token': adminCsrf });
  check('Module robinet suspensible', mods.json.modules.faucet === false);
  const offState = await alice.get('/api/faucet/state');
  check('Robinet désactivé côté membre', offState.json.enabled === false);
  await admin.post('/api/admin/modules/faucet/on', {}, { 'X-CSRF-Token': adminCsrf });

  const adminPayouts = await admin.get('/api/admin/payouts');
  check('Paiements FaucetPay visibles en admin', adminPayouts.json.items.length >= 1);
  const usersList = await admin.get('/api/admin/users?q=ali');
  check('Recherche de membres', usersList.json.items.some((u) => u.username === 'alice'));

  /* =================================================================== */
  section('13. Rentabilité');
  /* =================================================================== */
  const fin = await admin.get('/api/admin/finance');
  check('Rapport financier disponible', fin.status === 200 && fin.json.overview.day);
  check('Résultat par jour/semaine/mois', Boolean(fin.json.overview.week && fin.json.overview.month));
  check('Coûts = récompenses + frais + hébergement',
    fin.json.overview.day.costs.total_usd >= fin.json.overview.day.costs.member_rewards_usd);
  const net = fin.json.overview.day.net_usd;
  check('Bénéfice net calculé (peut être négatif en MVP)', typeof net === 'number', `net=${net}`);
  const entry = await admin.post('/api/admin/finance/entry', { kind: 'revenue', category: 'shortlinks', amount_usd: 5.5, note: 'test' }, { 'X-CSRF-Token': adminCsrf });
  check('Saisie manuelle d\'un revenu', entry.status === 200);
  const sim = await admin.post('/api/admin/finance/simulate', {
    users: 100, claims_per_user: 10, reward_sats: 25, revenue_per_1000_points: 0.002, hosting_usd_month: 0,
  });
  check('Simulateur de rentabilité', sim.json.daily_claims === 1000 && typeof sim.json.profitable === 'boolean', JSON.stringify(sim.json));

  /* =================================================================== */
  section('14. Sécurité complémentaire');
  /* =================================================================== */
  const brute = makeClient();
  let blocked = false;
  for (let i = 0; i < 12; i++) {
    const r = await brute.post('/api/auth/login', { login: 'alice', password: 'faux' + i });
    if (r.status === 429) { blocked = true; break; }
  }
  check('Limitation de débit sur la connexion', blocked);

  const suspPath = await makeClient().get('/api/../.env');
  check('Traversée de répertoire bloquée', suspPath.status === 404 || !suspPath.text.includes('SESSION_SECRET'));

  const protectedRoutes = await makeClient().get('/api/payouts');
  check('API retrait protégée sans session', protectedRoutes.status === 401);

  const auditRows = await admin.get('/api/admin/audit');
  check('Journal d\'audit alimenté', auditRows.json.items.length > 0);

  /* =================================================================== */
  /*  Résumé                                                             */
  /* =================================================================== */
  server.close();
  await db.close();

  console.log(`\n${'='.repeat(60)}`);
  console.log(`RÉSULTAT : ${passed} test(s) réussi(s), ${failed} échec(s)`);
  console.log(`${'='.repeat(60)}`);

  fs.writeFileSync(
    path.join(__dirname, '..', 'docs', 'TEST-REPORT.json'),
    JSON.stringify({
      generated_at: new Date().toISOString(),
      node: process.version,
      environment: 'SQLite locale, FaucetPay mode mock, captcha math, aucun paiement réel',
      summary: { passed, failed, total: passed + failed },
      results,
    }, null, 2)
  );
  fs.rmSync(TMP, { recursive: true, force: true });
  process.exit(failed === 0 ? 0 : 1);
})().catch((e) => {
  console.error('\nERREUR FATALE DANS LES TESTS:', e);
  process.exit(1);
});
