/**
 * Simulateur Cloudflare D1 basé sur SQLite local.
 * Permet de tester le Worker (et l'adaptateur D1) sans compte Cloudflare.
 * Implémente l'API D1 utilisée par l'adaptateur :
 *   prepare(sql).bind(...).all() / .first() / .run()
 *   batch([...])  — atomique
 *   exec(sql)
 */
import Database from 'better-sqlite3';

class D1Statement {
  constructor(db, sql, params = []) {
    this.db = db;
    this.sql = sql;
    this.params = params;
  }
  bind(...params) {
    return new D1Statement(this.db, this.sql, params);
  }
  async all() {
    const rows = this.db.prepare(this.sql).all(...this.params);
    return { results: rows, success: true, meta: {} };
  }
  async first(column) {
    const row = this.db.prepare(this.sql).get(...this.params) ?? null;
    if (row && column) return row[column];
    return row;
  }
  async run() {
    const info = this.db.prepare(this.sql).run(...this.params);
    return {
      success: true,
      meta: { changes: info.changes, last_row_id: Number(info.lastInsertRowid), duration: 0 },
      results: [],
    };
  }
}

export class D1Simulator {
  constructor(file = ':memory:') {
    this.db = new Database(file);
    this.db.pragma('journal_mode = WAL');
    this.db.pragma('foreign_keys = ON');
  }
  prepare(sql) {
    return new D1Statement(this.db, sql);
  }
  async batch(statements) {
    const runAll = this.db.transaction((stmts) => {
      return stmts.map((s) => {
        const info = this.db.prepare(s.sql).run(...s.params);
        return { success: true, meta: { changes: info.changes, last_row_id: Number(info.lastInsertRowid) } };
      });
    });
    return runAll(statements);
  }
  async exec(sql) {
    this.db.exec(sql);
    return { count: 1, duration: 0 };
  }
  close() {
    this.db.close();
  }
}
