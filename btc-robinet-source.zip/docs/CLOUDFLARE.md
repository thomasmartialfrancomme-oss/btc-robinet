# Cloudflare Workers + D1 — état du portage

**Statut : réalisé et testé.** 13 contrôles automatisés passent sur ce chemin
(`npm run test:worker`). La procédure de déploiement complète est dans
`MISE-EN-LIGNE.md`, section « Option B ».

| Élément | État | Fichier |
|---|---|---|
| Entrée Worker (fetch, assets, routage) | ✅ | `worker/index.mjs` |
| Schéma embarqué | ✅ généré | `worker/schema.generated.js` (`npm run build:worker`) |
| Adaptateur base D1 | ✅ | `src/lib/d1.js` |
| Shim HTTP Request/Response | ✅ | `src/lib/httpshim.js` |
| Hachage mot de passe portable | ✅ PBKDF2-SHA256 | `src/lib/security.js` |
| Config depuis l'environnement Worker | ✅ | `src/lib/config.js` (`buildConfig`) |
| Transactions → écritures conditionnelles | ✅ | `src/services/faucet.js`, `payout.js`, `shortlink.js`, `ptc.js`, `offerwall.js` |
| Configuration de déploiement | ✅ | `wrangler.toml` |
| Simulateur D1 (tests hors Cloudflare) | ✅ | `test/d1-simulator.mjs` |

## Règles à respecter pour toute évolution

1. **Jamais de lecture dans `db.atomic()`** : la boîte ne contient que `run()`.
   La cohérence se fait par `UPDATE … WHERE <invariant>` ou
   `INSERT … SELECT … WHERE NOT EXISTS (…)` puis contrôle de `changes`.
2. **Unicité par index SQL**, pas par vérification applicative
   (`idempotency_key`, `transaction_id`, `(user_id, module, claim_slot)`).
3. **Aucun `lastInsertRowid` en dépendance forte** : relire par clé unique.
4. Toute nouvelle route doit passer par `requireCsrf` + `requireUser`/`requireAdmin`.

## Limites D1 à connaître

- `batch()` = écritures uniquement, atomique ; pas de transaction interactive.
- 100 000 écritures/jour sur l'offre gratuite : largement suffisant pour un robinet,
  à surveiller si vous ajoutez des écritures par requête (ex. compteurs).
- Les timeouts de requête sont courts : les appels externes (FaucetPay) ont un
  `AbortSignal` de 15 s côté service.
