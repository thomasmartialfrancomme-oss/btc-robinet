# Accès au site — liens actifs

## 1. Lien public (partageable, temporaire)

**https://operations-course-chen-extra.trycloudflare.com**

- Accessible depuis n'importe quel appareil (téléphone, ordinateur), en HTTPS.
- Généré par un tunnel Cloudflare « quick tunnel » pointant sur le serveur du workspace.
- ⚠️ **Temporaire** : ce lien meurt dès que l'environnement de travail est arrêté ou
  après un certain temps, et **aucune garantie de disponibilité** n'est offerte par
  Cloudflare sur ce mode. Ce n'est **pas** un hébergement définitif.
- Régénérer un lien à tout moment :

```bash
/tmp/cloudflared tunnel --url http://127.0.0.1:3000 --no-autoupdate
# → la nouvelle URL s'affiche dans les lignes "Your quick Tunnel has been created"
```

## 2. Aperçu intégré (live preview)

Le serveur tourne sur le port **3000** du workspace : un aperçu « BTC ROBINET » apparaît
directement dans l'interface Arena (le lien d'aperçu est protégé par un jeton propre à
votre session, c'est pourquoi il n'est pas recopié ici).

## 3. Comptes de démonstration déjà créés

| Compte | Identifiant | Mot de passe | Rôle |
|---|---|---|---|
| Administrateur | `demo_admin` | `DemoAdmin2026!` | accès `/admin` complet |
| Membre de test | `membre#####` | `MotDePasse123` | créé pendant les vérifications |

> ⚠️ **Avant toute ouverture publique réelle** : supprimez ou changez ces comptes de
> démonstration (ils sont publics dans ce document) :
> ```bash
> node scripts/create-admin.js monpseudo moi@monmail.com "MonVraiMotDePasse!2026" moi@faucetpay.io
> # puis supprimer demo_admin (SQLite)
> node -e "const db=require('better-sqlite3')('data/btc-robinet.db');db.prepare('DELETE FROM users WHERE username=?').run('demo_admin');console.log('supprimé')"
> ```

## 4. Parcours à tester en ligne (2 minutes)

1. <https://operations-course-chen-extra.trycloudflare.com/register> → créez un compte
   (captcha = petit calcul, ex. « 13 × 5 = ? » → 65).
2. `/faucet` → **CLAIM BTC** → 25 sats crédités, minuterie de 3 min qui démarre.
3. Rechargez et recliquez : le serveur répond « Patientez encore N secondes » (normal).
4. `/admin` avec `demo_admin` → changez la récompense, la minuterie, le minimum de
   retrait ; vérifiez le tableau **Rentabilité** et le simulateur.
5. `/withdraw` → demande de retrait → statut **« simulé »** (aucun bitcoin réel).

## 5. Ce qui reste faux / provisoire tant que vous n'avez pas vos comptes

| Élément | État | Ce qu'il faut |
|---|---|---|
| Paiements BTC réels | ❌ simulés | votre clé API FaucetPay + `PAYOUTS_LIVE=true` (avec votre accord) |
| Domaine définitif | ❌ lien trycloudflare | un nom de domaine (~10 €/an) ou un sous-domaine gratuit |
| Hébergement permanent | ❌ sandbox | serveur Node avec disque persistant, ou Cloudflare Workers + D1 |
| Shortlinks / PTC / Offerwalls | 🟡 désactivés | comptes partenaires approuvés |
| Mentions légales / RGPD | 🟡 brouillon | vos informations d'éditeur |

## 6. Pour un vrai « en ligne » permanent

Suivez `docs/MISE-EN-LIGNE.md` :

- **Option A** : hébergeur Node (Render/Railway/Fly/Oracle gratuit) + disque persistant
  pour `data/btc-robinet.db` → 30 à 60 minutes de mise en place.
- **Option B** : Cloudflare Workers + D1 (gratuit, cible de votre cahier des charges) →
  nécessite le portage de l'adaptateur base décrit section B.2 (≈ 1 journée).

Dites-moi laquelle vous voulez et je réalise la configuration complète (fichiers
`wrangler.toml`, adaptateur D1, migrations, script de déploiement) dès que vous avez
créé le compte correspondant.
