# Installation sous Windows — BTC ROBINET

Objectif : faire tourner le site sur votre PC en local, puis (plus tard) sur un serveur.
Tout est gratuit. Comptez 10 minutes.

---

## 1. Installer Node.js

1. Téléchargez la version **LTS (20.x ou 22.x)** : <https://nodejs.org/fr/download>
2. Lancez l'installateur `.msi`, cliquez *Suivant* partout (laissez les options par défaut).
3. Vérifiez : ouvrez **Invite de commandes** (touche Windows → tapez `cmd` → Entrée) :

```bat
node -v
npm -v
```

Vous devez voir par exemple `v20.20.2` et `10.8.2`. Si « node n'est pas reconnu »,
redémarrez votre PC (le PATH se met à jour à la connexion).

## 2. Récupérer les fichiers du projet

Placez le dossier `btc-robinet` dans `C:\btc-robinet` (évitez Bureau/OneDrive :
les chemins avec espaces ou accents provoquent des erreurs).

```bat
cd C:\btc-robinet
dir
```

Vous devez voir `package.json`, `src`, `public`, `db`, `docs`.

## 3. Installer les dépendances

```bat
cd C:\btc-robinet
npm install
```

Une seule dépendance (`better-sqlite3`) est nécessaire : elle est précompilée pour
Windows + Node LTS, aucun compilateur n'est requis.

> Si vous voyez une erreur `MSB3428` / `node-gyp` : vous n'êtes pas sur une version LTS
> de Node. Désinstallez Node, réinstallez la LTS, supprimez `node_modules`, refaites
> `npm install`.

## 4. Premier démarrage

```bat
npm start
```

Sortie attendue :

```
[info] Fichier .env créé depuis .env.example (secret de session généré).
[info] Relancez le serveur pour appliquer cette configuration.
```

C'est normal : le `.env` vient d'être créé. Faites **Ctrl + C**, puis :

```bat
npm start
```

Vous devez voir :

```
⟠  BTC ROBINET — serveur démarré
   Local      : http://localhost:3000
   FaucetPay  : mode=mock api=v1 paiements_réels=NON (verrou fermé)
```

Ouvrez votre navigateur sur <http://localhost:3000>.

## 5. Créer votre compte administrateur

Dans un **second** invite de commandes (laissez le serveur tourner) :

```bat
cd C:\btc-robinet
node scripts\create-admin.js admin vous@exemple.com "UnMotDePasseSolide123" vous@faucetpay.io
```

- `admin` = votre pseudo (3 à 20 caractères, lettres/chiffres/_)
- `vous@exemple.com` = votre email de connexion
- le mot de passe doit faire **au moins 10 caractères**
- la dernière valeur = votre adresse email/pseudo **FaucetPay** (celle qui recevra vos fonds)

Connectez-vous sur <http://localhost:3000/login>, puis ouvrez
<http://localhost:3000/admin>.

## 6. Tester le parcours complet (aucun argent réel)

1. **Inscription** : ouvrez une fenêtre de navigation privée → <http://localhost:3000/register>
2. **Robinet** : <http://localhost:3000/faucet> → répondez au captcha → **CLAIM BTC**
3. Vérifiez le solde, la minuterie, le rejeu bloqué (rechargez et recliquez).
4. **Retrait** : mettez un minimum de retrait bas dans `/admin` (ex. 10 sats),
   puis <http://localhost:3000/withdraw> → demande de retrait → statut **« simulé »**.
5. **Admin** → *Paiements FaucetPay* : le retrait apparaît, mode `mock`.
6. **Rentabilité** : `/admin` → tableau jour / 7 jours / 30 jours + simulateur.

## 7. Basculer sur votre vraie clé FaucetPay (quand vous le déciderez)

⚠️ Ne faites cette étape qu'après avoir créé votre compte faucet chez FaucetPay et
seulement lorsque vous être prêt à envoyer de vrais satoshis.

1. FaucetPay → *Faucet owner dashboard* → votre faucet → **Manage → API & Webhooks**
   → révélez la clé API (v1) ou créez des clés *scoped* (v2 : une clé `read`,
   une clé `send`).
2. Éditez `C:\btc-robinet\.env` avec le Bloc-notes :

```ini
FAUCETPAY_MODE=faucetpay
FAUCETPAY_API_VERSION=v1
FAUCETPAY_API_KEY=votre_cle_ici
PAYOUTS_LIVE=false      ← laissez false pour les tests « à blanc »
```

3. Redémarrez le serveur (Ctrl + C puis `npm start`).
4. Dans `/admin`, vérifiez que **FaucetPay** affiche *connecté* et le solde du faucet.
5. Testez une adresse avec le bouton *Vérifier* dans la page Retraits
   (`checkaddress` réel, aucun argent envoyé).
6. **Seulement après mon autorisation** : `PAYOUTS_LIVE=true`, redémarrage, puis
   un retrait volontairement petit (ex. le minimum) pour valider la chaîne complète.

> Gardez la clé API **uniquement** dans `.env`. Ne la collez jamais dans un message,
> un dépôt Git ou un fichier public.

## 8. Dépannage

| Symptôme | Cause / solution |
|---|---|
| `EADDRINUSE :3000` | Un autre programme utilise le port. Changez `PORT=3001` dans `.env`. |
| `[config] ERREUR: SESSION_SECRET…` | `.env` incomplet : remplacez la ligne par 64 caractères aléatoires. |
| Page blanche | Ouvrez la console (F12) ; vérifiez que le serveur tourne toujours. |
| `SqliteError: no such table` | Lancez `npm run init-db`. |
| `Cannot find module 'better-sqlite3'` | `npm install` n'a pas été fait dans le bon dossier. |
| Le captcha refuse | Rechargez la page (défi valable 5 min). |
| Mot de passe admin perdu | Relancez `node scripts\create-admin.js` avec le même pseudo : il réinitialise. |

## 9. Sauvegarde

Tout est dans `C:\btc-robinet\data\btc-robinet.db` (fichiers `.db`, `.db-wal`,
`.db-shm`). Copiez ce dossier régulièrement : c'est votre base de données complète.
