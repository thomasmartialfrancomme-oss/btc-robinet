# Rapport de tests — BTC ROBINET

**Date :** 12/11/2026 14:41 UTC
**Environnement :** Node v20.20.2 · SQLite locale · FaucetPay en simulation · aucun paiement réel

| Suite | Résultat |
|---|---|
| Application (serveur Node) | **129/129** — 0 échec(s) |
| Chemin Cloudflare Workers + D1 | **13/13** — 0 échec |

> Les deux suites exécutent le **vrai code HTTP** de l'application. La seconde passe par un
> objet `Request` Web et un adaptateur D1 (simulé par SQLite) : elle prouve que le portage
> Cloudflare ne change pas le comportement métier.
> **Aucun bitcoin réel n'a été déplacé** : mode simulation, verrou `PAYOUTS_LIVE` fermé.

Pour relancer : `npm test` et `npm run test:worker`.

## 1. Démarrage & configuration (4/4)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Configuration publique accessible | — |
| ✅ | Aucune clé API exposée au navigateur | — |
| ✅ | Mode paiement annoncé = simulation | — |
| ✅ | Page d'accueil servie | — |

## 2. Inscription & sécurité du mot de passe (9/9)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Mot de passe trop court refusé | — |
| ✅ | Captcha incorrect rejeté | — |
| ✅ | Inscription réussie | {"ok":true,"user":{"id":1,"username":"alice","email":"alice@example.com","payout_address": |
| ✅ | Mot de passe jamais renvoyé par l'API | — |
| ✅ | Code de parrainage généré | — |
| ✅ | Cookie de session posé (HttpOnly) | — |
| ✅ | Mot de passe stocké haché (PBKDF2-SHA256, jamais en clair) | — |
| ✅ | Email en double refusé | — |
| ✅ | Anti multi-compte : variante email contrôlée | — |

## 3. Connexion / déconnexion (9/9)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Mauvais mot de passe refusé (401) | — |
| ✅ | Inscription avec code de parrainage | — |
| ✅ | Filleul peut réclamer normalement | {"ok":true,"claim_id":1,"amount_sats":25,"base_sats":25,"bonus_sats":0,"bonus_percent":0," |
| ✅ | Commission de parrainage renvoyée au filleul (info) | — |
| ✅ | Connexion par email réussie | — |
| ✅ | Session valide (/api/me) | — |
| ✅ | Jeton CSRF fourni au client | — |
| ✅ | Déconnexion invalide la session | — |
| ✅ | Cookie de session forgé rejeté | — |

## 4. Protection CSRF (1/1)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Réclamation sans jeton CSRF bloquée | — |

## 5. Robinet BTC — réclamation, minuterie, limites (18/18)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | État du robinet disponible | — |
| ✅ | Récompense configurable affichée | — |
| ✅ | Solde cohérent : uniquement les commissions de parrainage (aucune réclamation) | solde=5, commissions=5 |
| ✅ | Première réclamation créditée | {"ok":true,"claim_id":2,"amount_sats":25,"base_sats":25,"bonus_sats":0,"bonus_percent":0," |
| ✅ | Solde mis à jour après réclamation | attendu=30, obtenu=30 |
| ✅ | Deuxième réclamation immédiate bloquée (cooldown) | — |
| ✅ | Temps d'attente communiqué | — |
| ✅ | Rejeu de la même requête bloqué | — |
| ✅ | Une seule réclamation enregistrée en base | — |
| ✅ | Lien de parrainage enregistré | — |
| ✅ | Commission de parrainage créditée | earned=5 |
| ✅ | Réclamation après expiration du cooldown acceptée | — |
| ✅ | Plafond de réclamations par jour respecté | — |
| ✅ | 4e réclamation du jour refusée (limite = 3) | {"ok":false,"error":"Limite journalière de réclamations atteinte. Revenez demain.","code": |
| ✅ | Historique des réclamations disponible | — |
| ✅ | Total des gains cohérent | — |
| ✅ | 8 réclamations simultanées → 1 seul crédit | succès=1, en base=1 |
| ✅ | Solde cohérent avec les crédits (pas de double crédit) | — |

## 6. FaucetPay — adresse, solde, retraits simulés (16/16)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Mode mock : aucun paiement réel possible | — |
| ✅ | Solde faucet (mock) récupérable | — |
| ✅ | Adresse invalide refusée | — |
| ✅ | Adresse FaucetPay acceptée (mock) | — |
| ✅ | Retrait sous le minimum refusé | — |
| ✅ | Retrait supérieur au solde refusé | — |
| ✅ | Retrait simulé accepté | {"ok":true,"duplicate":false,"payout":{"id":1,"user_id":1,"amount_sats":100,"currency":"BT |
| ✅ | Solde débité après retrait | — |
| ✅ | Mouvement inscrit au grand livre | — |
| ✅ | Double paiement impossible (clé d'idempotence) | — |
| ✅ | Un seul paiement enregistré malgré le rejeu | count=1 |
| ✅ | Erreur FaucetPay 456 => paiement en échec | {"ok":false,"error":"Paiement refusé par FaucetPay (Destinataire non payable). Montant rec |
| ✅ | Remboursement automatique du solde | avant=525, après=525 |
| ✅ | Remboursement tracé au grand livre | — |
| ✅ | Aucun paiement si le faucet est à découvert | — |
| ✅ | Solde interne intact en cas de refus de financement | — |

## 7. Parrainage (5/5)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Lien de parrainage personnel | — |
| ✅ | Filleul listé | — |
| ✅ | Commission cumulée > 0 | — |
| ✅ | Historique des commissions disponible | — |
| ✅ | Pourcentage de commission configurable | — |

## 8. Shortlinks (Étape 4) (16/16)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Admin : listes shortlinks accessibles | — |
| ✅ | Module désactivé => clic refusé | — |
| ✅ | Création d'un partenaire shortlink | — |
| ✅ | Création d'un lien shortlink | — |
| ✅ | Activation du module shortlinks | — |
| ✅ | Liste des liens pour le membre | — |
| ✅ | Démarrage : redirection vers le partenaire | — |
| ✅ | URL de retour signée (HMAC) | — |
| ✅ | Retour avec signature invalide => refusé | — |
| ✅ | Retour trop rapide (délai minimal) => refusé | — |
| ✅ | Retour validé => redirection avec gain | — |
| ✅ | Récompense shortlink créditée (15 sats) | avant=1980, après=1995 |
| ✅ | Rejeu du même retour impossible (session déjà validée) | — |
| ✅ | Revenu partenaire enregistré (cpm/1000) | usd=0.0035 |
| ✅ | Retour sans session => redirection connexion | — |
| ✅ | Lien en mode démonstration (sans secret partenaire) | — |

## 9. PTC (Étape 5) (11/11)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | PTC désactivé par défaut | — |
| ✅ | Création d'une campagne PTC | — |
| ✅ | URL de campagne invalide rejetée | — |
| ✅ | Campagne visible par le membre | — |
| ✅ | Ouverture d'une vue PTC (jeton unique) | — |
| ✅ | Validation avant la durée minimale refusée | — |
| ✅ | Vue PTC validée après la durée | — |
| ✅ | Récompense PTC créditée | avant=1995, après=2003 |
| ✅ | Double validation PTC impossible | — |
| ✅ | Budget annonceur débité | spent=8/100 |
| ✅ | Onglet non visible pendant la durée => refusé | — |

## 10. Offerwalls (Étape 6) (9/9)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Création d'un partenaire offerwall | — |
| ✅ | Callbacks refusés quand le module est désactivé | — |
| ✅ | Partenaire offerwall listé pour le membre | — |
| ✅ | Callback avec signature invalide => 401 | — |
| ✅ | Callback signé => conversion créditée | {"ok":true,"duplicate":false,"username":"alice","usd":0.01,"credited_sats":8,"balance_sats |
| ✅ | Solde augmenté du montant de la conversion | — |
| ✅ | Rejeu du callback ignoré (idempotence transaction_id) | — |
| ✅ | Mission non complétée => aucun crédit | — |
| ✅ | Admin : callbacks journalisés | — |

## 11. Administration (suite : modules) (4/4)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Admin : statistiques shortlinks | — |
| ✅ | Admin : campagnes PTC avec budget | — |
| ✅ | Suspension d'un lien par l'admin | — |
| ✅ | Lien suspendu inaccessible | — |

## 12. Administration (17/17)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Accès admin refusé aux membres | — |
| ✅ | Page /admin protégée (redirection) | — |
| ✅ | Connexion administrateur | — |
| ✅ | Page /admin accessible à l'admin | — |
| ✅ | Tableau de bord admin | — |
| ✅ | Solde FaucetPay visible en admin | — |
| ✅ | Récompense modifiable en admin | — |
| ✅ | Minuterie modifiable en admin | — |
| ✅ | Nouvelle récompense appliquée immédiatement | {"enabled":true,"maintenance":false,"reward_sats":40,"cooldown_seconds":60,"daily_limit":5 |
| ✅ | Valeurs aberrantes bornées | — |
| ✅ | Suspension d'un membre | — |
| ✅ | Membre suspendu : session invalidée / réclamation bloquée | status=401 |
| ✅ | Ajustement de solde manuel tracé | — |
| ✅ | Module robinet suspensible | — |
| ✅ | Robinet désactivé côté membre | — |
| ✅ | Paiements FaucetPay visibles en admin | — |
| ✅ | Recherche de membres | — |

## 13. Rentabilité (6/6)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Rapport financier disponible | — |
| ✅ | Résultat par jour/semaine/mois | — |
| ✅ | Coûts = récompenses + frais + hébergement | — |
| ✅ | Bénéfice net calculé (peut être négatif en MVP) | net=-0.13 |
| ✅ | Saisie manuelle d'un revenu | — |
| ✅ | Simulateur de rentabilité | {"daily_claims":1000,"reward_sats":25000,"revenue_usd":0.05,"reward_usd":22.5,"fees_usd":0 |

## 14. Sécurité complémentaire (4/4)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Limitation de débit sur la connexion | — |
| ✅ | Traversée de répertoire bloquée | — |
| ✅ | API retrait protégée sans session | — |
| ✅ | Journal d'audit alimenté | — |

## Chemin Cloudflare Workers + D1

| Résultat | Contrôle |
|---|---|
| ✅ | Configuration publique servie par le Worker |
| ✅ | Aucun secret exposé |
| ✅ | Inscription via Worker (PBKDF2 Web Crypto) |
| ✅ | Cookie de session émis avec Secure |
| ✅ | Réclamation créditée (INSERT conditionnel + index unique) |
| ✅ | Solde mis à jour |
| ✅ | 6 réclamations simultanées → 1 seul crédit (index unique claim_slot) |
| ✅ | Une seule réclamation en base |
| ✅ | Retrait simulé via Worker |
| ✅ | Rejeu de la clé d'idempotence : aucun second débit |
| ✅ | Démarrage shortlink via Worker |
| ✅ | Retour immédiat refusé (délai minimal) |
| ✅ | Page privée sans session → redirection |

## Points non testables sans vos comptes

- Paiement **réel** FaucetPay (clé API + fonds + votre autorisation explicite).
- Vérification d'une adresse FaucetPay réelle (`checkaddress` sur un vrai compte).
- Approbation du site par un réseau de shortlinks / offerwall.
- Déploiement Cloudflare réel (`wrangler deploy`) : le code est prêt et testé avec un D1 simulé.
- Captcha Cloudflare Turnstile en production (clés de compte requises).
