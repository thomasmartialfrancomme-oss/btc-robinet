# Partenaires : shortlinks, PTC, offerwalls

⚠️ **Aucun compte ne peut être créé à votre place : il faut votre identité, votre
email, votre portefeuille de paiement et souvent une validation manuelle du site.**
Ce document liste les réseaux à étudier, ce qu'il faut vérifier, et comment le code
est prêt à les brancher. Les conditions changent souvent : **vérifiez les CGU du
réseau au jour de votre inscription**, c'est votre responsabilité d'éditeur.

---

## 1. Shortlinks (monétisation du temps passé)

Principe : vous envoyez le membre sur une page publicitaire du réseau ; le réseau
paie le propriétaire du site au CPM (par 1 000 vues), et vous reversez une part au
membre. Le réseau doit **accepter le trafic "faucet / récompensé"**.

| Réseau | Trafic faucet | Paiement éditeur | À vérifier |
|---|---|---|---|
| ShrinkMe (shrinkme.io) | accepté (trafic crypto/micro-earn courant) | crypto, min. ~5 $ | CGU : « faucet / incentivized traffic » |
| Exe.io | annoncé compatible faucet/PTC | BTC, min. ~3 $ | validation du site + zone de trafic |
| Clk.sh | accepté | crypto, min. ~3–5 $ | anti-fraude strict sur les retours |
| ShrtFly | accepté | crypto | délais de paiement |

**Questions à poser à chaque réseau avant de signer :**
1. Le trafic provenant d'un site de récompenses (faucet/PTC) est-il autorisé ?
2. Proposez-vous une **URL de retour** (return URL / callback) avec paramètres ?
   (sans cela, la validation « clic terminé » n'est pas possible)
3. Quel est le CPM réel pour mes pays principaux (Afrique, Asie du Sud, Europe) ?
4. Y a-t-il un API de postback ou seulement des rapports ?
5. Quelles méthodes de paiement (idéalement FaucetPay/BTC) et quel minimum ?

**Implémenté et testé** (tables `shortlinks`, `shortlink_sessions`, `partners`) :

```
Membre clique
   → POST /api/shortlinks/:id/start
       crée une session (token UUID, statut pending, expire en 10 min)
       redirige vers : https://reseau/short?api=XXX&url=<retour signé>
   → le réseau affiche sa pub, puis renvoie le membre sur
       /shortlink/return?s=<token>&sig=<HMAC>
   → le serveur vérifie : signature, non-expiration, unicité,
       délai minimal (>= 15 s), quota journalier
   → crédit + `ledger` + statut validated
```

La clé `partners.callback_secret` sert de secret HMAC. **Aucun crédit sans retour
validé** : c'est la règle demandée à l'étape 4.

Chemin concret pour brancher un réseau :
1. `/admin` → *Shortlinks* → **Ajouter un réseau partenaire** : nom, URL de base
   (ex. `https://shrinkme.io/st?api=`), CPM réel, part reversée au membre, secret.
2. **Créer un lien rémunéré** : titre, récompense en sats, limite/jour.
3. Activer le module (bouton *Modules → Shortlinks*).
4. L'URL transmise au réseau est notre **URL de retour signée** ; si le réseau accepte un
   paramètre de retour, les clics reviennent automatiquement et sont crédités.
   Si le réseau n'offre pas d'URL de retour utilisable, il faut passer par son API
   (rapport de clics) : dans ce cas, ne créditez pas automatiquement — utilisez la
   validation manuelle dans `/admin`.

---

## 2. PTC (paid-to-click)

Ici les choses sont différentes : **payer des gens pour cliquer sur des publicités
classiques (AdSense, réseaux display) est interdit par ces réseaux** et peut faire
fermer votre compte. Le PTC n'est légitime que dans deux cas :

1. **Vous vendez vous-même les campagnes** : un annonceur paie pour X vues garanties
   (forfait ou CPM négocié). C'est alors un contrat direct, et vous pouvez rémunérer
   la consultation.
2. **Réseaux PTC spécialisés** (ex. plateformes de type « traffic exchange » payant)
   qui autorisent explicitement la redistribution du trafic à des membres rémunérés.

Le code du projet est conforme à ce cadre : la table `ptc_ads` exige un champ
`advertiser` et un `budget_sats`, la page `/ptc` refuse d'afficher quoi que ce soit
tant que l'administrateur n'a pas créé de campagne, et **chaque vue est débitée du budget
de l'annonceur** (`spent_sats`) : impossible de payer plus que ce que l'annonceur a versé.
La création de campagne et le rechargement de budget se font dans `/admin → PTC`.

**Mécanique anti-fraude prévue** : jeton de vue unique, durée minimale contrôlée
serveur, onglet actif vérifié (`visibilitychange`), limite quotidienne, détection de
fréquence anormale, traçabilité IP.

**À ne jamais faire** : iframes cachées, clics automatiques, faux visiteurs, popunder
forcé, « loader » de faux trafic. Ce sont des fraudes publicitaires : comptes fermés,
fonds confisqués, et risques juridiques.

---

## 3. Offerwalls

Fournisseurs généralement compatibles avec des sites de récompenses (à valider un par
un, certains **refusent** les faucets) :

| Fournisseur | Modèle | Compatibilité faucet | Remarque |
|---|---|---|---|
| AdGate Media | offerwall + postback | à valider | souvent OK pour sites de récompenses, API postback robuste |
| OfferToro | offerwall | à valider | exige un site « propre », validation manuelle |
| ayeT-Studios / TimeWall | offerwall + surveys | à valider | propose des murs « reward » |
| BitLabs / CPX Research | sondages | à valider | sondages = meilleur CPM, forte demande de conformité |
| AyetStudios | offerwall | à valider | — |

**Ce qui est exigé de vous, en général** : site en HTTPS avec contenu réel
(ce n'est pas un simple splash), page de conditions, politique de confidentialité,
système de support, moyen de contact, preuve que les utilisateurs sont réellement
rémunérés. Certains demandent un **volume minimum** de trafic avant l'approbation.

**Postback à fournir au réseau** (à implémenter côté Workers/Node) :

```
GET/POST /api/offerwalls/:partner/callback
  ?user_id=<notre id>          (fourni par nous dans l'URL générée)
  &transaction_id=<unique>
  &amount=<montant>
  &payout=<USD>
  &signature=<HMAC ou hash du réseau>
```

Traitement obligatoire, dans cet ordre :
1. vérifier la signature avec `partners.callback_secret` (sinon 401),
2. vérifier l'unicité de `transaction_id` (table `offerwall_callbacks`),
3. journaliser le callback **avant** tout crédit,
4. créditer la conversion en sats selon le taux configuré,
5. répondre `200 OK` — le réseau réessaie sinon (d'où l'idempotence).

Le schéma de base contient déjà la table `offerwall_callbacks` avec
`transaction_id UNIQUE` : le doublon est impossible au niveau de la base.

**Implémentation livrée** : `GET|POST /api/offerwalls/:id/callback`
(voir `src/services/offerwall.js`) — vérifie la signature (HMAC-SHA256, MD5 avec ou sans
secret, selon le réseau), refuse les missions non complétées (`status=0`), applique un
montant minimal, plafonne à 200 000 sats par conversion, journalise avant crédit et
crédite une seule fois. Testé avec signatures valides, invalides et rejeux.

---

## 4. Publicité display (complément, optionnel)

Un bandeau display classique (AdSense et équivalents) **ne peut pas** être combiné avec
une rémunération au clic. Vous pouvez en revanche afficher un bandeau passif (sans
récompense) pour couvrir l'hébergement. AdSense refuse généralement les faucets ;
d'autres régies sont plus tolérantes mais avec des CPM faibles. À évaluer une fois le
trafic existant.

---

## 5. Récapitulatif des revenus à suivre dans l'admin

| Source | Unité de mesure | À saisir dans `/admin → Rentabilité` |
|---|---|---|
| Shortlinks | CPM par pays | revenu / 1000 points + entrées manuelles réelles |
| Offerwalls | USD par conversion | entrées manuelles mensuelles |
| PTC vendu directement | forfait | entrées manuelles |
| Display | CPM passif | entrées manuelles |
| Hébergement, frais FaucetPay | USD / % | dépenses + champ `faucetpay_fee_percent` |

Le calculateur affiche alors le **bénéfice net avant impôts** par jour, semaine et mois
(Étape 9), et le simulateur vous donne le point d'équilibre : à combien de
réclamations par jour le site devient rentable avec vos vrais taux.
