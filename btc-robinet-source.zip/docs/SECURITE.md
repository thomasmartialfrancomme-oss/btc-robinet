# Sécurité, anti-fraude et conformité — BTC ROBINET

Ce document décrit précisément ce qui est protégé, comment, et les points à surveiller
avant d'ouvrir le site au public.

---

## 1. Paiements : les 3 verrous

| Verrou | Emplacement | Effet |
|---|---|---|
| `FAUCETPAY_MODE=mock` | `.env` | aucune requête réseau vers FaucetPay |
| `PAYOUTS_LIVE=false` | `.env` | même en mode `faucetpay`, `/send` n'est jamais appelé |
| Clé API absente côté navigateur | par conception | seul le serveur lit `process.env` |

Il faut donc **deux** changements explicites pour qu'un satoshi réel parte.

## 2. Anti-double-paiement et anti-double-réclamation

| Risque | Protection |
|---|---|
| Double clic sur CLAIM | verrou mémoire par membre + `nonce` unique en base (`claims.nonce UNIQUE`) |
| Requêtes simultanées | re-contrôle du cooldown **dans la transaction** SQLite (série d'exécution) |
| Rejeu de la requête de retrait | `payouts.idempotency_key UNIQUE` + re-vérification du solde dans la transaction |
| Retry réseau vers FaucetPay | en v2, `idempotency_key` est transmis au fournisseur |
| Refus FaucetPay | remboursement automatique (codes 401/403/405/410/456/457) + écriture `ledger` |
| Panne réseau pendant l'envoi | statut `failed` **sans** remboursement, signalé à vérifier en admin (le paiement a peut-être eu lieu) |
| Retrait sans financement | solde FaucetPay vérifié avant chaque envoi (jamais de découvert) |

Ordre d'écriture d'un retrait : contrôle → débit + ligne de paiement `pending` dans la
même transaction → **ensuite** appel FaucetPay. Le débit précède donc l'appel : même en
cas de coupure serveur, l'argent n'est jamais dépensé deux fois.

## 3. Authentification

- **scrypt** (N=16384, r=8, p=1, sel 128 bits) — pas de MD5/SHA1, pas de mot de passe en clair.
- Comparaison en temps constant (`crypto.timingSafeEqual`).
- Connexion : vérification factice même si l'utilisateur n'existe pas (évite la
  révélation d'existence par le temps de réponse).
- Sessions : token 256 bits dans un cookie `HttpOnly; SameSite=Lax; Secure` (en prod),
  empreinte SHA-256 seule en base, expiration 72 h, révocables (déconnexion globale).
- Changement de mot de passe → toutes les sessions sont détruites.
- Limitation : inscription 8/h/IP, connexion 10/15 min/IP, réclamation 40/h/IP,
  retraits 15/h/IP + 5/h + 2 min entre deux par membre.

## 4. CSRF, XSS, injections

- Toutes les actions mutantes exigent `X-CSRF-Token` dérivé de la session (HMAC SHA-256).
- Pages : `X-Frame-Options: SAMEORIGIN`, `X-Content-Type-Options: nosniff`,
  `Referrer-Policy`, `Permissions-Policy`.
- Côté client, toute donnée serveur passe par `fmt.esc()` avant insertion HTML.
- SQL : **100 % requêtes préparées** (`?`), aucune concaténation de valeurs.
- Fichiers statiques : normalisation de chemin + vérification de confinement
  (traversée `../` testée et bloquée).
- Corps de requête limité à 64 Ko.

## 5. Anti-fraude membres

| Signal | Réaction |
|---|---|
| Email jetable (mailinator, yopmail, temp-mail…) | inscription refusée |
| Variante d'email (`ali.ce+1@gmail.com` = `alice@gmail.com`) | doublon détecté |
| ≥ 3 inscriptions / 24 h depuis une IP | refus + score de risque |
| ≥ 4 réclamations / 10 min depuis une IP | score de risque |
| Score de risque ≥ 100 | suspension automatique + journal d'audit |
| User-Agent suspect / VPN-proxy déclaratif | score augmenté |
| Retraits multiples | quotas horaires + délai de 2 min |

Le score est **visible et réinitialisable** dans `/admin` : vous gardez la main.

## 6. Journalisation et traçabilité

- `ledger` : chaque mouvement de solde (crédit, débit, remboursement, commission,
  ajustement admin) avec horodatage et métadonnées.
- `audit_log` : connexions, échecs, inscriptions, changements de réglages, actions
  admin, envois de paiement.
- `payouts` : statut, mode, id fournisseur, message d'erreur, clé d'idempotence.

En cas de litige avec un membre, vous pouvez reconstituer **chaque satoshi**.

## 7. Conformité : ce que vous devez faire vous-même

1. **Mentions légales** : nom, contact, hébergeur, responsabilité — complétez `/legal`.
2. **RGPD** (si des visiteurs européens) : finalité, durée de conservation, droits
   d'accès/suppression, base légale (intérêt légitime / contrat).
3. **Fiscalité** : les revenus publicitaires et les cryptos reçues sont imposables
   dans la plupart des juridictions. Tenez la comptabilité via `/admin → Rentabilité`
   et exportez régulièrement.
4. **CGU des partenaires** : c'est le point le plus risqué. Un faucet qui envoie du
   trafic rémunéré vers un réseau display classique se fait fermer. Utilisez
   uniquement des réseaux qui autorisent explicitement ce modèle.
5. **FaucetPay** : respectez leurs conditions faucet (pas de paiement à des comptes
   non vérifiés, pas de blanchiment, anti-fraude activée de leur côté).

## 8. Liste de contrôle avant ouverture publique

- [ ] `SESSION_SECRET` unique et long, `COOKIE_SECURE=true`, HTTPS
- [ ] `PAYOUTS_LIVE=false` jusqu'à validation complète
- [ ] Captcha Turnstile en production
- [ ] Sauvegarde quotidienne de la base vérifiée (restauration testée)
- [ ] Solde FaucetPay suffisant + alerte de solde bas configurée
- [ ] Récompense / minuterie ajustées à la rentabilité réelle
- [ ] Modules non validés (shortlinks, PTC, offerwalls) laissés désactivés
- [ ] `/legal` complet, page de contact, adresse de support
- [ ] Surveillance des logs pendant 72 h après l'ouverture
