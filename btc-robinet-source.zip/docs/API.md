# API interne — BTC ROBINET

Base : `http://localhost:3000`. Réponses JSON. Les erreurs renvoient
`{ ok:false, error, code, details? }` avec le code HTTP correspondant.
Les requêtes mutantes (`POST`) exigent l'en-tête `X-CSRF-Token` (valeur `csrf`
renvoyée par `/api/me` ou par la réponse d'inscription/connexion) et le cookie de session.

## Public

| Méthode | Route | Description |
|---|---|---|
| GET | `/api/public/config` | nom du site, modules, récompenses, mode de paiement |
| GET | `/api/auth/captcha` | défi captcha (mode `math`) |

## Authentification

| Méthode | Route | Corps | Description |
|---|---|---|---|
| POST | `/api/auth/register` | `username, email, password, payout_address, ref?, captcha*` | crée le compte + session |
| POST | `/api/auth/login` | `login, password` | session |
| POST | `/api/auth/logout` | — | détruit la session |
| GET | `/api/me` | — | utilisateur, CSRF, réglages, état du fournisseur |
| POST | `/api/me/profile` | `payout_address` | change l'adresse FaucetPay |
| POST | `/api/me/password` | `current_password, new_password` | change le mot de passe (déconnecte) |

## Robinet

| Méthode | Route | Corps | Description |
|---|---|---|---|
| GET | `/api/faucet/state` | — | récompense, cooldown restant, quota, série, solde |
| POST | `/api/faucet/claim` | `nonce, captcha*` | crédite la récompense |
| GET | `/api/claims/history?limit=&offset=&module=` | — | historique des gains |

Erreurs typiques : `cooldown` (429 + `retry_after`), `daily_limit` (429),
`duplicate_nonce` (409), `captcha` (400), `module_off` (503).

## Retraits

| Méthode | Route | Corps | Description |
|---|---|---|---|
| GET | `/api/payouts` | — | solde, minimum, historique, état FaucetPay |
| POST | `/api/payouts/verify-address` | `address` | `checkaddress` FaucetPay |
| POST | `/api/payouts/withdraw` | `amount_sats, idempotency_key?` | demande de retrait |

Erreurs : `below_min`, `insufficient_balance`, `rate_limit`, `cooldown`,
`provider_insufficient_funds` (503), `provider_unreachable` (503), `provider_error` (502).

## Parrainage

| Méthode | Route | Description |
|---|---|---|
| GET | `/api/referral` | lien, code, %, filleuls, commissions |

## Administration (rôle `admin` requis)

| Méthode | Route | Description |
|---|---|---|
| GET | `/api/admin/overview` | compteurs, stats, finance, état FaucetPay, réglages |
| GET / POST | `/api/admin/settings` | lire / modifier les réglages (valeurs bornées) |
| GET | `/api/admin/users?q=&status=&limit=` | recherche de membres |
| POST | `/api/admin/users/:id/:action` | `suspend`, `ban`, `activate`, `reset-risk`, `logout-all`, `adjust-balance` |
| GET | `/api/admin/payouts?status=&limit=` | paiements FaucetPay |
| POST | `/api/admin/payouts/:id/:action` | `retry`, `mark-sent`, `cancel-refund` |
| GET | `/api/admin/finance` | rapport jour/semaine/mois + écritures |
| POST | `/api/admin/finance/entry` | saisir un revenu / une dépense |
| POST | `/api/admin/finance/simulate` | simulateur de rentabilité |
| POST | `/api/admin/modules/:name/:state` | `on` / `off` : faucet, shortlinks, ptc, offerwalls, referral |
| GET | `/api/admin/audit?limit=` | journal d'audit |
| GET | `/api/admin/partners` | partenaires enregistrés |

## Exemple complet (curl)

```bash
# 1. captcha
curl -s http://localhost:3000/api/auth/captcha
# → {"mode":"math","challenge":"...","signature":"...","question":"7 × 4 = ?","ttlSeconds":300}

# 2. inscription (réponse = mot de passe de l'exemple)
curl -s -c cookies.txt -X POST http://localhost:3000/api/auth/register \
  -H 'Content-Type: application/json' \
  -d '{"username":"demo","email":"demo@exemple.com","password":"MotDePasse123",
       "payout_address":"demo@faucetpay.io",
       "captcha_challenge":"...","captcha_signature":"...","captcha_answer":28}'

# 3. /api/me → récupérer csrf
curl -s -b cookies.txt http://localhost:3000/api/me

# 4. réclamation
curl -s -b cookies.txt -X POST http://localhost:3000/api/faucet/claim \
  -H 'Content-Type: application/json' -H 'X-CSRF-Token: <csrf>' \
  -d '{"nonce":"essai-1","captcha_challenge":"...","captcha_signature":"...","captcha_answer":12}'
```
