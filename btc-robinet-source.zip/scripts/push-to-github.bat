@echo off
REM Pousse le depot vers GitHub sous Windows, sans stocker le token sur disque.
REM Usage (invite de commandes) :
REM   set GITHUB_TOKEN=ghp_xxx
REM   scripts\push-to-github.bat
REM   scripts\push-to-github.bat https://github.com/utilisateur/depot.git

setlocal
set REPO=%1
if "%REPO%"=="" set REPO=https://github.com/thomasmartialfrancomme-oss/btc-robinet.git
if "%GITHUB_TOKEN%"=="" (
  echo ERREUR : definissez GITHUB_TOKEN avant de lancer ce script.
  echo   set GITHUB_TOKEN=ghp_votre_token
  exit /b 1
)

cd /d "%~dp0.."
echo -- Verification des tests --
call npm test
if errorlevel 1 (
  echo Les tests echouent : envoi annule.
  exit /b 1
)

git remote remove origin 2>nul
git remote add origin %REPO%
git -c credential.helper="!f() { echo username=x-access-token; echo password=%GITHUB_TOKEN%; }; f" push -u origin main

echo.
echo Depose publie. Pensez a revoquer le token utilise.
endlocal
