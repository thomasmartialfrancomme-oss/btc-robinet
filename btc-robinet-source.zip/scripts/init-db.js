'use strict';
/**
 * Initialise la base de données (crée les tables et les réglages par défaut).
 *   npm run init-db
 */
const fs = require('node:fs');
const path = require('node:path');
const config = require('../src/lib/config');
const { createDb } = require('../src/lib/db');
const { SettingsService } = require('../src/services/settings');

(async () => {
  const db = createDb(config.dbPath);
  const schema = fs.readFileSync(path.join(config.root, 'db', 'schema.sql'), 'utf8');
  await db.exec(schema);
  const settings = new SettingsService(db);
  await settings.init({
    faucet_reward_sats: config.defaults.faucetRewardSats,
    faucet_cooldown_seconds: config.defaults.faucetCooldownSeconds,
    faucet_daily_limit: config.defaults.faucetDailyLimit,
    min_withdraw_sats: config.defaults.minWithdrawSats,
    referral_percent: config.defaults.referralPercent,
  });
  const tables = await db.all("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name");
  console.log('Base initialisée :', config.dbPath);
  console.log('Tables :', tables.map((t) => t.name).join(', '));
  await db.close();
})();
