/**
 * Prépare le worker Cloudflare :
 *  - génère worker/schema.generated.js (schéma SQL embarqué) ;
 *  - vérifie que les dossiers nécessaires existent.
 *
 * Usage : npm run build:worker
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const schema = fs.readFileSync(path.join(ROOT, 'db', 'schema.sql'), 'utf8');

const banner = `// FICHIER GÉNÉRÉ AUTOMATIQUEMENT — ne pas éditer.
// Source : db/schema.sql — régénérer avec : npm run build:worker
`;
fs.writeFileSync(
  path.join(ROOT, 'worker', 'schema.generated.js'),
  `${banner}export default ${JSON.stringify(schema)};\n`,
  'utf8'
);

console.log('✓ worker/schema.generated.js généré');
console.log('  → déploiement : npx wrangler deploy  (voir docs/MISE-EN-LIGNE.md, option B)');
