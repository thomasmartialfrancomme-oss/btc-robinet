'use strict';
/**
 * Crée (ou réinitialise) un compte administrateur.
 *
 *   node scripts/create-admin.js <pseudo> <email> <motdepasse> [adresse_faucetpay]
 *
 * Exemple :
 *   node scripts/create-admin.js admin moi@exemple.com "MotDePasseSolide123" moi@exemple.com
 */
const config = require('../src/lib/config');
const { createDb } = require('../src/lib/db');
const { hashPassword, randomCode } = require('../src/lib/security');

(async () => {
  const [username, email, password, payout] = process.argv.slice(2);
  if (!username || !email || !password) {
    console.error('Usage : node scripts/create-admin.js <pseudo> <email> <motdepasse> [adresse_faucetpay]');
    process.exit(1);
  }
  if (password.length < 10) {
    console.error('Le mot de passe administrateur doit contenir au moins 10 caractères.');
    process.exit(1);
  }
  const db = createDb(config.dbPath);
  const existing = await db.get('SELECT id FROM users WHERE lower(username)=lower(?) OR email=?', [username, email.toLowerCase()]);
  if (existing) {
    await db.run(`UPDATE users SET password_hash=?, role='admin', status='active' WHERE id=?`, [await hashPassword(password), existing.id]);
    console.log(`Compte existant #${existing.id} promu administrateur (mot de passe réinitialisé).`);
  } else {
    const r = await db.run(
      `INSERT INTO users (username, email, password_hash, payout_address, referral_code, role, status)
       VALUES (?, ?, ?, ?, ?, 'admin', 'active')`,
      [username, email.toLowerCase(), await hashPassword(password), payout || email, randomCode(7)]
    );
    console.log(`Administrateur créé : #${r.lastInsertRowid} (${username})`);
  }
  await db.close();
})();
