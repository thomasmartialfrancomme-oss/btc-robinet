#!/usr/bin/env bash
# Pousse le dépôt vers GitHub SANS stocker le token sur disque.
#
# Usage :
#   GITHUB_TOKEN=ghp_xxx ./scripts/push-to-github.sh
#   GITHUB_TOKEN=ghp_xxx ./scripts/push-to-github.sh https://github.com/user/repo.git
#
# Le token n'est jamais écrit dans .git/config ni dans un fichier : il est passé
# via un helper d'identification éphémère, valable le temps de la commande.
set -euo pipefail

REPO="${1:-https://github.com/thomasmartialfrancomme-oss/btc-robinet.git}"
: "${GITHUB_TOKEN:?Définissez GITHUB_TOKEN (token fine-grained, droit Contents: Read and write)}"

cd "$(dirname "$0")/.."

echo "→ Vérification des tests avant envoi…"
npm test > /dev/null && echo "  ✓ tests serveur OK"

echo "→ Configuration du dépôt distant : $REPO"
git remote remove origin 2>/dev/null || true
git remote add origin "$REPO"

echo "→ Envoi de la branche main…"
git -c credential.helper='!f() { echo "username=x-access-token"; echo "password=${GITHUB_TOKEN}"; }; f' \
    push -u origin main

echo
echo "✓ Dépôt publié : ${REPO%.git}"
echo "→ Pensez à révoquer le token utilisé (Settings → Developer settings → Tokens)."
