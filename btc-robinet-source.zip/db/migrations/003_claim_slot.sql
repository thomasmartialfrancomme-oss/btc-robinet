-- Migration 003 — anti-double-réclamation atomique (compatible SQLite et D1)
-- Ajoute la colonne de fenêtre de cooldown + l'index unique correspondant.
-- Sur une base neuve, db/schema.sql contient déjà ces éléments.

ALTER TABLE claims ADD COLUMN claim_slot INTEGER;

CREATE UNIQUE INDEX IF NOT EXISTS idx_claims_user_slot
  ON claims(user_id, module, claim_slot) WHERE claim_slot IS NOT NULL;
