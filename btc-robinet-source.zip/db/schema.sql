-- =====================================================================
--  BTC ROBINET — Schéma de base de données (SQLite local / Cloudflare D1)
--  Compatible SQLite 3 et D1. Les montants sont en SATOSHIS (entiers).
-- =====================================================================

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  username          TEXT NOT NULL UNIQUE,
  email             TEXT NOT NULL UNIQUE,
  password_hash     TEXT NOT NULL,
  payout_address    TEXT NOT NULL,              -- email / username FaucetPay
  payout_hash       TEXT,                       -- hash renvoyé par checkaddress
  balance_sats      INTEGER NOT NULL DEFAULT 0, -- solde disponible (non payé)
  total_earned_sats INTEGER NOT NULL DEFAULT 0, -- cumul gains (statistique)
  total_paid_sats   INTEGER NOT NULL DEFAULT 0, -- cumul payé via FaucetPay
  referral_code     TEXT NOT NULL UNIQUE,
  referred_by       INTEGER REFERENCES users(id) ON DELETE SET NULL,
  role              TEXT NOT NULL DEFAULT 'user',      -- user | admin
  status            TEXT NOT NULL DEFAULT 'active',    -- active | suspended | banned
  risk_score        INTEGER NOT NULL DEFAULT 0,
  signup_ip         TEXT,
  last_ip           TEXT,
  last_login_at     TEXT,
  created_at        TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at        TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_users_ref ON users(referred_by);
CREATE INDEX IF NOT EXISTS idx_users_ip ON users(signup_ip);

CREATE TABLE IF NOT EXISTS sessions (
  id          TEXT PRIMARY KEY,               -- hash SHA-256 du token (jamais le token en clair)
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  ip          TEXT,
  user_agent  TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

-- Réglages modifiables depuis l'administration (clé/valeur JSON)
CREATE TABLE IF NOT EXISTS settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Journal des réclamations (robinet, shortlinks, PTC, offerwalls, bonus)
CREATE TABLE IF NOT EXISTS claims (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  module       TEXT NOT NULL DEFAULT 'faucet',  -- faucet | shortlink | ptc | offerwall | bonus
  ref_id       INTEGER,                          -- id de la campagne shortlink/ptc/offre
  amount_sats  INTEGER NOT NULL,
  ip           TEXT,
  user_agent   TEXT,
  nonce        TEXT,                             -- anti double réclamation (unique par membre)
  claim_slot   INTEGER,                          -- fenêtre de cooldown (anti-double atomique)
  ledger_ref   TEXT,                             -- identifiant de corrélation avec le grand livre
  status       TEXT NOT NULL DEFAULT 'credited', -- credited | reversed
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_claims_user_date ON claims(user_id, created_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_claims_user_nonce ON claims(user_id, nonce) WHERE nonce IS NOT NULL;
-- Une seule réclamation 'faucet' par membre et par fenêtre de cooldown :
-- garantit l'anti-double-réclamation même sous requêtes simultanées (SQLite et D1).
CREATE UNIQUE INDEX IF NOT EXISTS idx_claims_user_slot ON claims(user_id, module, claim_slot)
  WHERE claim_slot IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_claims_ip_date ON claims(ip, created_at);

-- Retraits / paiements FaucetPay
CREATE TABLE IF NOT EXISTS payouts (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount_sats      INTEGER NOT NULL,
  currency         TEXT NOT NULL DEFAULT 'BTC',
  destination      TEXT NOT NULL,
  status           TEXT NOT NULL DEFAULT 'pending', -- pending | simulated | sent | failed | cancelled
  mode             TEXT NOT NULL DEFAULT 'mock',    -- mock | faucetpay
  idempotency_key  TEXT NOT NULL UNIQUE,
  provider_payout_id TEXT,
  provider_hash    TEXT,
  provider_status  INTEGER,
  provider_message TEXT,
  ip               TEXT,
  created_at       TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_payouts_user ON payouts(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_payouts_status ON payouts(status);

-- Journal comptable : chaque mouvement de solde (audit / rentabilité)
CREATE TABLE IF NOT EXISTS ledger (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id       INTEGER REFERENCES users(id) ON DELETE SET NULL,
  type          TEXT NOT NULL,   -- credit_reward | debit_payout | refund | referral_bonus | revenue | expense
  module        TEXT,
  amount_sats   INTEGER NOT NULL,  -- positif = crédit membre, négatif = débit
  balance_after INTEGER,
  meta          TEXT,
  ref           TEXT,                             -- corrélation (idempotence des écritures)
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ledger_date ON ledger(created_at);

-- Commissions de parrainage
CREATE TABLE IF NOT EXISTS referrals (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  referrer_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  referred_id     INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  percent         INTEGER NOT NULL,
  earned_sats     INTEGER NOT NULL DEFAULT 0,
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_id);

-- Rate limiting / anti-fraude (en base : fonctionne aussi en D1)
CREATE TABLE IF NOT EXISTS rate_limits (
  bucket     TEXT PRIMARY KEY,
  count      INTEGER NOT NULL DEFAULT 0,
  window_end TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id   INTEGER,
  action     TEXT NOT NULL,
  target     TEXT,
  meta       TEXT,
  ip         TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_date ON audit_log(created_at);

-- ---------------------------------------------------------------------
--  MODULES POST-MVP (tables prêtes, modules désactivés par défaut)
-- ---------------------------------------------------------------------

-- Partenaires : revendeurs de trafic (shortlinks) et offreurs (offerwalls/PTC)
CREATE TABLE IF NOT EXISTS partners (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  name           TEXT NOT NULL,
  type           TEXT NOT NULL,             -- shortlink | offerwall | ptc | adsense
  network_url    TEXT,
  callback_secret TEXT,                     -- secret HMAC de validation des retours
  cpm_usd        REAL NOT NULL DEFAULT 0,   -- revenu estimé pour 1000 vues
  revenue_share  INTEGER NOT NULL DEFAULT 60, -- % reversé au membre
  status         TEXT NOT NULL DEFAULT 'active', -- active | paused | suspended
  notes          TEXT,
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Campagnes shortlinks (liens à faire visiter, avec URL de retour signée)
CREATE TABLE IF NOT EXISTS shortlinks (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  partner_id    INTEGER REFERENCES partners(id) ON DELETE SET NULL,
  title         TEXT NOT NULL,
  target_url    TEXT NOT NULL,              -- URL du réseau partenaire
  reward_sats   INTEGER NOT NULL DEFAULT 15,
  daily_limit   INTEGER NOT NULL DEFAULT 10,
  status        TEXT NOT NULL DEFAULT 'active',
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Sessions de shortlinks : créées au clic, validées par le retour du partenaire
CREATE TABLE IF NOT EXISTS shortlink_sessions (
  id          TEXT PRIMARY KEY,             -- token unique
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  shortlink_id INTEGER NOT NULL REFERENCES shortlinks(id) ON DELETE CASCADE,
  status      TEXT NOT NULL DEFAULT 'pending', -- pending | validated | rejected
  reward_sats INTEGER NOT NULL,
  ledger_ref  TEXT,                            -- corrélation avec le crédit effectif
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  validated_at TEXT
);

-- Campagnes PTC
CREATE TABLE IF NOT EXISTS ptc_ads (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  advertiser    TEXT NOT NULL,
  title         TEXT NOT NULL,
  target_url    TEXT NOT NULL,
  duration_sec  INTEGER NOT NULL DEFAULT 30,
  reward_sats   INTEGER NOT NULL DEFAULT 10,
  budget_sats   INTEGER NOT NULL DEFAULT 0,      -- budget annonceur (0 = illimité)
  spent_sats    INTEGER NOT NULL DEFAULT 0,
  daily_limit   INTEGER NOT NULL DEFAULT 5,
  status        TEXT NOT NULL DEFAULT 'active',
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS ptc_views (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  ad_id      INTEGER NOT NULL REFERENCES ptc_ads(id) ON DELETE CASCADE,
  token      TEXT NOT NULL UNIQUE,
  status     TEXT NOT NULL DEFAULT 'started', -- started | credited | rejected
  ledger_ref TEXT,                            -- corrélation avec le crédit effectif
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  credited_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_ptc_user ON ptc_views(user_id, ad_id);

-- Callbacks offerwalls (idempotence par transaction_id du réseau)
CREATE TABLE IF NOT EXISTS offerwall_callbacks (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  partner_id     INTEGER REFERENCES partners(id) ON DELETE SET NULL,
  user_id        INTEGER REFERENCES users(id) ON DELETE SET NULL,
  transaction_id TEXT NOT NULL UNIQUE,
  offer_name     TEXT,
  amount_usd     REAL,
  reward_sats    INTEGER,
  signature_ok   INTEGER NOT NULL DEFAULT 0,
  status         TEXT NOT NULL DEFAULT 'received', -- received | credited | rejected
  ledger_ref     TEXT,                             -- corrélation avec le crédit effectif
  raw            TEXT,
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Revenus et dépenses du propriétaire (module rentabilité)
CREATE TABLE IF NOT EXISTS finance_entries (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  kind       TEXT NOT NULL,     -- revenue | expense
  category   TEXT NOT NULL,     -- shortlinks | ptc | offerwall | adsense | hosting | fees | other
  amount_usd REAL NOT NULL DEFAULT 0,
  sats       INTEGER NOT NULL DEFAULT 0,
  note       TEXT,
  entry_date TEXT NOT NULL DEFAULT (date('now')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_finance_date ON finance_entries(entry_date);
