# ₿ BTC ROBINET — robinet Bitcoin (MVP + modules prêts)

Site de robinet Bitcoin : les membres réclament des satoshis, complètent des tâches
rémunérées et retirent leurs gains **exclusivement via FaucetPay**. Le propriétaire
suit ses revenus et ses coûts dans un panneau d'administration avec calculateur de
rentabilité.

> **État actuel : MVP testé en local, en mode simulation.** Aucun paiement réel n'est
> possible tant que vous n'avez pas fourni votre clé FaucetPay **et** ouvert le verrou
> `PAYOUTS_LIVE=true`. Rien n'est encore en ligne.

---

## 1. Ce qui fonctionne déjà (Étapes 1, 2, 3, 7, 8, 9, 11)

| Module | État | Détail |
|---|---|---|
| Accueil / design noir-orange / responsive | ✅ | `public/index.html` + `public/css/style.css` |
| Inscription | ✅ | scrypt, captcha, anti multi-compte, code de parrainage |
| Connexion / sessions | ✅ | cookie HttpOnly, sessions en base, CSRF sur toutes les actions |
| Tableau de bord | ✅ | solde, gains, retraits, filleuls, état du système |
| Robinet BTC | ✅ | CLAIM, minuterie, captcha, quota/jour, anti double réclamation, bonus de série |
| Historique | ✅ | réclamations + retraits, export CSV |
| Retraits FaucetPay | ✅ | `checkaddress`, solde faucet, envoi, idempotence, remboursement auto |
| Parrainage | ✅ | lien, suivi, commission configurable, anti-fraude |
| Administration | ✅ | récompenses, minuteries, membres, blocages, modules, paiements, audit |
| Rentabilité | ✅ | revenus − récompenses − frais − hébergement, jour/semaine/mois + simulateur |
| Shortlinks | ✅ | session signée HMAC, délai minimal, quota, crédit + revenu partenaire enregistré |
| PTC | ✅ | campagnes à budget, jeton unique, durée + visibilité vérifiées, limite/jour |
| Offerwalls | ✅ | callbacks signés (HMAC/MD5), idempotence par transaction, conversion USD→sats |
| Cloudflare Workers + D1 | ✅ | portage réalisé et testé (`npm run test:worker`, 13 contrôles) |
| Tests | ✅ | **142 contrôles automatisés** (129 serveur + 13 chemin Worker/D1), rapport dans `docs/RAPPORT-DE-TESTS.md` |

## 1 bis. Lien en ligne (temporaire)

**https://operations-course-chen-extra.trycloudflare.com** — site accessible publiquement
(tunnel Cloudflare, HTTPS). Comptes de démonstration, limites de ce lien et procédure pour
obtenir un hébergement définitif : **[docs/ACCES-EN-LIGNE.md](docs/ACCES-EN-LIGNE.md)**.

## 2. Démarrage en 3 minutes (Windows, macOS ou Linux)

Prérequis : **Node.js 18.17+** (20 LTS recommandé) — <https://nodejs.org>

```bash
cd btc-robinet
npm install
npm start
```

Puis ouvrez <http://localhost:3000>.

Au premier démarrage, le fichier `.env` est créé automatiquement avec un secret de
session aléatoire. Relancez `npm start` une seconde fois pour l'appliquer.

Créer votre compte administrateur :

```bash
node scripts/create-admin.js admin vous@exemple.com "UnMotDePasseSolide123" vous@faucetpay.io
```

Puis connectez-vous et ouvrez <http://localhost:3000/admin>.

Guide détaillé Windows : **[docs/INSTALLATION-WINDOWS.md](docs/INSTALLATION-WINDOWS.md)**

## 3. Configuration (`.env`)

| Variable | Rôle | Défaut |
|---|---|---|
| `PORT` | Port HTTP | `3000` |
| `SITE_URL` | URL publique (liens de parrainage) | `http://localhost:3000` |
| `SESSION_SECRET` | Signature des sessions (32+ car.) | généré |
| `COOKIE_SECURE` | Cookies HTTPS uniquement | `false` (⚠ `true` en prod) |
| `DB_PATH` | Fichier SQLite | `./data/btc-robinet.db` |
| `FAUCETPAY_MODE` | `mock` ou `faucetpay` | `mock` |
| `FAUCETPAY_API_VERSION` | `v1` ou `v2` | `v1` |
| `FAUCETPAY_API_KEY` | Clé du faucet (v1) | — |
| `FAUCETPAY_V2_READ_KEY` / `FAUCETPAY_V2_SEND_KEY` | Clés scoped (v2) | — |
| `PAYOUTS_LIVE` | **Verrou global des paiements réels** | `false` |
| `CAPTCHA_MODE` | `off`, `math`, `turnstile` | `math` |
| `TURNSTILE_SITE_KEY` / `TURNSTILE_SECRET_KEY` | Cloudflare Turnstile | — |

Les réglages métier (récompense, minuterie, quota, minimum de retrait, commission,
prix BTC) se modifient **en direct dans `/admin`** — pas besoin de redémarrer.

## 4. Intégration FaucetPay — comment elle est sécurisée

API officielle : <https://faucetpay.io/api-docs>

- Les clés ne sont **jamais** envoyées au navigateur : uniquement lues côté serveur
  (`src/services/faucetpay.js`).
- **Double verrou** : `FAUCETPAY_MODE=mock` (par défaut) **et** `PAYOUTS_LIVE=false`.
  Tant que les deux ne sont pas basculés, aucun appel `/send` n'est émis.
- **Idempotence** : chaque paiement porte une clé unique stockée en base (`UNIQUE`).
  Un double clic ou un rejeu réseau ne peut pas payer deux fois. En v2, cette clé est
  transmise à FaucetPay (`idempotency_key`).
- **Jamais de découvert** : avant tout envoi, le solde réel du faucet est demandé via
  `/getbalance` (v1) ou `/balance` (v2). Si insuffisant → refus, solde du membre intact.
- **Remboursement automatique** si FaucetPay refuse (codes 401/403/405/410/456/457).
  Erreur réseau/5xx → paiement marqué « à vérifier » (pas de remboursement aveugle,
  car le paiement a pu partir).
- **Journal d'audit** de chaque envoi et de chaque échec.
- Codes d'erreur FaucetPay traduits dans l'interface.

## 5. Structure du projet

```
btc-robinet/
├── src/
│   ├── server.js              # démarrage HTTP
│   ├── app.js                 # routes API + pages
│   ├── lib/                   # config, db, http, sécurité
│   └── services/              # auth, faucet, faucetpay, payout, referral, finance, antifraud, settings
├── public/                    # 12 pages HTML + CSS + JS (aucune dépendance externe)
├── db/schema.sql              # schéma complet (SQLite & D1)
├── scripts/                   # init-db.js, create-admin.js
├── worker/                    # Cloudflare Worker (index.mjs + schéma généré)
├── wrangler.toml              # configuration de déploiement Cloudflare
├── test/run-tests.js          # 129 tests serveur (npm test)
├── test/worker-smoke.mjs      # 13 tests chemin Worker/D1 (npm run test:worker)
├── data/                      # base SQLite (non versionnée)
└── docs/                      # installation, mise en ligne, partenaires, Cloudflare, tests
```

## 6. Sécurité en place

- Mots de passe : **scrypt** salé (jamais en clair, jamais renvoyés par l'API).
- Sessions : token 256 bits, cookie `HttpOnly` + `SameSite=Lax`, empreinte SHA-256 en base.
- **CSRF** obligatoire sur toutes les actions mutantes (`X-CSRF-Token`).
- Limitation de débit persistée en base : inscription, connexion, réclamation, retrait.
- Captcha serveur (calcul signé HMAC) ou Cloudflare Turnstile.
- Anti-fraude : emails jetables, variantes Gmail (`+tag`, points), multi-comptes par IP,
  score de risque, suspension automatique, blocage des clés API côté client.
- `MAX()`/bornes sur toutes les valeurs d'administration (pas de récompense absurde).
- Traversée de répertoire bloquée, en-têtes de sécurité HTTP.

## 7. Ce qui reste à faire (dans l'ordre)

1. **Vos comptes FaucetPay** : créer le compte faucet, obtenir la clé API,
   renseigner `FAUCETPAY_API_KEY`, tester avec `PAYOUTS_LIVE=false`, puis m'autoriser à
   ouvrir le verrou → **Étape 3 validée en réel**.
2. **Vos comptes partenaires** (shortlinks/offerwalls) : demander l'approbation du site,
   puis saisir dans `/admin` l'URL du réseau, le CPM réel et le secret de callback.
   Les modules fonctionnent déjà en mode démonstration (validation interne signée) pour
   que vous puissiez tester sans partenaire.
3. **Mise en ligne définitive** : `docs/MISE-EN-LIGNE.md` — option B (Cloudflare) est
   désormais **réalisable telle quelle** : `npm run build:worker` puis `npx wrangler deploy`.

## 8. Commandes utiles

```bash
npm start                      # serveur
npm run dev                    # avec rechargement (Node 18+)
npm test                       # 129 tests serveur + rapport JSON
npm run test:worker            # 13 tests du chemin Cloudflare Workers + D1
npm run build:worker           # régénère worker/schema.generated.js
npm run init-db                # (re)crée les tables
npm run create-admin -- pseudo email "motdepasse" adresse@faucetpay.io
```

## 8 bis. Dépôt Git

Le projet est versionné (branche `main`, `.gitignore` protégeant secrets et base) et
prêt à être poussé : voir **[docs/METTRE-SUR-GIT.md](docs/METTRE-SUR-GIT.md)**.
Un workflow GitHub Actions (`.github/workflows/ci.yml`) lance automatiquement les
142 contrôles (Node 20 et 22), et deux archives sont fournies :
`btc-robinet-source.zip` (code) et `btc-robinet-repo.bundle` (dépôt complet avec historique).

## 9. Avertissements honnêtes

- Un robinet Bitcoin **ne génère pas de revenus sans trafic** : les revenus viennent des
  shortlinks/offerwalls/publicités. Le calculateur de l'admin vous montre le point
  d'équilibre (par défaut, 25 sats/réclamation coûtent plus que ce qu'un visiteur
  rapporte : ajustez récompense et revenu/1000 points avec vos vrais chiffres).
- Les réseaux publicitaires **interdisent** les clics artificiels, les faux visiteurs et
  les bots. Ce projet n'en contient aucun et ne doit pas en contenir : cela entraînerait
  la fermeture de vos comptes partenaires.
- Vous êtes responsable de la conformité légale (mentions légales, RGPD, fiscalité) dans
  votre juridiction. La page `/legal` est un brouillon à compléter.
