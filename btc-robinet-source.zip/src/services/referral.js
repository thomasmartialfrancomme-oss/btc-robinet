'use strict';
/**
 * Service de parrainage.
 * - Chaque membre possède un code et un lien personnel.
 * - La commission est un pourcentage du gain du filleul (configurable).
 * - Protections : IP d'inscription identique (signalement), limite de filleuls
 *   par IP, comptes suspendus exclus du calcul.
 */
class ReferralService {
  constructor(db, settings, config) {
    this.db = db;
    this.settings = settings;
    this.config = config;
  }

  async summary(user, origin = null) {
    const cfg = await this.settings.all();
    const code = user.referral_code;
    // L'origine réelle de la requête est prioritaire : le site fonctionne ainsi
    // sur localhost, sur un domaine d'aperçu (proxy) et en production, sans
    // reconfiguration du lien de parrainage.
    const base = (origin || this.config.siteUrl || '').replace(/\/$/, '');
    const link = `${base}/register?ref=${encodeURIComponent(code)}`;
    const totals = await this.db.get(
      `SELECT COUNT(*) AS n, COALESCE(SUM(earned_sats),0) AS earned FROM referrals WHERE referrer_id = ?`, [user.id]
    );
    const active = await this.db.get(
      `SELECT COUNT(*) AS n FROM referrals r JOIN users u ON u.id = r.referred_id
       WHERE r.referrer_id = ? AND u.status = 'active'`, [user.id]
    );
    const today = await this.db.get(
      `SELECT COALESCE(SUM(amount_sats),0) AS sats FROM ledger
       WHERE user_id = ? AND type = 'referral_bonus' AND date(created_at) = date('now')`, [user.id]
    );
    return {
      enabled: Boolean(cfg.modules && cfg.modules.referral),
      code,
      link,
      percent: Number(cfg.referral_percent),
      total_referrals: totals.n,
      active_referrals: active.n,
      total_earned_sats: totals.earned,
      earned_today_sats: today.sats,
    };
  }

  /** Liste des filleuls (données limitées : pseudo, date, gains générés). */
  async listReferred(userId, limit = 100) {
    return this.db.all(
      `SELECT u.username, u.status, u.created_at, r.percent, r.earned_sats
       FROM referrals r JOIN users u ON u.id = r.referred_id
       WHERE r.referrer_id = ? ORDER BY r.id DESC LIMIT ?`, [userId, Math.min(300, limit)]
    );
  }

  async commissions(userId, limit = 100) {
    return this.db.all(
      `SELECT l.amount_sats, l.meta, l.created_at FROM ledger l
       WHERE l.user_id = ? AND l.type = 'referral_bonus' ORDER BY l.id DESC LIMIT ?`, [userId, Math.min(300, limit)]
    );
  }

  /** Contrôle anti-faux-comptes au moment de l'inscription (appelé par AuthService). */
  async checkReferralAbuse(referrerId, ip) {
    const row = await this.db.get(
      `SELECT COUNT(*) AS n FROM users WHERE referred_by = ? AND signup_ip = ? AND created_at >= datetime('now','-30 days')`,
      [referrerId, ip]
    );
    return { sameIpSignups: row ? row.n : 0, suspicious: Boolean(row && row.n >= 2) };
  }
}

module.exports = { ReferralService };
