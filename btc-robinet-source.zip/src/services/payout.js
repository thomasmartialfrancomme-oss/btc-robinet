'use strict';
/**
 * Service de retraits (FaucetPay).
 *
 * Flux d'un retrait :
 *   1. validations (compte actif, montant >= minimum, adresse vérifiée) ;
 *   2. vérification du solde FaucetPay réel (le site ne paie JAMAIS à découvert) ;
 *   3. débit atomique du solde interne + création du paiement "pending"
 *      portant une clé d'idempotence unique (UNIQUE en base) ;
 *   4. appel FaucetPay ;
 *   5. mise à jour du statut (sent / simulated / failed) + remboursement du
 *      solde interne si l'appel échoue.
 *
 * Protections :
 *   - clé d'idempotence : un rejeu (double clic, retry réseau) ne peut pas créer
 *     un second débit ;
 *   - verrou par membre (pas de retraits concurrents) ;
 *   - rate limiting par membre et par IP ;
 *   - remboursement automatique en cas d'échec confirmé.
 */
const crypto = require('node:crypto');

class PayoutError extends Error {
  constructor(message, { status = 400, code = 'payout_error', details } = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

class PayoutService {
  constructor(db, settings, faucetpay, config) {
    this.db = db;
    this.settings = settings;
    this.faucetpay = faucetpay;
    this.config = config;
    this.locks = new Set();
  }

  /** Vérifie l'adresse FaucetPay du membre et enregistre son hash. */
  async verifyAddress(user, address = null) {
    const target = String(address || user.payout_address || '').trim();
    if (target.length < 3) throw new PayoutError('Adresse FaucetPay manquante.');
    const res = await this.faucetpay.checkAddress(target, 'BTC');
    if (!res.valid) throw new PayoutError('Adresse FaucetPay non valide ou compte inexistant.', { status: 422, code: 'bad_address' });
    await this.db.run('UPDATE users SET payout_address = ?, payout_hash = ? WHERE id = ?', [target, res.payout_user_hash, user.id]);
    return { address: target, hash: res.payout_user_hash, simulated: res.simulated, message: res.message };
  }

  /** Solde du faucet chez FaucetPay (satoshis) + état du verrou de paiement. */
  async getProviderStatus(currency = 'BTC') {
    try {
      const res = await this.faucetpay.getBalance(currency);
      return {
        ok: true,
        balance_sats: res.balance_sats,
        simulated: res.simulated,
        live: this.faucetpay.live,
        mode: this.faucetpay.mode,
        api_version: this.config.faucetpay.apiVersion,
      };
    } catch (e) {
      return {
        ok: false,
        error: e.message,
        status: e.status || null,
        simulated: this.faucetpay.mode === 'mock',
        live: this.faucetpay.live,
        mode: this.faucetpay.mode,
        api_version: this.config.faucetpay.apiVersion,
      };
    }
  }

  /**
   * Demande de retrait.
   * @param {object} user
   * @param {object} p { amountSats, ip, userAgent, idempotencyKey? }
   */
  async requestWithdraw(user, { amountSats, ip, userAgent, idempotencyKey = null }) {
    if (this.locks.has(user.id)) {
      throw new PayoutError('Un retrait est déjà en cours pour ce compte.', { status: 429, code: 'in_progress' });
    }
    this.locks.add(user.id);
    try {
      const cfg = await this.settings.all();
      if (user.status !== 'active') throw new PayoutError('Compte non actif.', { status: 403, code: 'status' });

      const amount = Math.floor(Number(amountSats));
      if (!Number.isFinite(amount) || amount <= 0) throw new PayoutError('Montant invalide.');
      const min = Number(cfg.min_withdraw_sats);
      if (amount < min) throw new PayoutError(`Le minimum de retrait est de ${min} satoshis.`, { status: 422, code: 'below_min', details: { min } });

      // --- Rate limiting : 5 retraits / heure et 1 / 2 minutes --------------
      const lastHour = await this.db.get(
        `SELECT COUNT(*) AS n FROM payouts WHERE user_id = ? AND created_at >= datetime('now','-1 hour')`, [user.id]
      );
      if (lastHour && lastHour.n >= 5) {
        throw new PayoutError('Trop de retraits sur la dernière heure. Réessayez plus tard.', { status: 429, code: 'rate_limit' });
      }
      const lastAny = await this.db.get(
        `SELECT created_at FROM payouts WHERE user_id = ? ORDER BY id DESC LIMIT 1`, [user.id]
      );
      if (lastAny) {
        const ts = Date.parse(lastAny.created_at.replace(' ', 'T') + 'Z');
        const wait = Math.ceil((ts + 120000 - Date.now()) / 1000);
        if (wait > 0) throw new PayoutError(`Attendez ${wait} s avant un nouveau retrait.`, { status: 429, code: 'cooldown', details: { retry_after: wait } });
      }

      // --- Solde interne --------------------------------------------------
      const fresh = await this.db.get('SELECT balance_sats, payout_address, payout_hash FROM users WHERE id = ?', [user.id]);
      if (!fresh || fresh.balance_sats < amount) {
        throw new PayoutError(`Solde insuffisant (${fresh ? fresh.balance_sats : 0} sats disponibles).`, {
          status: 422, code: 'insufficient_balance', details: { balance_sats: fresh ? fresh.balance_sats : 0 },
        });
      }
      if (!fresh.payout_address) throw new PayoutError('Adresse FaucetPay requise avant tout retrait.', { status: 422, code: 'no_address' });

      // --- Solde FaucetPay réel : on ne paie jamais sans financement -------
      const provider = await this.getProviderStatus('BTC');
      if (provider.ok && !provider.simulated && provider.balance_sats < amount) {
        throw new PayoutError('Le faucet n\'a pas assez de fonds disponibles pour ce retrait. Réessayez plus tard.', {
          status: 503, code: 'provider_insufficient_funds',
          details: { provider_balance_sats: provider.balance_sats, requested_sats: amount },
        });
      }
      if (!provider.ok && !provider.simulated) {
        throw new PayoutError('Impossible de vérifier le solde FaucetPay. Retrait suspendu par sécurité.', {
          status: 503, code: 'provider_unreachable', details: { provider_error: provider.error },
        });
      }

      // --- Débit atomique + création du paiement --------------------------
      const key = idempotencyKey
        ? String(idempotencyKey).slice(0, 80)
        : `wd_${user.id}_${amount}_${crypto.randomBytes(8).toString('hex')}`;

      // Rejeu d'une clé déjà utilisée : on renvoie le paiement existant (aucun nouveau débit)
      const existingPayout = await this.db.get('SELECT * FROM payouts WHERE idempotency_key = ?', [key]);
      if (existingPayout) {
        return { duplicate: true, payout: this.publicPayout(existingPayout) };
      }

      const created = await this.db.atomic((tx) => {
        // Débit CONDITIONNEL : aucune ligne modifiée ⇒ solde insuffisant.
        const debit = tx.run(
          `UPDATE users SET balance_sats = balance_sats - ?, updated_at = datetime('now')
           WHERE id = ? AND balance_sats >= ? AND status = 'active'`,
          [amount, user.id, amount]
        );
        if (debit.changes === 0) {
          throw new PayoutError('Solde insuffisant (contrôle final) ou compte inactif.', {
            status: 422, code: 'insufficient_balance',
          });
        }
        let ins;
        try {
          ins = tx.run(
            `INSERT INTO payouts (user_id, amount_sats, currency, destination, status, mode, idempotency_key, ip)
             VALUES (?, ?, 'BTC', ?, 'pending', ?, ?, ?)`,
            [user.id, amount, fresh.payout_address, this.faucetpay.live ? 'faucetpay' : 'mock', key, ip]
          );
        } catch (e) {
          if (String(e.message).includes('UNIQUE')) {
            throw new PayoutError('Cette demande de retrait a déjà été enregistrée.', { status: 409, code: 'duplicate' });
          }
          throw e;
        }
        tx.run(
          `INSERT INTO ledger (user_id, type, module, amount_sats, balance_after, meta)
           VALUES (?, 'debit_payout', 'withdraw', ?,
                   (SELECT balance_sats FROM users WHERE id = ?), ?)`,
          [user.id, -amount, user.id, JSON.stringify({ payout_id: ins.lastInsertRowid, idempotency_key: key })]
        );
        return { duplicate: false, payoutId: ins.lastInsertRowid };
      });

      if (created.duplicate) {
        const p = await this.db.get('SELECT * FROM payouts WHERE id = ?', [created.payoutId]);
        return { duplicate: true, payout: this.publicPayout(p) };
      }

      // --- Appel FaucetPay -------------------------------------------------
      // On relit l'identifiant via la clé d'idempotence (unique) plutôt que via
      // lastInsertRowid : comportement identique en SQLite et en D1 (batch).
      const saved = await this.db.get('SELECT id FROM payouts WHERE idempotency_key = ?', [key]);
      if (!saved) throw new PayoutError('Paiement non enregistré (état incohérent).', { status: 500, code: 'inconsistent' });
      return await this.executePayout(saved.id, { ip, userAgent });
    } finally {
      this.locks.delete(user.id);
    }
  }

  /** Exécute (ou rejoue) l'envoi d'un paiement existant vers FaucetPay. */
  async executePayout(payoutId, { ip = null, userAgent = null } = {}) {
    const payout = await this.db.get('SELECT * FROM payouts WHERE id = ?', [payoutId]);
    if (!payout) throw new PayoutError('Paiement introuvable.', { status: 404 });
    if (['sent', 'simulated'].includes(payout.status)) {
      return { duplicate: true, payout: this.publicPayout(payout) };
    }

    try {
      const res = await this.faucetpay.sendPayout({
        idempotencyKey: payout.idempotency_key,
        to: payout.destination,
        amountSats: payout.amount_sats,
        currency: payout.currency,
        ip: payout.ip || ip || undefined,
      });

      const status = res.simulated ? 'simulated' : 'sent';
      await this.db.run(
        `UPDATE payouts SET status = ?, mode = ?, provider_payout_id = ?, provider_hash = ?, provider_message = ?,
           provider_status = 200, updated_at = datetime('now') WHERE id = ?`,
        [status, res.simulated ? 'mock' : 'faucetpay', res.payout_id || null, res.payout_user_hash || null, res.message || null, payoutId]
      );
      await this.db.run(
        `UPDATE users SET total_paid_sats = total_paid_sats + ? WHERE id = ?`, [payout.amount_sats, payout.user_id]
      );
      await this.db.run(
        `INSERT INTO audit_log (actor_id, action, target, meta) VALUES (?, 'payout_sent', ?, ?)`,
        [payout.user_id, String(payoutId), JSON.stringify({ status, mode: res.simulated ? 'mock' : 'faucetpay', provider_id: res.payout_id })]
      );

      const updated = await this.db.get('SELECT * FROM payouts WHERE id = ?', [payoutId]);
      return { duplicate: false, payout: this.publicPayout(updated) };
    } catch (err) {
      // Refus CONFIRMÉ par le fournisseur (4xx) => remboursement immédiat.
      // Erreur réseau / 5xx => statut "failed" mais marqué à vérifier
      // manuellement (le paiement a peut-être été accepté côté FaucetPay).
      const confirmedRejection = [401, 403, 405, 410, 456, 457].includes(err.status);
      const newStatus = confirmedRejection ? 'failed' : 'failed';
      await this.db.run(
        `UPDATE payouts SET status = ?, provider_status = ?, provider_message = ?, updated_at = datetime('now') WHERE id = ?`,
        [newStatus, err.status || null, String(err.message).slice(0, 400), payoutId]
      );

      if (confirmedRejection) {
        await this.db.atomic((tx) => {
          // Remboursement conditionnel : uniquement si le paiement est bien en échec
          const refunded = tx.run(
            `UPDATE users SET balance_sats = balance_sats + ?
             WHERE id = ? AND EXISTS (SELECT 1 FROM payouts WHERE id = ? AND status = 'failed')`,
            [payout.amount_sats, payout.user_id, payoutId]
          );
          if (refunded.changes === 0) return;
          tx.run(
            `INSERT INTO ledger (user_id, type, module, amount_sats, balance_after, meta)
             VALUES (?, 'refund', 'withdraw', ?, (SELECT balance_sats FROM users WHERE id = ?), ?)`,
            [payout.user_id, payout.amount_sats, payout.user_id,
             JSON.stringify({ payout_id: payoutId, reason: err.message })]
          );
        });
      }

      await this.db.run(
        `INSERT INTO audit_log (actor_id, action, target, meta) VALUES (?, 'payout_failed', ?, ?)`,
        [payout.user_id, String(payoutId), JSON.stringify({ status: err.status || null, message: err.message, refunded: confirmedRejection })]
      );

      throw new PayoutError(
        confirmedRejection
          ? `Paiement refusé par FaucetPay (${err.message}). Montant recrédité sur votre solde.`
          : `Paiement en erreur (${err.message}). Le montant n'est pas perdu : contactez le support.`,
        { status: 502, code: 'provider_error', details: { provider_status: err.status || null, refunded: confirmedRejection } }
      );
    }
  }

  /** Historique des retraits d'un membre. */
  async history(userId, limit = 30) {
    const rows = await this.db.all(
      `SELECT id, amount_sats, currency, destination, status, mode, provider_payout_id, provider_message, created_at
       FROM payouts WHERE user_id = ? ORDER BY id DESC LIMIT ?`,
      [userId, Math.min(100, Math.max(1, limit))]
    );
    const totals = await this.db.get(
      `SELECT COUNT(*) AS n, COALESCE(SUM(CASE WHEN status IN ('sent','simulated') THEN amount_sats ELSE 0 END),0) AS paid
       FROM payouts WHERE user_id = ?`, [userId]
    );
    return { items: rows, total_count: totals.n, total_paid_sats: totals.paid };
  }

  /** Tous les retraits (administration). */
  async adminList({ limit = 50, status = null } = {}) {
    const params = [];
    let where = '';
    if (status) { where = 'WHERE p.status = ?'; params.push(status); }
    params.push(Math.min(200, Math.max(1, limit)));
    const rows = await this.db.all(
      `SELECT p.*, u.username AS username FROM payouts p JOIN users u ON u.id = p.user_id
       ${where} ORDER BY p.id DESC LIMIT ?`, params
    );
    return rows.map((r) => ({ ...this.publicPayout(r), username: r.username }));
  }

  publicPayout(p) {
    if (!p) return null;
    return {
      id: p.id,
      user_id: p.user_id,
      amount_sats: p.amount_sats,
      currency: p.currency,
      destination: p.destination,
      status: p.status,
      mode: p.mode,
      provider_payout_id: p.provider_payout_id,
      provider_message: p.provider_message,
      created_at: p.created_at,
      updated_at: p.updated_at,
      simulated: p.status === 'simulated' || p.mode === 'mock',
    };
  }
}

module.exports = { PayoutService, PayoutError };
