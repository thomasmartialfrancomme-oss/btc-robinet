'use strict';
/**
 * Service du robinet BTC.
 *
 * Règles appliquées (toutes vérifiées AVANT tout crédit) :
 *   1. compte actif + module robinet activé ;
 *   2. cooldown respecté (contrôle atomique en base) ;
 *   3. quota journalier respecté ;
 *   4. anti-double-réclamation (nonce + verrou anti-concurrence par membre) ;
 *   5. récompense bornée par les règles de sécurité (jamais de montant farfelu) ;
 *   6. bonus de série (streak) plafonné.
 *
 *  Tout crédit passe par le grand livre (`ledger`) dans la même transaction.
 */
const crypto = require('node:crypto');
const { AntifraudService } = require('./antifraud');

const MIN_REWARD = 1;
const MAX_REWARD = 100000;      // garde-fou : 100 000 sats maximum par réclamation
const MAX_STREAK_BONUS_PERCENT = 50;

class FaucetError extends Error {
  constructor(message, { status = 400, code = 'faucet_error', details } = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

class FaucetService {
  constructor(db, settings, faucetpay, config, antifraud = null) {
    this.db = db;
    this.settings = settings;
    this.faucetpay = faucetpay;
    this.config = config;
    this.antifraud = antifraud || new AntifraudService(db, settings);
    // Verrou anti-concurrence : une seule réclamation simultanée par membre
    this.locks = new Set();
  }

  /** État complet du robinet pour l'interface. */
  async getState(user, { ip = null } = {}) {
    const cfg = await this.settings.all();
    const last = await this.db.get(
      `SELECT created_at, amount_sats FROM claims WHERE user_id = ? AND module = 'faucet' AND status = 'credited'
       ORDER BY id DESC LIMIT 1`,
      [user.id]
    );
    const today = await this.db.get(
      `SELECT COUNT(*) AS n, COALESCE(SUM(amount_sats),0) AS sats FROM claims
       WHERE user_id = ? AND module = 'faucet' AND status = 'credited' AND date(created_at) = date('now')`,
      [user.id]
    );
    const lastTs = last ? Date.parse(last.created_at.replace(' ', 'T') + 'Z') : 0;
    const readyAt = lastTs ? lastTs + cfg.faucet_cooldown_seconds * 1000 : 0;
    const now = Date.now();
    const enabled = Boolean(cfg.modules && cfg.modules.faucet) && user.status === 'active';
    return {
      enabled,
      maintenance: Boolean(cfg.maintenance && cfg.maintenance.enabled),
      reward_sats: cfg.faucet_reward_sats,
      cooldown_seconds: cfg.faucet_cooldown_seconds,
      daily_limit: cfg.faucet_daily_limit,
      claims_today: today ? today.n : 0,
      earned_today_sats: today ? today.sats : 0,
      remaining_today: Math.max(0, cfg.faucet_daily_limit - (today ? today.n : 0)),
      balance_sats: user.balance_sats,
      min_withdraw_sats: cfg.min_withdraw_sats,
      last_claim_at: last ? last.created_at : null,
      next_claim_in: Math.max(0, Math.ceil((readyAt - now) / 1000)),
      notes: cfg.faucet_notes,
      streak_days: await this.getStreak(user.id),
      module_ready: true,
    };
  }

  /** Nombre de jours consécutifs avec au moins une réclamation. */
  async getStreak(userId) {
    const rows = await this.db.all(
      `SELECT DISTINCT date(created_at) AS d FROM claims
       WHERE user_id = ? AND module = 'faucet' AND status = 'credited'
       ORDER BY d DESC LIMIT 40`,
      [userId]
    );
    if (!rows.length) return 0;
    let streak = 0;
    let cursor = new Date();
    const days = new Set(rows.map((r) => r.d));
    const todayKey = cursor.toISOString().slice(0, 10);
    const yesterday = new Date(cursor.getTime() - 86400000).toISOString().slice(0, 10);
    // La série n'est comptée que si aujourd'hui ou hier a une réclamation
    if (!days.has(todayKey) && !days.has(yesterday)) return 0;
    let probe = days.has(todayKey) ? cursor : new Date(cursor.getTime() - 86400000);
    while (days.has(probe.toISOString().slice(0, 10))) {
      streak += 1;
      probe = new Date(probe.getTime() - 86400000);
    }
    return streak;
  }

  /** Calcule la récompense (montant configurable + bonus de série plafonné). */
  async computeReward(userId) {
    const cfg = await this.settings.all();
    let reward = Number(cfg.faucet_reward_sats);
    if (!Number.isFinite(reward)) reward = this.config.defaults.faucetRewardSats;
    reward = Math.max(MIN_REWARD, Math.min(MAX_REWARD, Math.round(reward)));

    const streak = await this.getStreak(userId);
    const bonusPercent = Math.min(MAX_STREAK_BONUS_PERCENT, Math.max(0, streak - 1) * 5); // +5 %/jour, max +50 %
    const bonus = Math.round((reward * bonusPercent) / 100);
    return { base: reward, bonus, bonus_percent: bonusPercent, total: reward + bonus, streak };
  }

  /**
   * Réclame des satoshis.
   * @returns {{amount_sats:number, balance_sats:number, ...}}
   */
  async claim(user, { ip, userAgent, nonce }) {
    if (this.locks.has(user.id)) {
      throw new FaucetError('Une réclamation est déjà en cours pour ce compte.', { status: 429, code: 'in_progress' });
    }
    this.locks.add(user.id);
    try {
      const cfg = await this.settings.all();
      if (!cfg.modules || !cfg.modules.faucet) {
        throw new FaucetError('Le robinet est temporairement désactivé.', { status: 503, code: 'module_off' });
      }
      if (cfg.maintenance && cfg.maintenance.enabled) {
        throw new FaucetError(cfg.maintenance.message, { status: 503, code: 'maintenance' });
      }
      if (user.status !== 'active') {
        throw new FaucetError('Compte non actif.', { status: 403, code: 'status' });
      }

      // --- Contrôles anti-double réclamation ------------------------------
      const cleanNonce = String(nonce || '').slice(0, 80);
      if (cleanNonce) {
        const dup = await this.db.get('SELECT id FROM claims WHERE user_id = ? AND nonce = ?', [user.id, cleanNonce]);
        if (dup) throw new FaucetError('Réclamation déjà enregistrée (double soumission bloquée).', { status: 409, code: 'duplicate_nonce' });
      }

      const last = await this.db.get(
        `SELECT created_at FROM claims WHERE user_id = ? AND module = 'faucet' AND status = 'credited'
         ORDER BY id DESC LIMIT 1`,
        [user.id]
      );
      if (last) {
        const lastTs = Date.parse(last.created_at.replace(' ', 'T') + 'Z');
        const wait = Math.ceil((lastTs + cfg.faucet_cooldown_seconds * 1000 - Date.now()) / 1000);
        if (wait > 0) {
          throw new FaucetError(`Patientez encore ${wait} seconde(s).`, {
            status: 429, code: 'cooldown', details: { retry_after: wait },
          });
        }
      }

      const today = await this.db.get(
        `SELECT COUNT(*) AS n FROM claims WHERE user_id = ? AND module = 'faucet' AND status = 'credited'
         AND date(created_at) = date('now')`,
        [user.id]
      );
      if (today && today.n >= cfg.faucet_daily_limit) {
        throw new FaucetError('Limite journalière de réclamations atteinte. Revenez demain.', {
          status: 429, code: 'daily_limit', details: { limit: cfg.faucet_daily_limit },
        });
      }

      // --- Anti-fraude (notation, non bloquant sauf score extrême) ---------
      const score = await this.antifraud.scoreClaim({ userId: user.id, ip, userAgent });
      if (score.risk >= 100) {
        throw new FaucetError('Activité anormale détectée. Réclamation bloquée.', { status: 403, code: 'antifraud', details: score.reasons });
      }

      // --- Garde-fou de financement : solde faucet FaucetPay --------------
      // Le solde du faucet est vérifié par un appel FaucetPay avant de payer
      // (contrôle non bloquant ici : il bloque les retraits, pas les crédits,
      //  car les crédits sont des points internes mis en file de paiement).
      const reward = await this.computeReward(user.id);

      // --- Écriture atomique (portable SQLite ↔ D1) ----------------------
      // Aucune lecture dans la transaction : l'unicité est garantie par
      //   (a) l'index UNIQUE (user_id, nonce)  → anti-double-soumission
      //   (b) l'index UNIQUE (user_id, claim_slot) → une seule réclamation
      //       par fenêtre de cooldown, calculée ici sans lecture.
      const slot = Math.floor(Date.now() / (cfg.faucet_cooldown_seconds * 1000));
      const lid = crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex');

      const result = await this.db.atomic((tx) => {
        let inserted;
        try {
          inserted = tx.run(
            `INSERT INTO claims (user_id, module, amount_sats, ip, user_agent, nonce, claim_slot, ledger_ref, status)
             SELECT ?, 'faucet', ?, ?, ?, ?, ?, ?, 'credited'
             WHERE NOT EXISTS (SELECT 1 FROM claims WHERE user_id = ? AND module = 'faucet' AND claim_slot = ?)`,
            [user.id, reward.total, ip, String(userAgent || '').slice(0, 250), cleanNonce || null, slot, lid, user.id, slot]
          );
        } catch (e) {
          if (String(e.message).includes('UNIQUE')) {
            throw new FaucetError('Réclamation déjà effectuée sur cette période (protection anti-double).', {
              status: 429, code: 'cooldown',
            });
          }
          throw e;
        }

        // Le crédit n'est appliqué que si la réclamation vient d'être créée (lid)
        const debit = tx.run(
          `UPDATE users SET balance_sats = balance_sats + ?, total_earned_sats = total_earned_sats + ?,
             last_ip = ?, updated_at = datetime('now')
           WHERE id = ? AND EXISTS (SELECT 1 FROM claims WHERE ledger_ref = ?)`,
          [reward.total, reward.total, ip, user.id, lid]
        );
        if (debit.changes === 0) {
          throw new FaucetError('Réclamation déjà effectuée sur cette période (protection anti-double).', {
            status: 429, code: 'cooldown',
          });
        }

        // Commission de parrainage : % du gain (crédit conditionnel au filleul existant)
        tx.run(
          `UPDATE users SET balance_sats = balance_sats + CAST(? * r.percent / 100 AS INTEGER),
             total_earned_sats = total_earned_sats + CAST(? * r.percent / 100 AS INTEGER)
           FROM referrals r
           WHERE r.referred_id = ? AND users.id = r.referrer_id AND ? = 1`,
          [reward.total, reward.total, user.id, cfg.modules && cfg.modules.referral ? 1 : 0]
        );
        tx.run(
          `UPDATE referrals SET earned_sats = earned_sats + CAST(? * percent / 100 AS INTEGER)
           WHERE referred_id = ? AND ? = 1`,
          [reward.total, user.id, cfg.modules && cfg.modules.referral ? 1 : 0]
        );
        tx.run(
          `INSERT INTO ledger (user_id, type, module, amount_sats, balance_after, meta)
           SELECT r.referrer_id, 'referral_bonus', 'referral', CAST(? * r.percent / 100 AS INTEGER),
                  (SELECT balance_sats FROM users WHERE id = r.referrer_id), ?
           FROM referrals r WHERE r.referred_id = ? AND CAST(? * r.percent / 100 AS INTEGER) > 0 AND ? = 1`,
          [reward.total, JSON.stringify({ from_user: user.id, amount: reward.total }),
           user.id, reward.total, cfg.modules && cfg.modules.referral ? 1 : 0]
        );
        tx.run(
          `INSERT INTO ledger (user_id, type, module, amount_sats, balance_after, meta, ref)
           VALUES (?, 'credit_reward', 'faucet', ?,
                   (SELECT balance_sats FROM users WHERE id = ?), ?, ?)`,
          [user.id, reward.total, user.id,
           JSON.stringify({ base: reward.base, bonus: reward.bonus, streak: reward.streak }), lid]
        );
        return { claimId: inserted.lastInsertRowid };
      });

      const fresh = await this.db.get('SELECT balance_sats FROM users WHERE id = ?', [user.id]);
      const ref = await this.db.get(
        `SELECT r.referrer_id, r.percent, CAST(? * r.percent / 100 AS INTEGER) AS commission
         FROM referrals r WHERE r.referred_id = ?`, [reward.total, user.id]
      );

      await this.antifraud.applyRisk(user.id, 0, score.reasons);

      return {
        claim_id: result.claimId,
        amount_sats: reward.total,
        base_sats: reward.base,
        bonus_sats: reward.bonus,
        bonus_percent: reward.bonus_percent,
        streak_days: reward.streak,
        balance_sats: fresh ? fresh.balance_sats : null,
        referral: ref ? { referrer_id: ref.referrer_id, commission_sats: ref.commission, percent: ref.percent } : null,
        next_claim_in: cfg.faucet_cooldown_seconds,
        claimed_at: new Date().toISOString(),
      };
    } finally {
      this.locks.delete(user.id);
    }
  }

  /** Historique des réclamations d'un membre. */
  async history(userId, limit = 50, offset = 0) {
    const rows = await this.db.all(
      `SELECT id, module, amount_sats, status, ip, created_at FROM claims
       WHERE user_id = ? ORDER BY id DESC LIMIT ? OFFSET ?`,
      [userId, Math.min(200, Math.max(1, limit)), Math.max(0, offset)]
    );
    const totals = await this.db.get(
      `SELECT COUNT(*) AS n, COALESCE(SUM(amount_sats),0) AS sats FROM claims WHERE user_id = ? AND status = 'credited'`,
      [userId]
    );
    return { items: rows, total_count: totals.n, total_sats: totals.sats };
  }

  /** Statistiques globales pour l'administration. */
  async stats(period = 'day') {
    const since = period === 'day' ? "-1 day" : period === 'week' ? "-7 days" : "-30 days";
    const claims = await this.db.get(
      `SELECT COUNT(*) AS n, COALESCE(SUM(amount_sats),0) AS sats FROM claims
       WHERE status = 'credited' AND created_at >= datetime('now', ?)`, [since]
    );
    const users = await this.db.get(
      `SELECT COUNT(*) AS n FROM users WHERE created_at >= datetime('now', ?)`, [since]
    );
    const active = await this.db.get(
      `SELECT COUNT(DISTINCT user_id) AS n FROM claims WHERE created_at >= datetime('now', ?)`, [since]
    );
    const pending = await this.db.get(
      `SELECT COALESCE(SUM(balance_sats),0) AS sats FROM users WHERE balance_sats > 0`
    );
    return {
      period,
      claims: claims.n,
      reward_sats: claims.sats,
      new_users: users.n,
      active_users: active.n,
      total_liability_sats: pending.sats,
    };
  }
}

module.exports = { FaucetService, FaucetError, MIN_REWARD, MAX_REWARD };
