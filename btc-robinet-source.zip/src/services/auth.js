'use strict';
/**
 * Authentification : inscription, connexion, sessions, CSRF.
 *
 * - Mots de passe : scrypt salé (jamais stockés en clair).
 * - Sessions : token aléatoire envoyé dans un cookie HttpOnly ; seule son
 *   empreinte SHA-256 est stockée en base.
 * - CSRF : jeton lié à la session, requis sur toutes les requêtes mutantes.
 */
const { hashPassword, verifyPassword, sha256, randomToken, randomCode, safeEqual } = require('../lib/security');
const { AntifraudService } = require('./antifraud');

const USERNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/;

class AuthError extends Error {
  constructor(message, { status = 400, code = 'auth_error', details } = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

class AuthService {
  constructor(db, settings, config, antifraud = null) {
    this.db = db;
    this.settings = settings;
    this.config = config;
    this.antifraud = antifraud || new AntifraudService(db, settings);
  }

  /* --------------------------- Inscription -------------------------- */

  async register({ username, email, password, payoutAddress, refCode, ip, userAgent }) {
    username = String(username || '').trim();
    email = String(email || '').trim().toLowerCase();
    payoutAddress = String(payoutAddress || '').trim();

    if (!USERNAME_RE.test(username)) {
      throw new AuthError('Le nom d\'utilisateur doit faire 3 à 20 caractères (lettres, chiffres, _).');
    }
    if (!EMAIL_RE.test(email)) throw new AuthError('Adresse email invalide.');
    if (String(password || '').length < 8) throw new AuthError('Le mot de passe doit contenir au moins 8 caractères.');
    if (payoutAddress.length < 3) throw new AuthError('Adresse FaucetPay (email ou pseudo) requise pour être payé.');

    // Doublon strict (rapide, message explicite) avant les contrôles avancés
    const exists = await this.db.get('SELECT id FROM users WHERE lower(username) = lower(?) OR email = ?', [username, email]);
    if (exists) throw new AuthError('Ce nom d\'utilisateur ou cet email est déjà utilisé.', { status: 409, code: 'duplicate' });

    const fraud = await this.antifraud.checkSignup({ email, username, ip, userAgent });
    if (!fraud.allowed) {
      throw new AuthError('Inscription refusée par le contrôle antifraude.', {
        status: 403, code: 'antifraud', details: fraud.reasons,
      });
    }

    let referrer = null;
    if (refCode) {
      referrer = await this.db.get('SELECT id FROM users WHERE referral_code = ? AND status = \'active\'', [String(refCode).toUpperCase()]);
    }

    let code = randomCode(7);
    for (let i = 0; i < 5; i++) {
      const taken = await this.db.get('SELECT id FROM users WHERE referral_code = ?', [code]);
      if (!taken) break;
      code = randomCode(7);
    }

    const result = await this.db.run(
      `INSERT INTO users (username, email, password_hash, payout_address, referral_code, referred_by, signup_ip, last_ip, risk_score)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [username, email, await hashPassword(password), payoutAddress, code, referrer ? referrer.id : null, ip, ip, fraud.risk]
    );

    const userId = result.lastInsertRowid;

    if (referrer) {
      const percent = Number(await this.settings.get('referral_percent', 20));
      await this.db.run(
        'INSERT OR IGNORE INTO referrals (referrer_id, referred_id, percent) VALUES (?, ?, ?)',
        [referrer.id, userId, percent]
      );
    }

    await this.db.run(
      `INSERT INTO audit_log (actor_id, action, target, meta, ip) VALUES (?, 'register', ?, ?, ?)`,
      [userId, String(userId), JSON.stringify({ referrer: referrer ? referrer.id : null, risk: fraud.risk }), ip]
    );

    return this.getUserById(userId);
  }

  /* ---------------------------- Connexion -------------------------- */

  async login({ login, password, ip, userAgent }) {
    login = String(login || '').trim();
    const user = await this.db.get(
      'SELECT * FROM users WHERE lower(username) = lower(?) OR email = lower(?)',
      [login, login]
    );

    // Comparaison de mot de passe même si l'utilisateur n'existe pas (temps constant)
    const dummyHash = 'scrypt$16384$8$1$AAAAAAAAAAAAAAAAAAAAAA==$AAAA';
    const ok = await verifyPassword(String(password || ''), user ? user.password_hash : dummyHash);

    if (!user || !ok) {
      await this.db.run(
        `INSERT INTO audit_log (actor_id, action, target, meta, ip) VALUES (NULL, 'login_failed', ?, ?, ?)`,
        [login.slice(0, 64), null, ip]
      );
      throw new AuthError('Identifiants incorrects.', { status: 401, code: 'bad_credentials' });
    }
    if (user.status === 'banned') throw new AuthError('Ce compte est banni.', { status: 403, code: 'banned' });
    if (user.status === 'suspended') throw new AuthError('Compte suspendu. Contactez le support.', { status: 403, code: 'suspended' });

    await this.db.run('UPDATE users SET last_login_at = datetime(\'now\'), last_ip = ? WHERE id = ?', [ip, user.id]);

    const session = await this.createSession(user.id, ip, userAgent);
    await this.db.run(
      `INSERT INTO audit_log (actor_id, action, target, ip) VALUES (?, 'login', ?, ?)`,
      [user.id, String(user.id), ip]
    );
    return { user, session };
  }

  /* ---------------------------- Sessions --------------------------- */

  async createSession(userId, ip, userAgent, ttlHours = null) {
    const token = randomToken(32);
    const ttl = ttlHours || this.config.sessionTtlHours;
    const expires = new Date(Date.now() + ttl * 3600 * 1000).toISOString().slice(0, 19).replace('T', ' ');
    await this.db.run(
      'INSERT INTO sessions (id, user_id, ip, user_agent, expires_at) VALUES (?, ?, ?, ?, ?)',
      [sha256(token), userId, ip, String(userAgent || '').slice(0, 250), expires]
    );
    await this.db.run('DELETE FROM sessions WHERE expires_at < datetime(\'now\')');
    return { token, csrf: sha256('csrf:' + token).slice(0, 40), expires };
  }

  /** Résout une session à partir du token du cookie. */
  async resolveSession(token) {
    if (!token) return null;
    const id = sha256(token);
    const row = await this.db.get(
      `SELECT s.id AS session_id, s.expires_at, u.*
       FROM sessions s JOIN users u ON u.id = s.user_id
       WHERE s.id = ? AND s.expires_at > datetime('now')`,
      [id]
    );
    if (!row) return null;
    if (row.status !== 'active' && row.role !== 'admin') return null;
    const user = this.sanitize(row);
    return { user, sessionId: id, csrf: sha256('csrf:' + token).slice(0, 40), exp: row.expires_at };
  }

  async destroySession(token) {
    if (!token) return;
    await this.db.run('DELETE FROM sessions WHERE id = ?', [sha256(token)]);
  }

  async destroyAllSessions(userId) {
    await this.db.run('DELETE FROM sessions WHERE user_id = ?', [userId]);
  }

  sanitize(row) {
    if (!row) return null;
    return {
      id: row.id,
      username: row.username,
      email: row.email,
      payout_address: row.payout_address,
      payout_hash: row.payout_hash,
      balance_sats: row.balance_sats,
      total_earned_sats: row.total_earned_sats,
      total_paid_sats: row.total_paid_sats,
      referral_code: row.referral_code,
      referred_by: row.referred_by,
      role: row.role,
      status: row.status,
      risk_score: row.risk_score,
      created_at: row.created_at,
    };
  }

  async getUserById(id) {
    const row = await this.db.get('SELECT * FROM users WHERE id = ?', [id]);
    return this.sanitize(row);
  }

  /* ----------------------------- CSRF ------------------------------ */

  verifyCsrf(session, token) {
    return Boolean(session && token && safeEqual(session.csrf, String(token)));
  }

  /* ------------------------ Mot de passe --------------------------- */

  async changePassword(userId, currentPassword, newPassword) {
    const row = await this.db.get('SELECT password_hash FROM users WHERE id = ?', [userId]);
    if (!row || !(await verifyPassword(currentPassword, row.password_hash))) {
      throw new AuthError('Mot de passe actuel incorrect.', { status: 401 });
    }
    if (String(newPassword).length < 8) throw new AuthError('Nouveau mot de passe trop court (8 caractères minimum).');
    await this.db.run('UPDATE users SET password_hash = ?, updated_at = datetime(\'now\') WHERE id = ?', [await hashPassword(newPassword), userId]);
    await this.destroyAllSessions(userId);
    return true;
  }
}

module.exports = { AuthService, AuthError };
