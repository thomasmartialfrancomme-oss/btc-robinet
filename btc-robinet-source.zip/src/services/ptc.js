'use strict';
/**
 * Service PTC (Étape 5) — publicités rémunérées pour consultation réelle.
 *
 * Cadre strict :
 *  - seules les campagnes créées explicitement par l'administrateur sont diffusées ;
 *  - l'annonceur paie un budget en sats (table ptc_ads.budget_sats) ;
 *  - la récompense du membre est débitée du budget de l'annonceur ;
 *  - une vue n'est valide que si : jeton unique, annonce active, durée minimale
 *    écoulée, quota quotidien non dépassé, intervalle minimal entre deux vues.
 *
 * Ce module ne génère aucun clic artificiel : il rémunère un humain qui a réellement
 * affiché la publicité pendant la durée demandée, dans une campagne contractée.
 */
const crypto = require('node:crypto');

class PtcError extends Error {
  constructor(message, { status = 400, code = 'ptc_error', details } = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

class PtcService {
  constructor(db, settings, config) {
    this.db = db;
    this.settings = settings;
    this.config = config;
  }

  async enabled() {
    const cfg = await this.settings.all();
    return Boolean(cfg.modules && cfg.modules.ptc);
  }

  /** Campagnes visibles par un membre + compteurs. */
  async listForUser(user) {
    const cfg = await this.settings.all();
    const enabled = Boolean(cfg.modules && cfg.modules.ptc);
    const ads = await this.db.all(
      `SELECT id, advertiser, title, duration_sec, reward_sats, daily_limit, budget_sats, spent_sats
       FROM ptc_ads WHERE status = 'active' AND (budget_sats = 0 OR spent_sats < budget_sats)
       ORDER BY id ASC`
    );
    const today = await this.db.get(
      `SELECT COUNT(*) AS n FROM claims WHERE user_id = ? AND module = 'ptc' AND status = 'credited'
         AND date(created_at) = date('now')`, [user.id]
    );
    const perAd = await this.db.all(
      `SELECT ref_id, COUNT(*) AS n FROM claims WHERE user_id = ? AND module = 'ptc'
         AND status = 'credited' AND date(created_at) = date('now') GROUP BY ref_id`, [user.id]
    );
    const counts = Object.fromEntries(perAd.map((r) => [r.ref_id, r.n]));
    return {
      enabled,
      daily_limit: cfg.ptc_daily_limit,
      claims_today: today ? today.n : 0,
      remaining_today: Math.max(0, cfg.ptc_daily_limit - (today ? today.n : 0)),
      items: ads.map((a) => ({
        ...a,
        used_today: counts[a.id] || 0,
        remaining: Math.max(0, a.daily_limit - (counts[a.id] || 0)),
        budget_left_sats: a.budget_sats > 0 ? Math.max(0, a.budget_sats - a.spent_sats) : null,
      })),
    };
  }

  /** Ouvre une vue : crée le jeton, renvoie l'URL de l'annonce et le décompte. */
  async start(user, adId) {
    if (!(await this.enabled())) throw new PtcError('Le module PTC est désactivé.', { status: 503, code: 'module_off' });
    if (user.status !== 'active') throw new PtcError('Compte non actif.', { status: 403, code: 'status' });
    const cfg = await this.settings.all();

    const ad = await this.db.get(`SELECT * FROM ptc_ads WHERE id = ? AND status = 'active'`, [adId]);
    if (!ad) throw new PtcError('Campagne introuvable ou inactive.', { status: 404, code: 'not_found' });
    if (ad.budget_sats > 0 && ad.spent_sats >= ad.budget_sats) {
      throw new PtcError('Budget de cette campagne épuisé.', { status: 409, code: 'budget_exhausted' });
    }

    const today = await this.db.get(
      `SELECT COUNT(*) AS n FROM claims WHERE user_id = ? AND module = 'ptc' AND status = 'credited'
         AND date(created_at) = date('now')`, [user.id]
    );
    if (today && today.n >= cfg.ptc_daily_limit) {
      throw new PtcError('Limite journalière PTC atteinte.', { status: 429, code: 'daily_limit', details: { limit: cfg.ptc_daily_limit } });
    }
    const usedAd = await this.db.get(
      `SELECT COUNT(*) AS n FROM claims WHERE user_id = ? AND module = 'ptc' AND ref_id = ? AND status = 'credited'
         AND date(created_at) = date('now')`, [user.id, adId]
    );
    if (usedAd && usedAd.n >= ad.daily_limit) {
      throw new PtcError('Vous avez déjà consulté cette annonce le nombre maximum de fois aujourd\'hui.', { status: 429, code: 'ad_limit' });
    }
    const lastView = await this.db.get(
      `SELECT created_at FROM claims WHERE user_id = ? AND module = 'ptc' AND status = 'credited'
       ORDER BY id DESC LIMIT 1`, [user.id]
    );
    if (lastView) {
      const ts = Date.parse(lastView.created_at.replace(' ', 'T') + 'Z');
      const wait = Math.ceil((ts + cfg.ptc_min_interval * 1000 - Date.now()) / 1000);
      if (wait > 0) throw new PtcError(`Patientez ${wait} s avant une nouvelle annonce.`, { status: 429, code: 'cooldown', details: { retry_after: wait } });
    }

    const token = crypto.randomBytes(20).toString('base64url');
    await this.db.run(
      `INSERT INTO ptc_views (user_id, ad_id, token, status) VALUES (?, ?, ?, 'started')`,
      [user.id, adId, token]
    );
    return {
      token,
      ad_url: ad.target_url,
      duration_sec: ad.duration_sec,
      reward_sats: ad.reward_sats,
      title: ad.title,
      advertiser: ad.advertiser,
    };
  }

  /** Valide la vue après la durée minimale écoulée. */
  async complete(user, { token, visible_seconds }) {
    const view = await this.db.get('SELECT * FROM ptc_views WHERE token = ?', [token]);
    if (!view) throw new PtcError('Vue inconnue.', { status: 404, code: 'not_found' });
    if (view.user_id !== user.id) throw new PtcError('Vue d\'un autre membre.', { status: 403, code: 'wrong_user' });
    if (view.status === 'credited') throw new PtcError('Récompense déjà versée.', { status: 409, code: 'already_credited' });
    if (view.status === 'rejected') throw new PtcError('Vue rejetée.', { status: 409, code: 'rejected' });

    const ad = await this.db.get('SELECT * FROM ptc_ads WHERE id = ?', [view.ad_id]);
    if (!ad || ad.status !== 'active') throw new PtcError('Campagne inactive.', { status: 409, code: 'ad_inactive' });

    const started = Date.parse(view.started_at.replace(' ', 'T') + 'Z');
    const elapsed = (Date.now() - started) / 1000;
    const required = ad.duration_sec;
    if (elapsed < required) {
      throw new PtcError(`Temps de consultation insuffisant (${Math.floor(elapsed)} s / ${required} s).`, {
        status: 429, code: 'too_fast', details: { elapsed: Math.floor(elapsed), required },
      });
    }
    // Contrôle "onglet réellement visible" transmis par le client : tolérance 20 %
    if (visible_seconds !== undefined && Number(visible_seconds) < required * 0.8) {
      throw new PtcError('L\'onglet n\'est pas resté visible pendant la durée requise.', { status: 429, code: 'not_visible' });
    }
    if (elapsed > 3600) {
      await this.db.run(`UPDATE ptc_views SET status = 'rejected' WHERE token = ?`, [token]);
      throw new PtcError('Vue expirée.', { status: 410, code: 'expired' });
    }

    const reward = ad.reward_sats;
    const lid = crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex');

    const result = await this.db.atomic((tx) => {
      // 1. Verrou de vue + contrôle de budget dans la MÊME écriture conditionnelle
      const locked = tx.run(
        `UPDATE ptc_views SET status = 'credited', credited_at = datetime('now'), ledger_ref = ?
         WHERE token = ? AND status = 'started'
           AND EXISTS (SELECT 1 FROM ptc_ads a WHERE a.id = ? AND a.status = 'active'
                       AND (a.budget_sats = 0 OR a.spent_sats + a.reward_sats <= a.budget_sats))`,
        [lid, token, ad.id]
      );
      if (locked.changes === 0) {
        throw new PtcError('Vue déjà traitée ou budget de la campagne épuisé.', { status: 409, code: 'already_credited' });
      }

      // 2. Débit du budget annonceur (conditionnel, jamais négatif)
      const spent = tx.run(
        `UPDATE ptc_ads SET spent_sats = spent_sats + ?
         WHERE id = ? AND (budget_sats = 0 OR spent_sats + ? <= budget_sats)`,
        [reward, ad.id, reward]
      );
      if (spent.changes === 0) throw new PtcError('Budget de la campagne épuisé.', { status: 409, code: 'budget_exhausted' });

      // 3. Réclamation + crédit membre + grand livre
      const ins = tx.run(
        `INSERT INTO claims (user_id, module, ref_id, amount_sats, ledger_ref, status)
         SELECT ?, 'ptc', ?, ?, ?, 'credited'
         WHERE EXISTS (SELECT 1 FROM ptc_views WHERE ledger_ref = ?)`,
        [user.id, ad.id, reward, lid, lid]
      );
      const credit = tx.run(
        `UPDATE users SET balance_sats = balance_sats + ?, total_earned_sats = total_earned_sats + ?
         WHERE id = ? AND EXISTS (SELECT 1 FROM claims WHERE ledger_ref = ?)`,
        [reward, reward, user.id, lid]
      );
      if (credit.changes === 0) throw new PtcError('Crédit impossible (état incohérent).', { status: 500, code: 'inconsistent' });

      tx.run(
        `INSERT INTO ledger (user_id, type, module, amount_sats, balance_after, meta, ref)
         VALUES (?, 'credit_reward', 'ptc', ?, (SELECT balance_sats FROM users WHERE id = ?), ?, ?)`,
        [user.id, reward, user.id, JSON.stringify({ ad_id: ad.id, token }), lid]
      );

      // 4. Parrainage
      tx.run(
        `UPDATE users SET balance_sats = balance_sats + CAST(? * r.percent / 100 AS INTEGER)
         FROM referrals r WHERE r.referred_id = ? AND users.id = r.referrer_id`,
        [reward, user.id]
      );
      tx.run(`UPDATE referrals SET earned_sats = earned_sats + CAST(? * percent / 100 AS INTEGER) WHERE referred_id = ?`,
        [reward, user.id]);

      return { claimId: ins.lastInsertRowid };
    });

    const fresh = await this.db.get('SELECT balance_sats FROM users WHERE id = ?', [user.id]);

    return { ok: true, amount_sats: reward, balance_sats: fresh ? fresh.balance_sats : null, claim_id: result.claimId };
  }

  /* ----------------------------- Admin ------------------------------ */

  async createAd({ advertiser, title, targetUrl, durationSec, rewardSats, budgetSats, dailyLimit }) {
    if (!advertiser || !title || !targetUrl) throw new PtcError('Annonceur, titre et URL sont requis.');
    if (!/^https?:\/\//i.test(targetUrl)) throw new PtcError('URL de campagne invalide (http/https attendu).');
    const r = await this.db.run(
      `INSERT INTO ptc_ads (advertiser, title, target_url, duration_sec, reward_sats, budget_sats, daily_limit, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'active')`,
      [advertiser, title, targetUrl,
       Math.min(300, Math.max(10, Number(durationSec) || 30)),
       Math.max(1, Number(rewardSats) || 10),
       Math.max(0, Number(budgetSats) || 0),
       Math.max(1, Number(dailyLimit) || 5)]
    );
    return { id: r.lastInsertRowid };
  }

  async adminList() {
    const ads = await this.db.all('SELECT * FROM ptc_ads ORDER BY id DESC');
    const stats = await this.db.get(
      `SELECT COUNT(*) AS n, COALESCE(SUM(amount_sats),0) AS sats FROM claims WHERE module = 'ptc' AND status = 'credited'`);
    const views = await this.db.get(
      `SELECT SUM(CASE WHEN status = 'credited' THEN 1 ELSE 0 END) AS credited,
              SUM(CASE WHEN status = 'started' THEN 1 ELSE 0 END) AS started,
              SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected FROM ptc_views`);
    return { ads, stats, views };
  }

  async setAdStatus(id, status) {
    if (!['active', 'paused', 'suspended'].includes(status)) throw new PtcError('Statut invalide.');
    await this.db.run('UPDATE ptc_ads SET status = ? WHERE id = ?', [status, id]);
  }

  /** Crédite un budget annonceur (paiement reçu) — tracé en revenus. */
  async fundAd(id, amountSats, note) {
    const sats = Math.max(0, Number(amountSats) || 0);
    if (!sats) throw new PtcError('Montant de budget invalide.');
    await this.db.atomic((tx) => {
      tx.run('UPDATE ptc_ads SET budget_sats = budget_sats + ? WHERE id = ?', [sats, id]);
      tx.run(
        `INSERT INTO finance_entries (kind, category, amount_usd, sats, note, entry_date)
         VALUES ('revenue', 'ptc', 0, ?, ?, date('now'))`,
        [sats, note || 'budget annonceur PTC']
      );
    });
    return { ok: true };
  }
}

module.exports = { PtcService, PtcError };
