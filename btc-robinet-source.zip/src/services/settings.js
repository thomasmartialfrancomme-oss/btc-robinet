'use strict';
/**
 * Service de réglages : valeurs par défaut + surcharge en base (table settings).
 * L'administration modifie ces valeurs à chaud, sans redéploiement.
 */
const DEFAULTS = {
  site_name: 'BTC ROBINET',
  faucet_reward_sats: 25,
  faucet_cooldown_seconds: 180,
  faucet_daily_limit: 30,
  faucet_min_balance_guard: 0,      // marge de sécurité : ne jamais vider le faucet
  shortlink_reward_sats: 15,
  ptc_reward_sats: 10,
  min_withdraw_sats: 500,
  referral_percent: 20,
  points_per_sat: 100,              // 1 sat = 100 points (interne)
  btc_usd: 90000,                   // prix BTC utilisé pour la rentabilité
  usd_per_1000_points: 0.001,       // valeur partenaire estimée de 1000 points
  modules: { faucet: true, shortlinks: false, ptc: false, offerwalls: false, referral: true },
  maintenance: { enabled: false, message: 'Maintenance en cours, revenez dans quelques minutes.' },
  faucet_notes: 'Réclamez vos satoshis toutes les 3 minutes.',
  shortlink_min_dwell: 10,          // secondes minimales avant validation d'un shortlink
  shortlink_daily_limit: 20,        // par membre et par jour (tous liens confondus)
  ptc_daily_limit: 10,              // par membre et par jour (toutes annonces confondues)
  ptc_min_interval: 20,             // secondes entre deux validations PTC
  offerwall_min_usd: 0.0005,        // montant minimal accepté d'un callback
  revenue_share_default: 60,        // % du revenu partenaire reversé au membre
};

const MODULES = ['faucet', 'shortlinks', 'ptc', 'offerwalls', 'referral'];

class SettingsService {
  constructor(db) {
    this.db = db;
  }

  async init(overrides = {}) {
    for (const [key, value] of Object.entries(DEFAULTS)) {
      await this.db.run('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', [key, JSON.stringify(value)]);
    }
    for (const [key, value] of Object.entries(overrides)) {
      if (value !== undefined && value !== null && value !== '') {
        await this.set(key, value);
      }
    }
  }

  async all() {
    const rows = await this.db.all('SELECT key, value FROM settings');
    const out = { ...DEFAULTS };
    for (const row of rows) {
      try { out[row.key] = JSON.parse(row.value); } catch { out[row.key] = row.value; }
    }
    return out;
  }

  async get(key, fallback) {
    const row = await this.db.get('SELECT value FROM settings WHERE key = ?', [key]);
    if (!row) return key in DEFAULTS ? DEFAULTS[key] : fallback;
    try { return JSON.parse(row.value); } catch { return row.value; }
  }

  async set(key, value) {
    const json = JSON.stringify(value);
    await this.db.run(
      `INSERT INTO settings (key, value, updated_at) VALUES (?, ?, datetime('now'))
       ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')`,
      [key, json]
    );
    return value;
  }

  /** Applique un lot de réglages validés depuis le panneau admin. */
  async bulkSet(patch) {
    const applied = {};
    for (const [key, value] of Object.entries(patch)) {
      if (!(key in DEFAULTS)) continue;
      applied[key] = await this.set(key, value);
    }
    return applied;
  }

  async moduleEnabled(name) {
    const modules = await this.get('modules', DEFAULTS.modules);
    return Boolean(modules[name]);
  }

  async setModule(name, enabled) {
    if (!MODULES.includes(name)) throw new Error(`Module inconnu: ${name}`);
    const modules = await this.get('modules', DEFAULTS.modules);
    modules[name] = Boolean(enabled);
    await this.set('modules', modules);
    return modules;
  }
}

module.exports = { SettingsService, DEFAULTS, MODULES };
