'use strict';
/**
 * Module rentabilité (Étape 9).
 *
 *  Bénéfice net avant impôts =
 *      revenus partenaires + revenus manuels
 *    - récompenses versées aux membres
 *    - frais FaucetPay (pourcentage configurable)
 *    - hébergement (entrées de dépense)
 *    - autres frais
 *
 * Les montants sont calculés en satoshis puis convertis en USD/EUR avec le
 * prix BTC configurable. Les résultats sont fournis par jour / semaine / mois.
 */
const SATS_PER_BTC = 1e8;

class FinanceService {
  constructor(db, settings) {
    this.db = db;
    this.settings = settings;
  }

  async rates() {
    const cfg = await this.settings.all();
    return {
      btc_usd: Number(cfg.btc_usd) || 90000,
      usd_per_1000_points: Number(cfg.usd_per_1000_points) || 0,
      faucetpay_fee_percent: Number(cfg.faucetpay_fee_percent ?? 2),
      eur_usd: Number(cfg.eur_usd ?? 1.08),
    };
  }

  /** Rapport détaillé pour une fenêtre glissante. */
  async report(days = 1) {
    const r = await this.rates();
    const since = `-${days} days`;

    const rewards = await this.db.get(
      `SELECT COALESCE(SUM(amount_sats),0) AS sats, COUNT(*) AS n FROM claims
       WHERE status = 'credited' AND created_at >= datetime('now', ?)`, [since]
    );
    const paid = await this.db.get(
      `SELECT COALESCE(SUM(amount_sats),0) AS sats FROM payouts
       WHERE status IN ('sent','simulated') AND created_at >= datetime('now', ?)`, [since]
    );
    // Revenus estimés : valeur partenaire des points distribués (réglable).
    // (Chaque réseau partenaire a son propre CPM : on l'estime en USD pour
    //  1000 points distribués, ce qui est la métrique utilisée par les
    //  shortlinks/offerwalls — voir docs/PARTENAIRES.md.)
    const estimatedPartnerRevenueUsd = (rewards.sats / 1000) * r.usd_per_1000_points;

    const manualRevenue = await this.db.get(
      `SELECT COALESCE(SUM(amount_usd),0) AS usd FROM finance_entries
       WHERE kind = 'revenue' AND entry_date >= date('now', ?)`, [since]
    );
    const manualExpense = await this.db.get(
      `SELECT COALESCE(SUM(amount_usd),0) AS usd FROM finance_entries
       WHERE kind = 'expense' AND entry_date >= date('now', ?)`, [since]
    );

    const satsToUsd = (sats) => (sats / SATS_PER_BTC) * r.btc_usd;
    const rewardUsd = satsToUsd(rewards.sats);
    const feesUsd = (rewardUsd * r.faucetpay_fee_percent) / 100;
    const revenueUsd = estimatedPartnerRevenueUsd + manualRevenue.usd;
    const expensesUsd = rewardUsd + feesUsd + manualExpense.usd;
    const netUsd = revenueUsd - expensesUsd;

    return {
      window_days: days,
      rates: r,
      revenue: {
        partners_estimated_usd: round2(estimatedPartnerRevenueUsd),
        manual_usd: round2(manualRevenue.usd),
        total_usd: round2(revenueUsd),
      },
      costs: {
        member_rewards_sats: rewards.sats,
        member_rewards_usd: round2(rewardUsd),
        faucetpay_fees_usd: round2(feesUsd),
        hosting_other_usd: round2(manualExpense.usd),
        total_usd: round2(expensesUsd),
      },
      payouts: { count: rewards.n, paid_sats: paid.sats, paid_usd: round2(satsToUsd(paid.sats)) },
      net_usd: round2(netUsd),
      net_eur: round2(netUsd / r.eur_usd),
      margin_percent: revenueUsd > 0 ? round2((netUsd / revenueUsd) * 100) : 0,
      breakeven_usd_per_1000_points: round4(rewardUsd && 1000 ? (rewardUsd / Math.max(1, rewards.sats)) * 1000 + ((rewardUsd / Math.max(1, rewards.sats)) * 1000 * r.faucetpay_fee_percent) / 100 : 0),
      generated_at: new Date().toISOString(),
    };
  }

  async overview() {
    const [day, week, month] = await Promise.all([this.report(1), this.report(7), this.report(30)]);
    return { day, week, month };
  }

  /** Simulateur : que se passe-t-il si X utilisateurs réclament Y fois / jour ? */
  async simulate({ users, claims_per_user, reward_sats, revenue_per_1000_points, hosting_usd_month }) {
    const r = await this.rates();
    const claims = Math.max(0, Number(users) * Number(claims_per_user));
    const rewardSats = Math.max(0, claims * Number(reward_sats));
    const rewardUsd = (rewardSats / SATS_PER_BTC) * r.btc_usd;
    const feesUsd = (rewardUsd * r.faucetpay_fee_percent) / 100;
    const revenueUsd = (rewardSats / 1000) * Number(revenue_per_1000_points ?? r.usd_per_1000_points);
    const hostingUsd = Number(hosting_usd_month || 0) / 30;
    const net = revenueUsd - rewardUsd - feesUsd - hostingUsd;
    return {
      daily_claims: claims,
      reward_sats: Math.round(rewardSats),
      revenue_usd: round2(revenueUsd),
      reward_usd: round2(rewardUsd),
      fees_usd: round2(feesUsd),
      hosting_usd: round2(hostingUsd),
      net_usd: round2(net),
      net_eur: round2(net / r.eur_usd),
      net_month_usd: round2(net * 30),
      profitable: net > 0,
    };
  }

  async addEntry({ kind, category, amount_usd, note, entry_date }) {
    if (!['revenue', 'expense'].includes(kind)) throw new Error('kind invalide');
    await this.db.run(
      `INSERT INTO finance_entries (kind, category, amount_usd, note, entry_date) VALUES (?, ?, ?, ?, COALESCE(?, date('now')))`,
      [kind, category, Number(amount_usd) || 0, note || null, entry_date || null]
    );
  }

  async listEntries(limit = 100) {
    return this.db.all('SELECT * FROM finance_entries ORDER BY id DESC LIMIT ?', [Math.min(300, limit)]);
  }
}

const round2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
const round4 = (n) => Math.round((Number(n) + Number.EPSILON) * 10000) / 10000;

module.exports = { FinanceService, SATS_PER_BTC };
