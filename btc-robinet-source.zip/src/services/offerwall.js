'use strict';
/**
 * Service OFFERWALLS (Étape 6).
 *
 * Principe : le partenaire (AdGate, OfferToro, ayeT, BitLabs, CPX…) envoie un
 * postback serveur-à-serveur (S2S) quand une mission est terminée. Nous ne
 * créditons QUE sur callback officiel vérifié.
 *
 * Sécurité mise en œuvre :
 *  1. signature HMAC-SHA256 (recommandé) ou MD5 (compatibilité) sur
 *     `${user_token}${transaction_id}${amount}` avec le secret du partenaire ;
 *  2. unicité stricte de `transaction_id` (index UNIQUE en base) → un rejeu ne
 *     crédite jamais deux fois, même en cas de retry du partenaire ;
 *  3. journalisation du callback AVANT le crédit (table offerwall_callbacks) ;
 *  4. seul un statut de mission « complétée » est accepté ;
 *  5. montant minimal et plafond de sécurité par conversion ;
 *  6. réponse 200 systématique pour éviter les retries infinis, sauf signature
 *     invalide (401) que le partenaire doit voir.
 */
const crypto = require('node:crypto');
const { hmac, safeEqual } = require('../lib/security');

class OfferwallError extends Error {
  constructor(message, { status = 400, code = 'offerwall_error', details } = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

class OfferwallService {
  constructor(db, settings, config) {
    this.db = db;
    this.settings = settings;
    this.config = config;
  }

  async enabled() {
    const cfg = await this.settings.all();
    return Boolean(cfg.modules && cfg.modules.offerwalls);
  }

  /** Jeton stable identifiant le membre auprès des partenaires (pas son id brut). */
  userToken(user) {
    return hmac(this.config.sessionSecret, `offerwall:${user.id}`).slice(0, 24);
  }

  /** Retrouve un membre depuis le jeton transmis par le partenaire. */
  async resolveUser(token) {
    if (!token) return null;
    const users = await this.db.all(`SELECT id FROM users WHERE status = 'active' LIMIT 5000`);
    for (const u of users) {
      if (safeEqual(this.userToken({ id: u.id }), String(token))) {
        return this.db.get('SELECT * FROM users WHERE id = ?', [u.id]);
      }
    }
    return null;
  }

  /** Liste des offreurs configurés + URL personnalisée du membre. */
  async listForUser(user, origin) {
    const cfg = await this.settings.all();
    const enabled = Boolean(cfg.modules && cfg.modules.offerwalls);
    const partners = await this.db.all(
      `SELECT id, name, network_url, cpm_usd, revenue_share, status FROM partners
       WHERE type = 'offerwall' AND status = 'active' ORDER BY id ASC`
    );
    const base = (origin || this.config.siteUrl).replace(/\/$/, '');
    const token = this.userToken(user);
    const today = await this.db.get(
      `SELECT COUNT(*) AS n, COALESCE(SUM(amount_sats),0) AS sats FROM claims
       WHERE user_id = ? AND module = 'offerwall' AND status = 'credited' AND date(created_at) = date('now')`, [user.id]
    );
    return {
      enabled,
      token,
      earned_today_sats: today ? today.sats : 0,
      conversions_today: today ? today.n : 0,
      items: partners.map((p) => ({
        id: p.id,
        name: p.name,
        iframe_url: p.network_url
          ? `${p.network_url}${p.network_url.includes('?') ? '&' : '?'}uid=${encodeURIComponent(token)}`
          : null,
        callback_url: `${base}/api/offerwalls/${p.id}/callback`,
        revenue_share: p.revenue_share,
      })),
    };
  }

  /** Vérifie la signature d'un postback (HMAC-SHA256 ou MD5). */
  verifySignature({ partner, token, transactionId, amount, signature }) {
    if (!partner || !partner.callback_secret) return false;
    if (!signature) return false;
    const canonical = `${token}${transactionId}${amount}`;
    const hmacSig = hmac(partner.callback_secret, canonical);
    const md5Sig = crypto.createHash('md5').update(canonical + partner.callback_secret).digest('hex');
    const md5SigAlt = crypto.createHash('md5').update(canonical).digest('hex');
    const given = String(signature).toLowerCase();
    return [hmacSig, md5Sig, md5SigAlt].some((candidate) => safeEqual(candidate.toLowerCase(), given) || candidate.toLowerCase().endsWith(given));
  }

  /**
   * Traite un callback partenaire.
   * @param {number} partnerId
   * @param {object} q  paramètres du postback (query ou body)
   */
  async handleCallback(partnerId, q) {
    const cfg = await this.settings.all();
    if (!cfg.modules || !cfg.modules.offerwalls) {
      throw new OfferwallError('Module offerwalls désactivé.', { status: 503, code: 'module_off' });
    }
    const partner = await this.db.get('SELECT * FROM partners WHERE id = ? AND type = ?', [partnerId, 'offerwall']);
    if (!partner) throw new OfferwallError('Partenaire inconnu.', { status: 404, code: 'unknown_partner' });
    if (partner.status !== 'active') throw new OfferwallError('Partenaire suspendu.', { status: 403, code: 'partner_suspended' });

    const token = q.user_id || q.uid || q.subid || q.sub_id || null;
    const transactionId = String(q.transaction_id || q.txid || q.id || '').trim();
    const amountRaw = q.amount !== undefined ? q.amount : (q.payout !== undefined ? q.payout : q.reward);
    const amount = Number(amountRaw);
    const status = String(q.status !== undefined ? q.status : '1');
    const signature = q.signature || q.sig || q.hash || '';

    if (!transactionId) throw new OfferwallError('transaction_id manquant.', { status: 400, code: 'missing_tx' });
    if (!Number.isFinite(amount) || amount < 0) throw new OfferwallError('Montant invalide.', { status: 400, code: 'bad_amount' });

    // Statuts acceptés : 1 / "1" / "credited" / "completed"
    const completed = ['1', 'credited', 'completed', 'complete', 'true'].includes(status.toLowerCase());

    const signatureOk = this.verifySignature({ partner, token, transactionId, amount: amountRaw, signature });

    // Journalisation AVANT tout crédit (et idempotence par transaction_id)
    const existing = await this.db.get('SELECT * FROM offerwall_callbacks WHERE transaction_id = ?', [transactionId]);
    if (existing) {
      return { ok: true, duplicate: true, credited_sats: 0, message: 'Callback déjà traité (idempotence).' };
    }

    const user = signatureOk ? await this.resolveUser(token) : null;
    const usd = amount > 0 ? amount : 0;
    const rates = { btc_usd: Number(cfg.btc_usd) || 90000 };
    const share = Number(partner.revenue_share || cfg.revenue_share_default || 60);
    const rewardSats = Math.round((usd / rates.btc_usd) * 1e8 * (share / 100));

    const insert = await this.db.run(
      `INSERT INTO offerwall_callbacks (partner_id, user_id, transaction_id, offer_name, amount_usd, reward_sats, signature_ok, status, raw)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [partner.id, user ? user.id : null, transactionId, q.offer_name || q.offer || null, usd, rewardSats,
       signatureOk ? 1 : 0, signatureOk && completed && user ? 'received' : 'rejected', JSON.stringify(q).slice(0, 2000)]
    );

    if (!signatureOk) {
      throw new OfferwallError('Signature du callback invalide : conversion rejetée.', { status: 401, code: 'bad_signature' });
    }
    if (!completed) {
      await this.db.run(`UPDATE offerwall_callbacks SET status = 'rejected' WHERE id = ?`, [insert.lastInsertRowid]);
      return { ok: true, credited_sats: 0, message: 'Mission non complétée : aucun crédit.' };
    }
    if (!user) {
      await this.db.run(`UPDATE offerwall_callbacks SET status = 'rejected' WHERE id = ?`, [insert.lastInsertRowid]);
      throw new OfferwallError('Membre introuvable pour ce jeton.', { status: 404, code: 'unknown_user' });
    }
    if (usd < Number(cfg.offerwall_min_usd)) {
      await this.db.run(`UPDATE offerwall_callbacks SET status = 'rejected' WHERE id = ?`, [insert.lastInsertRowid]);
      return { ok: true, credited_sats: 0, message: 'Montant sous le seuil minimal.' };
    }

    // Plafond de sécurité : 1 conversion = 200 000 sats maximum
    const capped = Math.min(rewardSats, 200000);
    if (capped <= 0) {
      await this.db.run(`UPDATE offerwall_callbacks SET status = 'rejected' WHERE id = ?`, [insert.lastInsertRowid]);
      return { ok: true, credited_sats: 0, message: 'Conversion nulle.' };
    }

    const lid = crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex');

    await this.db.atomic((tx) => {
      // 1. Verrou du callback : seule une ligne encore "received" peut être créditée
      const locked = tx.run(
        `UPDATE offerwall_callbacks SET status = 'credited', ledger_ref = ?
         WHERE id = ? AND status = 'received'`,
        [lid, insert.lastInsertRowid]
      );
      if (locked.changes === 0) throw new OfferwallError('Callback déjà traité.', { status: 409, code: 'already_credited' });

      // 2. Réclamation + crédit membre + grand livre (tous conditionnés au verrou)
      tx.run(
        `INSERT INTO claims (user_id, module, ref_id, amount_sats, ledger_ref, status)
         SELECT ?, 'offerwall', ?, ?, ?, 'credited'
         WHERE EXISTS (SELECT 1 FROM offerwall_callbacks WHERE ledger_ref = ?)`,
        [user.id, partner.id, capped, lid, lid]
      );
      const credit = tx.run(
        `UPDATE users SET balance_sats = balance_sats + ?, total_earned_sats = total_earned_sats + ?
         WHERE id = ? AND EXISTS (SELECT 1 FROM claims WHERE ledger_ref = ?)`,
        [capped, capped, user.id, lid]
      );
      if (credit.changes === 0) throw new OfferwallError('Crédit impossible (état incohérent).', { status: 500, code: 'inconsistent' });

      tx.run(
        `INSERT INTO ledger (user_id, type, module, amount_sats, balance_after, meta, ref)
         VALUES (?, 'credit_reward', 'offerwall', ?, (SELECT balance_sats FROM users WHERE id = ?), ?, ?)`,
        [user.id, capped, user.id, JSON.stringify({ partner: partner.name, transaction_id: transactionId }), lid]
      );

      // 3. Revenu du propriétaire (montant brut de la conversion)
      tx.run(
        `INSERT INTO finance_entries (kind, category, amount_usd, note, entry_date)
         VALUES ('revenue', 'offerwall', ?, ?, date('now'))`,
        [usd, `${partner.name} — ${q.offer_name || 'mission'}`]
      );

      // 4. Parrainage
      tx.run(
        `UPDATE users SET balance_sats = balance_sats + CAST(? * r.percent / 100 AS INTEGER)
         FROM referrals r WHERE r.referred_id = ? AND users.id = r.referrer_id`,
        [capped, user.id]
      );
      tx.run(`UPDATE referrals SET earned_sats = earned_sats + CAST(? * percent / 100 AS INTEGER) WHERE referred_id = ?`,
        [capped, user.id]);
    });

    const fresh = await this.db.get('SELECT balance_sats FROM users WHERE id = ?', [user.id]);

    return {
      ok: true,
      duplicate: false,
      username: user.username,
      usd,
      credited_sats: capped,
      balance_sats: fresh ? fresh.balance_sats : null,
      message: 'Conversion créditée.',
    };
  }

  async adminList() {
    const partners = await this.db.all(`SELECT * FROM partners WHERE type = 'offerwall' ORDER BY id DESC`);
    const callbacks = await this.db.all(`SELECT * FROM offerwall_callbacks ORDER BY id DESC LIMIT 100`);
    const stats = await this.db.get(
      `SELECT COUNT(*) AS n, COALESCE(SUM(amount_sats),0) AS sats FROM claims WHERE module = 'offerwall' AND status = 'credited'`);
    const revenue = await this.db.get(
      `SELECT COALESCE(SUM(amount_usd),0) AS usd FROM finance_entries WHERE kind = 'revenue' AND category = 'offerwall'`);
    return { partners, callbacks, stats: { ...stats, revenue_usd: revenue.usd } };
  }
}

module.exports = { OfferwallService, OfferwallError };
