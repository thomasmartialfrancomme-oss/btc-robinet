'use strict';
/**
 * Service FaucetPay.
 *
 * Deux modes :
 *  - "mock"      : simulateur local (aucun appel réseau, aucun argent réel).
 *  - "faucetpay" : appels réels à l'API FaucetPay (v1 form-encoded ou v2 Bearer).
 *
 * Garanties de sécurité :
 *  - les clés API ne quittent jamais le serveur (jamais envoyées au navigateur) ;
 *  - PAYOUTS_LIVE=false => aucun paiement réel, même en mode faucetpay ;
 *  - chaque envoi porte une clé d'idempotence (env v2) : un rejeu ne peut pas
 *    payer deux fois ; en v1, l'unicité est garantie en base (colonne UNIQUE)
 *    et par un état "sending" posé dans la même transaction que le débit ;
 *  - erreurs normalisées, jamais de paiement si le solde interne est insuffisant
 *    (contrôle fait AVANT l'appel, puis confirmé par le statut 402 de FaucetPay).
 *
 * Documentation : https://faucetpay.io/api-docs
 */
const cfg = require('../lib/config');

const STATUS = {
  200: 'OK',
  401: 'Accès refusé (IP non autorisée ou compte faucet suspendu)',
  402: 'Solde FaucetPay insuffisant',
  403: 'Clé API invalide ou manquante',
  404: 'Méthode API inconnue ou requête non POST',
  405: 'Montant invalide (entier positif en plus petite unité)',
  410: 'Devise non supportée',
  450: 'Limite d\'envoi du faucet atteinte',
  456: 'Destinataire non payable (compte inexistant, suspendu ou non vérifié)',
  457: 'Destinataire refusé par les règles du faucet (blacklist/antifraude)',
  459: 'Trop de requêtes API depuis cette IP (rate limit)',
};

class FaucetPayError extends Error {
  constructor(message, { status, body } = {}) {
    super(message);
    this.name = 'FaucetPayError';
    this.status = status;
    this.body = body;
  }
}

class FaucetPayService {
  constructor(config = cfg, fetchImpl = globalThis.fetch) {
    this.cfg = config;
    this.fetch = fetchImpl;
  }

  get mode() {
    return this.cfg.faucetpay.mode;
  }

  get live() {
    // Un paiement réel n'est possible que si l'on est en mode faucetpay ET
    // que le verrou global PAYOUTS_LIVE a été explicitement ouvert.
    return this.mode === 'faucetpay' && this.cfg.faucetpay.livePayouts === true;
  }

  /* --------------------------- API v1 ----------------------------- */

  async _v1(method, params = {}) {
    const body = new URLSearchParams({ api_key: this.cfg.faucetpay.apiKey, ...params });
    let res;
    try {
      res = await this.fetch(`${this.cfg.faucetpay.baseV1}/${method}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
        signal: AbortSignal.timeout(15000),
      });
    } catch (e) {
      throw new FaucetPayError(`Erreur réseau FaucetPay: ${e.message}`, { status: 0 });
    }
    const data = await res.json().catch(() => ({}));
    if (data.status !== 200) {
      throw new FaucetPayError(data.message || STATUS[data.status] || 'Erreur FaucetPay', { status: data.status, body: data });
    }
    return data;
  }

  /* --------------------------- API v2 ----------------------------- */

  async _v2(path, { key, body = {} } = {}) {
    const bearer = key || this.cfg.faucetpay.readKey || this.cfg.faucetpay.sendKey;
    if (!bearer) throw new FaucetPayError('Clé scoped v2 manquante', { status: 403 });
    let res;
    try {
      res = await this.fetch(`${this.cfg.faucetpay.baseV2}${path}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${bearer}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(15000),
      });
    } catch (e) {
      throw new FaucetPayError(`Erreur réseau FaucetPay: ${e.message}`, { status: 0 });
    }
    const data = await res.json().catch(() => ({}));
    if (!res.ok || (data.status && data.status !== 200)) {
      throw new FaucetPayError(data.message || `HTTP ${res.status}`, { status: res.status, body: data });
    }
    return data;
  }

  useV2() {
    return this.cfg.faucetpay.apiVersion === 'v2';
  }

  /* ------------------------- Opérations --------------------------- */

  /** Vérifie qu'un destinataire est un utilisateur FaucetPay valide. */
  async checkAddress(address, currency = 'BTC') {
    if (this.mode === 'mock') {
      const ok = /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(address) || /^[A-Za-z0-9_.-]{3,}$/.test(address);
      return {
        valid: ok,
        message: ok ? 'Adresse simulée acceptée (mode mock)' : 'Adresse invalide',
        payout_user_hash: ok ? 'mock_' + require('node:crypto').createHash('sha256').update(address.toLowerCase()).digest('hex').slice(0, 24) : null,
        simulated: true,
      };
    }
    const data = this.useV2()
      ? await this._v2('/check-address', { key: this.cfg.faucetpay.readKey, body: { address, currency } })
      : await this._v1('checkaddress', { address, currency });
    return { valid: true, message: data.message, payout_user_hash: data.payout_user_hash || data.hash || null, simulated: false };
  }

  /** Solde du faucet chez FaucetPay, en satoshis. */
  async getBalance(currency = 'BTC') {
    if (this.mode === 'mock') {
      return { balance_sats: 500000, currency, simulated: true };
    }
    if (this.useV2()) {
      const data = await this._v2('/balance', { key: this.cfg.faucetpay.readKey, body: { currency } });
      const sats = data.balance !== undefined ? Number(data.balance) : Math.round(Number(data.balance_bitcoin || 0) * 1e8);
      return { balance_sats: sats, currency, simulated: false, raw: data };
    }
    const data = await this._v1('getbalance', { currency });
    const sats = data.balance !== undefined ? Number(data.balance) : Math.round(Number(data.balance_bitcoin || 0) * 1e8);
    return { balance_sats: sats, currency, simulated: false, raw: data };
  }

  /** Historique des paiements récents. */
  async listPayouts(count = 10, currency = 'BTC') {
    if (this.mode === 'mock') return { rewards: [], simulated: true };
    if (this.useV2()) {
      const data = await this._v2('/payouts', { key: this.cfg.faucetpay.readKey, body: { currency, count } });
      return { rewards: data.payouts || data.rewards || [], simulated: false, raw: data };
    }
    const data = await this._v1('payouts', { count, currency });
    return { rewards: data.rewards || [], simulated: false, raw: data };
  }

  /**
   * Envoie un paiement.
   * @param {object} p
   * @param {string} p.idempotencyKey  clé unique et stable de l'opération
   * @param {string} p.to              email / username / adresse FaucetPay
   * @param {number} p.amountSats      montant en satoshis
   * @param {string} p.currency        BTC
   * @param {string} [p.ip]            IP du membre (anti-abus côté FaucetPay)
   */
  async sendPayout({ idempotencyKey, to, amountSats, currency = 'BTC', ip }) {
    if (!Number.isInteger(amountSats) || amountSats <= 0) {
      throw new FaucetPayError('Montant invalide (entier positif attendu)', { status: 405 });
    }
    if (!idempotencyKey) throw new FaucetPayError('Clé d\'idempotence requise', { status: 400 });

    // Mode simulation, ou mode réel mais verrou fermé => paiement simulé.
    if (!this.live) {
      return {
        simulated: true,
        ok: true,
        payout_id: 'sim_' + idempotencyKey.slice(0, 18),
        payout_user_hash: null,
        message: this.mode === 'mock'
          ? 'Paiement simulé (FAUCETPAY_MODE=mock)'
          : 'Paiement simulé (PAYOUTS_LIVE=false : verrou de sécurité fermé)',
        balance: null,
      };
    }

    if (this.useV2()) {
      const data = await this._v2('/send', {
        key: this.cfg.faucetpay.sendKey,
        body: {
          idempotency_key: idempotencyKey,
          to,
          amount: amountSats,
          currency,
          ...(ip ? { ip_address: ip } : {}),
        },
      });
      return {
        simulated: false,
        ok: true,
        payout_id: String(data.payout_id ?? ''),
        payout_user_hash: data.payout_user_hash || null,
        balance: data.balance ?? null,
        message: data.message || 'OK',
        raw: data,
      };
    }

    const data = await this._v1('send', {
      amount: amountSats,
      to,
      currency,
      ...(ip ? { ip_address: ip } : {}),
      referral: idempotencyKey, // traçabilité dans l'historique FaucetPay
    });
    return {
      simulated: false,
      ok: true,
      payout_id: String(data.payout_id ?? ''),
      payout_user_hash: data.payout_user_hash || null,
      balance: data.balance ?? null,
      message: data.message || 'OK',
      raw: data,
    };
  }
}

module.exports = { FaucetPayService, FaucetPayError, STATUS };
