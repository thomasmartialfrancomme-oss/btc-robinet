'use strict';
/**
 * Anti-fraude : règles simples, explicables et configurables.
 * Objectif : bloquer les abus les plus courants sans punir les membres réels.
 */
const SUSPICIOUS = [
  /\b(tor|vpn|proxy)\b/i,
];

const EMAIL_DISPOSABLE = new Set([
  'mailinator.com', 'yopmail.com', 'guerrillamail.com', '10minutemail.com',
  'temp-mail.org', 'trashmail.com', 'sharklasers.com', 'getnada.com',
  'dispostable.com', 'maildrop.cc', 'tempmail.com', 'fakeinbox.com',
]);

class AntifraudService {
  constructor(db, settings) {
    this.db = db;
    this.settings = settings;
  }

  /** Normalise un email pour les contrôles de doublon. */
  static normalizeEmail(email) {
    const [local, domain] = String(email).trim().toLowerCase().split('@');
    if (!domain) return String(email).trim().toLowerCase();
    // Gmail : les points et le +tag ne changent pas la boîte
    const cleanLocal = domain === 'gmail.com' ? local.replace(/\./g, '').split('+')[0] : local.split('+')[0];
    return `${cleanLocal}@${domain}`;
  }

  /** Contrôles à l'inscription. Retourne {allowed, risk, reasons[]}. */
  async checkSignup({ email, username, ip, userAgent }) {
    const reasons = [];
    let risk = 0;
    const domain = String(email).toLowerCase().split('@')[1] || '';
    if (EMAIL_DISPOSABLE.has(domain)) { reasons.push('email jetable'); risk += 60; }
    if (!ip || ip === 'unknown') { reasons.push('IP inconnue'); risk += 10; }
    if (userAgent && SUSPICIOUS.some((r) => r.test(userAgent))) { reasons.push('client suspect'); risk += 40; }

    // Trop de comptes depuis la même IP sur 24 h
    const row = await this.db.get(
      `SELECT COUNT(*) AS n FROM users WHERE signup_ip = ? AND created_at >= datetime('now','-1 day')`,
      [ip]
    );
    if (row && row.n >= 3) { reasons.push(`${row.n} inscriptions déjà enregistrées depuis cette IP (24 h)`); risk += 25 * (row.n - 2); }

    // Doublon email normalisé (gmail dots / +tag)
    const normalized = AntifraudService.normalizeEmail(email);
    const dupes = await this.db.all('SELECT email FROM users LIMIT 5000');
    if (dupes.some((u) => AntifraudService.normalizeEmail(u.email) === normalized)) {
      reasons.push('email déjà utilisé (variante)');
      risk += 100;
    }

    // Nom d'utilisateur trop proche d'un autre (anti multi-compte paresseux)
    const similar = await this.db.get(
      `SELECT COUNT(*) AS n FROM users WHERE lower(username) = lower(?)`, [String(username).replace(/\d+$/, '')]
    );
    if (similar && similar.n > 0) { risk += 15; }

    return { allowed: risk < 60, risk, reasons };
  }

  /**
   * Contrôles avant de créditer une réclamation.
   * (Le contrôle atomique du cooldown est fait dans le service de réclamation ;
   *  ici on mesure le risque résiduel pour la notation du compte.)
   */
  async scoreClaim({ userId, ip, userAgent }) {
    const reasons = [];
    let risk = 0;
    const row = await this.db.get(
      `SELECT COUNT(*) AS n FROM claims WHERE ip = ? AND created_at >= datetime('now','-10 minutes')`, [ip]
    );
    if (row && row.n >= 4) { reasons.push('activité IP élevée'); risk += 30; }
    if (userAgent && SUSPICIOUS.some((r) => r.test(userAgent))) { reasons.push('client suspect'); risk += 40; }
    return { risk, reasons };
  }

  /** Met à jour le score de risque d'un membre et suspend au-delà du seuil. */
  async applyRisk(userId, delta, reasons = []) {
    if (delta <= 0) return;
    const threshold = 100;
    const row = await this.db.get('SELECT risk_score, status FROM users WHERE id = ?', [userId]);
    if (!row) return;
    const score = row.risk_score + delta;
    const status = score >= threshold && row.status === 'active' ? 'suspended' : row.status;
    await this.db.run('UPDATE users SET risk_score = ?, status = ?, updated_at = datetime(\'now\') WHERE id = ?', [score, status, userId]);
    if (status !== row.status) {
      await this.db.run(
        `INSERT INTO audit_log (actor_id, action, target, meta) VALUES (NULL, 'auto_suspend', ?, ?)`,
        [String(userId), JSON.stringify({ score, reasons })]
      );
    }
  }
}

module.exports = { AntifraudService };
