'use strict';
/**
 * Service SHORTLINKS (Étape 4).
 *
 * Modèle de revenus :
 *   le réseau partenaire paie le propriétaire au CPM (par 1000 vues validées).
 *   Le membre reçoit une part (revenue_share du partenaire, en %) convertie en sats.
 *
 * Cycle de vie d'une session :
 *   1. start()          → crée un jeton unique (pending) + URL de retour signée HMAC
 *   2. redirection      → vers l'URL du partenaire, avec l'URL de retour en paramètre
 *   3. retour visiteur  → complete() : signature + délai minimal + unicité + quotas
 *   4. crédit           → claims + ledger + compteur d'audience (revenus)
 *
 * Règle absolue : AUCUN crédit sans retour validé par le partenaire (signature HMAC
 * sur le jeton, délai minimal réellement écoulé, session non déjà utilisée).
 * En mode "demo" (partner.callback_secret vide), la validation est simulée : utile
 * pour tester l'interface, jamais pour payer de vrais utilisateurs.
 */
const crypto = require('node:crypto');
const { hmac, safeEqual } = require('../lib/security');

class ShortlinkError extends Error {
  constructor(message, { status = 400, code = 'shortlink_error', details } = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

class ShortlinkService {
  constructor(db, settings, config) {
    this.db = db;
    this.settings = settings;
    this.config = config;
  }

  async enabled() {
    const cfg = await this.settings.all();
    return Boolean(cfg.modules && cfg.modules.shortlinks);
  }

  /** Liste des liens disponibles pour un membre (avec quotas restants). */
  async listForUser(user) {
    const cfg = await this.settings.all();
    const enabled = Boolean(cfg.modules && cfg.modules.shortlinks);
    const links = await this.db.all(
      `SELECT s.id, s.title, s.reward_sats, s.daily_limit, s.status, p.name AS partner_name, p.type AS partner_type
       FROM shortlinks s LEFT JOIN partners p ON p.id = s.partner_id
       WHERE s.status = 'active' ORDER BY s.id ASC`
    );
    const today = await this.db.get(
      `SELECT COUNT(*) AS n FROM claims WHERE user_id = ? AND module = 'shortlink'
         AND status = 'credited' AND date(created_at) = date('now')`, [user.id]
    );
    const perLink = await this.db.all(
      `SELECT ref_id, COUNT(*) AS n FROM claims
       WHERE user_id = ? AND module = 'shortlink' AND status = 'credited' AND date(created_at) = date('now')
       GROUP BY ref_id`, [user.id]
    );
    const counts = Object.fromEntries(perLink.map((r) => [r.ref_id, r.n]));
    return {
      enabled,
      daily_limit: cfg.shortlink_daily_limit,
      claims_today: today ? today.n : 0,
      remaining_today: Math.max(0, cfg.shortlink_daily_limit - (today ? today.n : 0)),
      min_dwell: cfg.shortlink_min_dwell,
      items: links.map((l) => ({
        ...l,
        used_today: counts[l.id] || 0,
        remaining: Math.max(0, l.daily_limit - (counts[l.id] || 0)),
      })),
    };
  }

  /** Construit l'URL de retour signée (HMAC du token). */
  returnUrl(token, origin) {
    const base = (origin || this.config.siteUrl).replace(/\/$/, '');
    const sig = hmac(this.config.sessionSecret, `shortlink:${token}`).slice(0, 40);
    return `${base}/shortlink/return?token=${encodeURIComponent(token)}&sig=${sig}`;
  }

  /**
   * Démarre une session : renvoie l'URL vers laquelle rediriger le membre.
   * @returns {{session_token, redirect_url, return_url, demo}}
   */
  async start(user, shortlinkId, { origin = null } = {}) {
    if (!(await this.enabled())) {
      throw new ShortlinkError('Le module shortlinks est désactivé.', { status: 503, code: 'module_off' });
    }
    if (user.status !== 'active') throw new ShortlinkError('Compte non actif.', { status: 403, code: 'status' });

    const cfg = await this.settings.all();
    const today = await this.db.get(
      `SELECT COUNT(*) AS n FROM claims WHERE user_id = ? AND module = 'shortlink'
         AND status = 'credited' AND date(created_at) = date('now')`, [user.id]
    );
    if (today && today.n >= cfg.shortlink_daily_limit) {
      throw new ShortlinkError('Limite journalière de shortlinks atteinte.', {
        status: 429, code: 'daily_limit', details: { limit: cfg.shortlink_daily_limit },
      });
    }

    const link = await this.db.get(
      `SELECT s.*, p.network_url, p.callback_secret, p.cpm_usd, p.revenue_share, p.status AS partner_status
       FROM shortlinks s LEFT JOIN partners p ON p.id = s.partner_id
       WHERE s.id = ? AND s.status = 'active'`, [shortlinkId]
    );
    if (!link) throw new ShortlinkError('Lien introuvable ou inactif.', { status: 404, code: 'not_found' });
    if (link.partner_status && link.partner_status !== 'active') {
      throw new ShortlinkError('Partenaire suspendu : lien indisponible.', { status: 503, code: 'partner_paused' });
    }

    const used = await this.db.get(
      `SELECT COUNT(*) AS n FROM claims WHERE user_id = ? AND module = 'shortlink' AND ref_id = ?
         AND status = 'credited' AND date(created_at) = date('now')`, [user.id, shortlinkId]
    );
    if (used && used.n >= link.daily_limit) {
      throw new ShortlinkError('Vous avez atteint la limite quotidienne pour ce lien.', { status: 429, code: 'link_limit' });
    }

    const token = crypto.randomBytes(24).toString('base64url');
    const returnUrl = this.returnUrl(token, origin);
    const demo = !link.callback_secret;

    await this.db.run(
      `INSERT INTO shortlink_sessions (id, user_id, shortlink_id, status, reward_sats) VALUES (?, ?, ?, 'pending', ?)`,
      [token, user.id, shortlinkId, link.reward_sats]
    );

    let redirectUrl;
    if (demo) {
      // Mode démonstration : pas de partenaire réel → le membre revient directement
      // sur notre propre page de retour (la validation par signature reste exigée).
      redirectUrl = returnUrl;
    } else {
      // Réseaux partenaires : ils attendent l'URL de destination finale en paramètre.
      const base = String(link.network_url || '').trim();
      if (!base) throw new ShortlinkError('Partenaire mal configuré (URL manquante).', { status: 500, code: 'bad_partner' });
      const sep = base.includes('?') ? '&' : '?';
      redirectUrl = `${base}${sep}${link.partner_type === 'ptc' ? 'url' : 'api'}=${encodeURIComponent(returnUrl)}`;
    }

    return {
      session_token: token,
      redirect_url: redirectUrl,
      return_url: returnUrl,
      demo,
      reward_sats: link.reward_sats,
      min_dwell: cfg.shortlink_min_dwell,
    };
  }

  /**
   * Valide une session au retour du visiteur et crédite la récompense.
   * @param {object} p { token, sig, user, ip, userAgent }
   */
  async complete({ token, sig, user, ip, userAgent }) {
    const expected = hmac(this.config.sessionSecret, `shortlink:${token}`).slice(0, 40);
    if (!sig || !safeEqual(expected, String(sig))) {
      throw new ShortlinkError('Retour non signé par le partenaire : récompense refusée.', { status: 403, code: 'bad_signature' });
    }

    const session = await this.db.get('SELECT * FROM shortlink_sessions WHERE id = ?', [token]);
    if (!session) throw new ShortlinkError('Session inconnue.', { status: 404, code: 'not_found' });
    if (session.user_id !== user.id) throw new ShortlinkError('Session appartient à un autre membre.', { status: 403, code: 'wrong_user' });
    if (session.status === 'validated') throw new ShortlinkError('Récompense déjà versée pour ce clic.', { status: 409, code: 'already_validated' });
    if (session.status === 'rejected') throw new ShortlinkError('Session expirée ou rejetée.', { status: 409, code: 'rejected' });

    const cfg = await this.settings.all();
    const created = Date.parse(session.created_at.replace(' ', 'T') + 'Z');
    const elapsed = (Date.now() - created) / 1000;
    if (elapsed < cfg.shortlink_min_dwell) {
      throw new ShortlinkError(
        `Consultation trop courte (${Math.floor(elapsed)} s) : ${cfg.shortlink_min_dwell} secondes minimum.`,
        { status: 429, code: 'too_fast', details: { elapsed: Math.floor(elapsed), required: cfg.shortlink_min_dwell } }
      );
    }
    if (elapsed > 6 * 3600) {
      await this.db.run(`UPDATE shortlink_sessions SET status = 'rejected' WHERE id = ?`, [token]);
      throw new ShortlinkError('Session expirée (plus de 6 heures).', { status: 410, code: 'expired' });
    }

    const link = await this.db.get(
      `SELECT s.*, p.cpm_usd, p.revenue_share FROM shortlinks s LEFT JOIN partners p ON p.id = s.partner_id WHERE s.id = ?`,
      [session.shortlink_id]
    );
    const reward = session.reward_sats;

    const lid = crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex');

    const result = await this.db.atomic((tx) => {
      // 1. Verrou de session : aucune ligne modifiée ⇒ session déjà validée/rejetée
      const locked = tx.run(
        `UPDATE shortlink_sessions SET status = 'validated', validated_at = datetime('now'), ledger_ref = ?
         WHERE id = ? AND status = 'pending'`,
        [lid, token]
      );
      if (locked.changes === 0) throw new ShortlinkError('Session déjà traitée.', { status: 409, code: 'already_validated' });

      // 2. Création de la réclamation (conditionnée au verrou ci-dessus)
      const ins = tx.run(
        `INSERT INTO claims (user_id, module, ref_id, amount_sats, ip, user_agent, ledger_ref, status)
         SELECT ?, 'shortlink', ?, ?, ?, ?, ?, 'credited'
         WHERE EXISTS (SELECT 1 FROM shortlink_sessions WHERE ledger_ref = ?)`,
        [user.id, session.shortlink_id, reward, ip, String(userAgent || '').slice(0, 250), lid, lid]
      );

      // 3. Crédit du membre, conditionné à l'existence de la réclamation
      const credit = tx.run(
        `UPDATE users SET balance_sats = balance_sats + ?, total_earned_sats = total_earned_sats + ?
         WHERE id = ? AND EXISTS (SELECT 1 FROM claims WHERE ledger_ref = ?)`,
        [reward, reward, user.id, lid]
      );
      if (credit.changes === 0) throw new ShortlinkError('Crédit impossible (état incohérent).', { status: 500, code: 'inconsistent' });

      // 4. Grand livre
      tx.run(
        `INSERT INTO ledger (user_id, type, module, amount_sats, balance_after, meta, ref)
         VALUES (?, 'credit_reward', 'shortlink', ?, (SELECT balance_sats FROM users WHERE id = ?), ?, ?)`,
        [user.id, reward, user.id, JSON.stringify({ shortlink_id: session.shortlink_id, session: token }), lid]
      );

      // 5. Commission de parrainage
      tx.run(
        `UPDATE users SET balance_sats = balance_sats + CAST(? * r.percent / 100 AS INTEGER),
           total_earned_sats = total_earned_sats + CAST(? * r.percent / 100 AS INTEGER)
         FROM referrals r
         WHERE r.referred_id = ? AND users.id = r.referrer_id`,
        [reward, reward, user.id]
      );
      tx.run(
        `UPDATE referrals SET earned_sats = earned_sats + CAST(? * percent / 100 AS INTEGER) WHERE referred_id = ?`,
        [reward, user.id]
      );
      if (link && link.cpm_usd > 0) {
        tx.run(
          `INSERT INTO finance_entries (kind, category, amount_usd, note, entry_date)
           VALUES ('revenue', 'shortlinks', ?, 'vue shortlink validée', date('now'))`,
          [Number(link.cpm_usd) / 1000]
        );
      }
      return { claimId: ins.lastInsertRowid, wrote: ins.changes };
    });

    const fresh = await this.db.get('SELECT balance_sats FROM users WHERE id = ?', [user.id]);
    const commission = await this.db.get(
      `SELECT CAST(? * percent / 100 AS INTEGER) AS c FROM referrals WHERE referred_id = ?`, [reward, user.id]
    );

    return {
      ok: true,
      amount_sats: reward,
      balance_sats: fresh ? fresh.balance_sats : null,
      claim_id: result.claimId,
      referral_commission_sats: commission ? commission.c : 0,
      partner: link ? link.title : null,
    };
  }

  /* ----------------------------- Admin ------------------------------ */

  async createPartner({ name, type, networkUrl, callbackSecret, cpmUsd, revenueShare, notes }) {
    if (!name) throw new ShortlinkError('Nom du partenaire requis.');
    if (!['shortlink', 'offerwall', 'ptc', 'adsense'].includes(type)) throw new ShortlinkError('Type de partenaire invalide.');
    const r = await this.db.run(
      `INSERT INTO partners (name, type, network_url, callback_secret, cpm_usd, revenue_share, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [name, type, networkUrl || null, callbackSecret || null, Number(cpmUsd) || 0, Number(revenueShare) || 60, notes || null]
    );
    return { id: r.lastInsertRowid };
  }

  async createShortlink({ partnerId, title, targetUrl, rewardSats, dailyLimit }) {
    if (!title) throw new ShortlinkError('Titre requis.');
    const r = await this.db.run(
      `INSERT INTO shortlinks (partner_id, title, target_url, reward_sats, daily_limit, status)
       VALUES (?, ?, ?, ?, ?, 'active')`,
      [partnerId || null, title, targetUrl || '', Math.max(1, Number(rewardSats) || 15), Math.max(1, Number(dailyLimit) || 10)]
    );
    return { id: r.lastInsertRowid };
  }

  async setStatus(kind, id, status) {
    const table = kind === 'partner' ? 'partners' : 'shortlinks';
    if (!['active', 'paused', 'suspended'].includes(status)) throw new ShortlinkError('Statut invalide.');
    await this.db.run(`UPDATE ${table} SET status = ? WHERE id = ?`, [status, id]);
  }

  async adminList() {
    const partners = await this.db.all('SELECT * FROM partners ORDER BY id DESC');
    const links = await this.db.all(
      `SELECT s.*, p.name AS partner_name FROM shortlinks s LEFT JOIN partners p ON p.id = s.partner_id ORDER BY s.id DESC`);
    const stats = await this.db.get(
      `SELECT COUNT(*) AS n, COALESCE(SUM(amount_sats),0) AS sats FROM claims WHERE module = 'shortlink' AND status = 'credited'`);
    const revenue = await this.db.get(
      `SELECT COALESCE(SUM(amount_usd),0) AS usd FROM finance_entries WHERE kind = 'revenue' AND category = 'shortlinks'`);
    const sessions = await this.db.get(
      `SELECT SUM(CASE WHEN status = 'validated' THEN 1 ELSE 0 END) AS validated,
              SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending,
              SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected
       FROM shortlink_sessions`);
    return { partners, links, stats: { ...stats, revenue_usd: revenue.usd, sessions } };
  }
}

module.exports = { ShortlinkService, ShortlinkError };
