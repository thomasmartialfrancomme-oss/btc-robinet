'use strict';
/**
 * Point d'entrée du serveur BTC ROBINET.
 *   node src/server.js      (ou : npm start)
 */
const config = require('./lib/config');
const { createApp } = require('./app');

async function main() {
  const { errors, warnings } = config.validate();
  if (warnings.length) warnings.forEach((w) => console.warn('[avertissement]', w));

  // Première utilisation : .env absent => on le crée depuis .env.example
  // et on génère un secret de session aléatoire pour un démarrage immédiat.
  if (!process.env.__ENV_READY) {
    const fs = require('node:fs');
    const path = require('node:path');
    const envPath = path.join(config.root, '.env');
    if (!fs.existsSync(envPath) && fs.existsSync(path.join(config.root, '.env.example'))) {
      const crypto = require('node:crypto');
      let tpl = fs.readFileSync(path.join(config.root, '.env.example'), 'utf8');
      tpl = tpl.replace(/^SESSION_SECRET=.*$/m, `SESSION_SECRET=${crypto.randomBytes(32).toString('hex')}`);
      fs.writeFileSync(envPath, tpl, 'utf8');
      console.log('\n[info] Fichier .env créé depuis .env.example (secret de session généré).');
      console.log('[info] Relancez le serveur pour appliquer cette configuration.\n');
      process.env.__ENV_READY = '1';
      process.exit(0);
    }
  }

  if (errors.length) {
    errors.forEach((e) => console.error('[config] ERREUR:', e));
    console.error('\nCorrigez le fichier .env puis relancez. (Voir .env.example)');
    process.exit(1);
  }

  const app = createApp({ config });
  await app.init();

  const server = require('node:http').createServer((req, res) => {
    app.handle(req, res).catch((err) => {
      console.error('[fatal]', err);
      if (!res.headersSent) {
        res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      }
      if (!res.writableEnded) res.end(JSON.stringify({ ok: false, error: 'Erreur interne' }));
    });
  });

  server.listen(config.port, '0.0.0.0', () => {
    console.log(`\n  ⟠  BTC ROBINET — serveur démarré`);
    console.log(`     Local      : http://localhost:${config.port}`);
    console.log(`     Public     : ${config.siteUrl}`);
    console.log(`     FaucetPay  : mode=${config.faucetpay.mode} api=${config.faucetpay.apiVersion} paiements_réels=${config.faucetpay.livePayouts ? 'OUI' : 'NON (verrou fermé)'}`);
    console.log(`     Captcha    : ${config.captcha.mode}`);
    console.log(`     Base       : ${config.dbPath}\n`);
  });

  const shutdown = () => {
    console.log('\nArrêt du serveur...');
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 3000);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

main().catch((e) => {
  console.error('Démarrage impossible :', e);
  process.exit(1);
});
