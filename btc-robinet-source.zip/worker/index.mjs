/**
 * Cloudflare Worker — BTC ROBINET
 *
 * Réutilise l'intégralité du code applicatif de `src/` (aucune duplication) :
 *  - les fichiers statiques sont servis par la liaison `ASSETS` (dossier public/) ;
 *  - l'API et les pages protégées passent par `app.handle` via un shim Request/Response ;
 *  - la base est Cloudflare D1, exposée par un adaptateur à l'interface identique.
 *
 * Secrets / variables à configurer (wrangler secret put / [vars]) :
 *   SESSION_SECRET, SITE_URL, COOKIE_SECURE, CAPTCHA_MODE,
 *   FAUCETPAY_MODE, FAUCETPAY_API_VERSION, FAUCETPAY_API_KEY (ou clés v2), PAYOUTS_LIVE,
 *   TURNSTILE_SITE_KEY, TURNSTILE_SECRET_KEY
 */
import { buildConfig } from '../src/lib/config.js';
import { D1Adapter } from '../src/lib/d1.js';
import { createApp } from '../src/app.js';
import { handleToResponse } from '../src/lib/httpshim.js';

// Schéma embarqué (généré depuis db/schema.sql — voir npm run build:worker)
import SCHEMA from './schema.generated.js';

let cachedApp = null;
let lastDb = null;

async function getApp(env) {
  if (cachedApp && lastDb === env.DB) return cachedApp;

  const config = buildConfig(env);
  const db = new D1Adapter(env.DB);
  const app = createApp({ config, db, schemaSql: SCHEMA });
  await app.init();

  cachedApp = app;
  lastDb = env.DB;
  return app;
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    // 1. Fichiers statiques et pages publiques servis par les assets Cloudflare
    const pageAssets = new Set([
      '/', '/index.html', '/register', '/login', '/dashboard', '/faucet', '/shortlinks',
      '/ptc', '/offerwalls', '/referral', '/withdraw', '/history', '/admin', '/legal',
      '/css/style.css', '/js/app.js', '/js/layout.js', '/favicon.ico',
    ]);

    // Les pages privées doivent passer par le serveur (contrôle d'accès + redirections)
    const serverManaged = new Set([
      '/dashboard', '/faucet', '/shortlinks', '/ptc', '/offerwalls',
      '/referral', '/withdraw', '/history', '/admin',
    ]);

    if (request.method === 'GET' && !url.pathname.startsWith('/api/') && !serverManaged.has(url.pathname)) {
      if (pageAssets.has(url.pathname) || url.pathname.startsWith('/css/') || url.pathname.startsWith('/js/')) {
        // Réécriture : /register → /register.html pour les assets statiques
        const assetUrl = new URL(request.url);
        if (!assetUrl.pathname.includes('.')) assetUrl.pathname = `${assetUrl.pathname}.html`;
        return env.ASSETS.fetch(new Request(assetUrl.toString(), request));
      }
    }

    // 2. Tout le reste (API, pages privées, callbacks partenaires) → application
    try {
      const app = await getApp(env);
      return await handleToResponse(request, app);
    } catch (err) {
      console.error('[worker] échec global:', err && err.stack);
      return new Response(JSON.stringify({
        ok: false,
        error: 'Erreur interne du serveur (worker).',
        code: 'worker_error',
      }), { status: 500, headers: { 'Content-Type': 'application/json; charset=utf-8' } });
    }
  },
};
