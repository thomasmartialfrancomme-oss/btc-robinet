/* =====================================================================
   BTC ROBINET — ossature commune (header, navigation latérale, footer)
   ===================================================================== */
'use strict';

const NAV_PUBLIC = [
  ['/', 'Accueil'],
  ['/faucet', 'Robinet'],
  ['/shortlinks', 'Shortlinks'],
  ['/ptc', 'PTC'],
  ['/offerwalls', 'Offerwalls'],
];

const NAV_MEMBER = [
  ['/dashboard', '⊞', 'Tableau de bord'],
  ['/faucet', '₿', 'Robinet BTC'],
  ['/shortlinks', '🔗', 'Shortlinks'],
  ['/ptc', '📺', 'PTC'],
  ['/offerwalls', '🎯', 'Offerwalls'],
  ['/referral', '👥', 'Parrainage'],
  ['/withdraw', '💸', 'Retraits'],
  ['/history', '📜', 'Historique'],
];

const NAV_ADMIN = [['/admin', '⚙', 'Administration']];

function renderHeader(user, activePath) {
  const host = document.getElementById('siteHeader');
  if (!host) return;
  const links = NAV_PUBLIC.map(([href, label]) =>
    `<a href="${href}" class="${href === activePath ? 'active' : ''}">${label}</a>`).join('');
  const right = user
    ? `<a href="/dashboard">Tableau de bord</a>
       ${user.role === 'admin' ? '<a href="/admin">Admin</a>' : ''}
       <a href="#" data-logout class="cta">Déconnexion</a>`
    : `<a href="/login">Connexion</a><a href="/register" class="cta">Inscription</a>`;
  host.innerHTML = `
    <header class="site-header">
      <div class="container header-inner">
        <a class="brand" href="/">
          <span class="logo">₿</span>
          <span>BTC <span class="btc">ROBINET</span></span>
        </a>
        <button class="burger" aria-label="Menu">☰</button>
        <nav class="nav">${links}${right}</nav>
      </div>
    </header>`;
}

function renderSidebar(user, activePath) {
  const host = document.getElementById('sidebar');
  if (!host) return;
  const link = ([href, ico, label]) =>
    `<a class="side-link ${href === activePath ? 'active' : ''}" href="${href}">
       <span class="ico">${ico}</span><span>${label}</span></a>`;
  host.className = 'sidebar';
  host.innerHTML = `
    <div class="userbox">
      <strong data-user-name>${user ? user.username : ''}</strong>
      <span class="small muted" data-user-balance>${user ? user.balance_sats.toLocaleString('fr-FR') + ' sats' : ''}</span>
    </div>
    ${NAV_MEMBER.map(link).join('')}
    ${user && user.role === 'admin' ? NAV_ADMIN.map(link).join('') : ''}`;
}

function renderFooter() {
  const host = document.getElementById('siteFooter');
  if (!host) return;
  host.innerHTML = `
    <footer class="site-footer">
      <div class="container inner">
        <div>© ${new Date().getFullYear()} BTC ROBINET — Paiements via FaucetPay. Gains en satoshis.</div>
        <div class="row small" style="gap:1rem">
          <a href="/legal">Règlement &amp; conditions</a>
          <a href="/faucet">Robinet</a>
          <a href="/register">Créer un compte</a>
        </div>
      </div>
    </footer>`;
}

/** Prépare la page : header, footer, sidebar (si présente) et session. */
async function shell({ requireAuth = false, requireAdmin = false } = {}) {
  renderHeader(null, location.pathname);
  renderFooter();
  const me = await boot({ requireAuth, requireAdmin });
  if (!me) return null;
  renderHeader(me.authenticated ? me.user : null, location.pathname);
  if (me.authenticated) renderSidebar(me.user, location.pathname);
  const logout = document.querySelector('[data-logout]');
  if (logout) {
    logout.addEventListener('click', async (e) => {
      e.preventDefault();
      await API.post('/api/auth/logout', {}).catch(() => {});
      location.href = '/';
    });
  }
  return me;
}
