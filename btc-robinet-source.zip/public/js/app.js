/* =====================================================================
   BTC ROBINET — utilitaires front-end (aucune dépendance externe)
   ===================================================================== */
'use strict';

const API = {
  csrf: null,

  async request(method, url, body) {
    const headers = { 'Accept': 'application/json' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (method !== 'GET' && API.csrf) headers['X-CSRF-Token'] = API.csrf;
    let res;
    try {
      res = await fetch(url, {
        method,
        headers,
        body: body !== undefined ? JSON.stringify(body) : undefined,
        credentials: 'same-origin',
      });
    } catch (e) {
      throw new ApiError('Connexion au serveur impossible. Vérifiez votre réseau.', 0, 'network');
    }
    let data = null;
    const text = await res.text();
    try { data = text ? JSON.parse(text) : {}; } catch { data = { error: text }; }
    if (!res.ok) {
      throw new ApiError(data.error || `Erreur ${res.status}`, res.status, data.code, data.details);
    }
    return data;
  },

  get(url) { return this.request('GET', url); },
  post(url, body = {}) { return this.request('POST', url, body); },
};

class ApiError extends Error {
  constructor(message, status, code, details) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

/* ------------------------------- Format ------------------------------ */

const fmt = {
  sats(n) {
    const v = Number(n || 0);
    return v.toLocaleString('fr-FR') + ' sats';
  },
  btc(sats) {
    return (Number(sats || 0) / 1e8).toFixed(8) + ' BTC';
  },
  usd(n) {
    return Number(n || 0).toLocaleString('fr-FR', { style: 'currency', currency: 'USD' });
  },
  date(iso) {
    if (!iso) return '—';
    const s = String(iso).includes('T') ? iso : String(iso).replace(' ', 'T') + 'Z';
    const d = new Date(s);
    if (Number.isNaN(d.getTime())) return iso;
    return d.toLocaleString('fr-FR', {
      day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit',
    });
  },
  time(sec) {
    sec = Math.max(0, Math.floor(sec));
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return m > 0 ? `${m}:${String(s).padStart(2, '0')}` : `${s}s`;
  },
  esc(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  },
};

/* ------------------------------- Toasts ------------------------------ */

function toast(message, kind = 'info', ms = 4200) {
  let wrap = document.querySelector('.toast-wrap');
  if (!wrap) {
    wrap = document.createElement('div');
    wrap.className = 'toast-wrap';
    document.body.appendChild(wrap);
  }
  const el = document.createElement('div');
  el.className = 'toast ' + kind;
  el.textContent = message;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), ms);
}

function setAlert(target, message, kind = 'info') {
  const el = typeof target === 'string' ? document.querySelector(target) : target;
  if (!el) return;
  if (!message) { el.className = 'alert hidden'; el.textContent = ''; return; }
  el.className = 'alert ' + kind;
  el.textContent = message;
}

/* --------------------------- Header / nav ---------------------------- */

function initHeader(activePath, user) {
  const burger = document.querySelector('.burger');
  const nav = document.querySelector('.nav');
  if (burger && nav) burger.addEventListener('click', () => nav.classList.toggle('open'));
  document.querySelectorAll('.nav a, .side-link').forEach((a) => {
    const href = a.getAttribute('href');
    if (href && (href === activePath || (activePath === '/' && href === '/'))) a.classList.add('active');
  });
  if (user) {
    document.querySelectorAll('[data-user-name]').forEach((e) => { e.textContent = user.username; });
    document.querySelectorAll('[data-user-balance]').forEach((e) => { e.textContent = fmt.sats(user.balance_sats); });
    const logout = document.querySelector('[data-logout]');
    if (logout) {
      logout.addEventListener('click', async (e) => {
        e.preventDefault();
        await API.post('/api/auth/logout', {}).catch(() => {});
        location.href = '/';
      });
    }
  }
}

/* ------------------------------ Session ------------------------------ */

async function boot({ requireAuth = false, requireAdmin = false } = {}) {
  let me;
  try {
    me = await API.get('/api/me');
  } catch (e) {
    me = { authenticated: false };
  }
  if (me.authenticated) {
    API.csrf = me.csrf;
    initHeader(location.pathname, me.user);
  } else {
    initHeader(location.pathname, null);
    if (requireAuth) {
      location.href = '/login?next=' + encodeURIComponent(location.pathname);
      return null;
    }
  }
  if (requireAdmin && (!me.authenticated || me.user.role !== 'admin')) {
    location.href = me.authenticated ? '/dashboard?error=admin_required' : '/login?next=/admin';
    return null;
  }
  return me;
}

/* ------------------------------ Captcha ------------------------------ */

const Captcha = {
  mode: 'math',
  data: null,
  siteKey: null,

  async load(containerSelector) {
    const container = document.querySelector(containerSelector);
    if (!container) return;
    const cfg = await API.get('/api/auth/captcha').catch(() => ({ mode: 'off' }));
    this.mode = cfg.mode;
    if (cfg.mode === 'math') {
      this.data = cfg;
      container.innerHTML = `
        <div class="captcha-box">
          <span class="question">${fmt.esc(cfg.question)}</span>
          <input type="number" id="captchaAnswer" inputmode="numeric" placeholder="Réponse" autocomplete="off" required>
          <button type="button" class="btn btn-sm btn-ghost" id="captchaRefresh" title="Nouveau calcul">↻</button>
        </div>
        <div class="help">Captcha anti-robot — calcul vérifié côté serveur.</div>`;
      document.getElementById('captchaRefresh').addEventListener('click', () => this.load(containerSelector));
      return;
    }
    if (cfg.mode === 'turnstile') {
      this.siteKey = cfg.site_key;
      container.innerHTML = `<div id="turnstileWidget"></div>
        <div class="help">Vérification Cloudflare Turnstile.</div>`;
      const s = document.createElement('script');
      s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      s.async = true;
      s.onload = () => {
        if (window.turnstile) {
          window.turnstile.render('#turnstileWidget', { sitekey: this.siteKey, theme: 'dark' });
        }
      };
      document.head.appendChild(s);
      return;
    }
    container.innerHTML = '';
  },

  payload() {
    if (this.mode === 'math') {
      if (!this.data) return {};
      const answer = document.getElementById('captchaAnswer');
      return {
        captcha_challenge: this.data.challenge,
        captcha_signature: this.data.signature,
        captcha_answer: answer ? answer.value : '',
      };
    }
    if (this.mode === 'turnstile') {
      const token = window.turnstile ? window.turnstile.getResponse() : null;
      return token ? { turnstile_token: token } : {};
    }
    return {};
  },

  reset() {
    if (this.mode === 'turnstile' && window.turnstile) window.turnstile.reset();
    if (this.mode === 'math') this.load('.captcha-slot');
  },
};

/* ------------------------------- Copy -------------------------------- */

function initCopyButtons(root = document) {
  root.querySelectorAll('[data-copy]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const sel = btn.getAttribute('data-copy');
      const el = document.querySelector(sel);
      const text = el ? (el.value || el.textContent) : sel;
      try {
        await navigator.clipboard.writeText(text);
        toast('Copié dans le presse-papiers', 'ok', 2200);
      } catch {
        toast('Copie impossible — sélectionnez le texte manuellement.', 'err');
      }
    });
  });
}

/* --------------------------- Petites aides --------------------------- */

function statusBadge(status) {
  const map = {
    sent: ['ok', 'envoyé'], simulated: ['info', 'simulé'], pending: ['warn', 'en attente'],
    failed: ['err', 'échec'], cancelled: ['err', 'annulé'], credited: ['ok', 'crédité'],
    reversed: ['err', 'annulé'], active: ['ok', 'actif'], suspended: ['warn', 'suspendu'],
    banned: ['err', 'banni'], admin: ['info', 'admin'],
  };
  const [cls, label] = map[status] || ['', status];
  return `<span class="badge ${cls}">${fmt.esc(label)}</span>`;
}

function download(filename, content, type = 'text/plain') {
  const blob = new Blob([content], { type });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

function params() {
  return new URLSearchParams(location.search);
}
