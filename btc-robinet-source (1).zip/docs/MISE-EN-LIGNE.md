# Mise en ligne — BTC ROBINET

Deux chemins possibles. Le premier est le plus rapide et le moins cher ; le second
respecte strictement votre cahier des charges (Cloudflare Workers + D1 + 0 €).

---

## Option A — VPS ou hébergement Node (le plus simple, opérationnel en 1 h)

Le projet est **déjà** une application Node complète (SQLite + serveur HTTP).
Il suffit d'un hébergement qui exécute Node 18+.

### A.1 Offres gratuites / à 0 € à vérifier avant déploiement

| Hébergeur | Offre gratuite | Limites à connaître |
|---|---|---|
| **Render** | Web Service gratuit | mise en veille après inactivité (démarrage ~30 s), disques persistants payants → base perdue au redéploiement |
| **Railway** | Crédit d'essai | facturation à l'usage ensuite |
| **Fly.io** | petite allocation gratuite | carte bancaire demandée, volumes payants |
| **Oracle Cloud Free Tier** | VM ARM gratuite à vie | inscription + carte, configuration manuelle |
| **Vercel / Netlify** | statique / fonctions | **ne convient pas** tel quel (serveur Node + SQLite persistant) |

> ⚠️ Point critique : sur tous les hébergeurs gratuits **sans disque persistant**,
> le fichier SQLite est effacé à chaque redéploiement (tous les soldes membres
> disparaissent). Solutions : (a) disque persistant (souvent payant, 1–5 $/mois) ;
> (b) la base managée D1 de l'option B ; (c) VPS avec disque (Oracle gratuit).

### A.2 Procédure type (exemple Render)

1. Poussez le dossier dans un dépôt **privé** GitHub (⚠ `.env` et `data/` sont exclus
   par `.gitignore` : ne les ajoutez jamais).
2. Render → *New → Web Service* → sélectionnez le dépôt.
   - Build : `npm install`
   - Start : `npm start`
   - Node : 20
3. Variables d'environnement à saisir dans l'interface (jamais dans le code) :
   `SESSION_SECRET`, `SITE_URL=https://votre-domaine`, `COOKIE_SECURE=true`,
   `NODE_ENV=production`, plus les variables FaucetPay quand vous les aurez.
4. Ajoutez un **disque persistant** monté sur `/var/data` et mettez
   `DB_PATH=/var/data/btc-robinet.db`.
5. Créez l'administrateur : onglet *Shell* → `node scripts/create-admin.js ...`.
6. Domaine : ajoutez votre domaine, activez HTTPS (automatique), puis mettez
   `SITE_URL` à jour et redéployez.

### A.3 Avant d'annoncer le site

- [ ] `COOKIE_SECURE=true` et HTTPS actif
- [ ] `SESSION_SECRET` unique (64 caractères)
- [ ] `PAYOUTS_LIVE=false` jusqu'à validation de vos tests
- [ ] Captcha `turnstile` activé (clés Cloudflare gratuites)
- [ ] Sauvegarde automatique du fichier `.db` (cron + copie hors site)
- [ ] Page `/legal` complétée (mentions légales, RGPD, fiscalité)
- [ ] Solde FaucetPay suffisant + alerte de solde bas

---

## Option B — Cloudflare Workers + D1 (✅ PORTÉ ET TESTÉ — recommandé, 0 €)

Le portage est **réalisé et validé dans le vrai runtime Cloudflare** : le code applicatif est
partagé, `worker/index.mjs` sert d'entrée, l'adaptateur D1 et le shim HTTP sont en place.

| Vérification | Commande | Résultat |
|---|---|---|
| Tests applicatifs (Node + SQLite) | `npm test` | 129/129 |
| Chemin Worker (adaptateur D1 simulé) | `npm run test:worker` | 21/21 |
| **Worker compilé exécuté dans `workerd` + vraie base D1** | `npm run test:workerd` | **28/28** |
| Bundle de déploiement | `npx wrangler deploy --dry-run` | 244 Kio (51,7 Kio gzip) |

Le test `workerd` reproduit un déploiement : schéma appliqué à une base D1 locale, Worker
démarré par Wrangler, parcours complet (inscription, réclamation, retrait refusé si solde
insuffisant, administration, modules). **Trois anomalies graves ont été trouvées et corrigées
grâce à lui** (voir `CLOUDFLARE.md`, section « Trois pièges du runtime Cloudflare ») : sans
cela le site aurait renvoyé des erreurs 500 et `/dashboard` aurait été accessible sans
connexion une fois déployé.

### B.1 Procédure de déploiement (≈ 20 minutes)

```bash
# 1. Compte Cloudflare gratuit : https://dash.cloudflare.com/sign-up

# 2. Outils
npm install -g wrangler
wrangler login                     # ouvre le navigateur

# 3. Créer la base D1 (noter l'ID renvoyé)
npx wrangler d1 create btc-robinet

# 4. Renseigner l'ID dans wrangler.toml
#    [[d1_databases]] → database_id = "…"

# 5. Créer les tables
npx wrangler d1 execute btc-robinet --file=db/schema.sql --remote

# 6. Secrets (jamais dans le fichier de configuration)
npx wrangler secret put SESSION_SECRET      # 64 caractères aléatoires
npx wrangler secret put FAUCETPAY_API_KEY   # quand vous l'aurez
npx wrangler secret put TURNSTILE_SITE_KEY
npx wrangler secret put TURNSTILE_SECRET_KEY

# 7. Vérifier, régénérer le schéma + les pages embarqués, puis déployer
npm run test:all                   # 129 + 21 + 28 contrôles
npm run build:worker               # schéma + pages dans le bundle
npx wrangler deploy --dry-run      # contrôle du bundle, sans rien publier
npx wrangler deploy
```

> ⚠️ Ne retirez pas `html_handling = "none"` de la section `[assets]` de `wrangler.toml` :
> sans cette ligne, Cloudflare sert `dashboard.html` directement et les zones privées
> deviennent accessibles sans connexion.

Puis mettez `SITE_URL` (dans `wrangler.toml`) à l'URL renvoyée par `wrangler deploy`,
relancez `npx wrangler deploy`, et créez votre administrateur :

```bash
npx wrangler d1 execute btc-robinet --remote --command \
  "INSERT INTO users (username, email, password_hash, payout_address, referral_code, role, status)
   VALUES ('admin','vous@exemple.com','<hash>','vous@faucetpay.io','ADMIN01','admin','active')"
```
Le hash se génère en local :
```bash
node -e "const{hashPassword}=require('./src/lib/security');hashPassword('VotreMotDePasse!2026').then(h=>console.log(h))"
```

### B.2 Ce qui a été porté (et pourquoi)

| Point | Solution retenue | Fichier |
|---|---|---|
| HTTP Node → Web | shim `req`/`res` au-dessus de `Request`/`Response` | `src/lib/httpshim.js` |
| Base D1 | adaptateur même interface (`all/get/run/exec/atomic`) | `src/lib/d1.js` |
| Transactions | remplacées par des **écritures conditionnelles** + index UNIQUE (portables) | `src/services/*.js` |
| Hachage mot de passe | **PBKDF2-SHA256 210 000 itérations** (scrypt absent des Workers) | `src/lib/security.js` |
| Configuration | `buildConfig(env)` pour lire les variables du Worker | `src/lib/config.js` |
| Fichiers statiques | liaison `ASSETS` + pages privées servies par le Worker | `worker/index.mjs` |

**Anti-double-réclamation** : l'index `UNIQUE(user_id, module, claim_slot)` où
`claim_slot = floor(horodatage / cooldown)` rend un double crédit **impossible au niveau
SQL**, y compris sous requêtes simultanées (testé : 6 requêtes concurrentes → 1 crédit).
**Anti-double-paiement** : `payouts.idempotency_key UNIQUE` + débit conditionnel
`UPDATE users SET balance = balance - ? WHERE balance >= ?`.
Ces deux mécanismes fonctionnent à l'identique en SQLite et en D1.

### B.3 Limites à vérifier avant ouverture

Offres gratuites Cloudflare (à revérifier le jour du déploiement) : Workers 100 000
requêtes/jour, D1 5 Go + 5 M lectures/jour + 100 000 écritures/jour, Turnstile gratuit.
Un robinet de quelques centaines de membres actifs reste dans ces limites ; au-delà,
l'offre Workers payante (≈ 5 $/mois) suffit largement.
Un point d'attention : D1 `batch()` écrit sans transaction longue — les écritures
conditionnelles utilisées ici garantissent l'intégrité, mais si vous ajoutez de nouvelles
règles métier, **ne réintroduisez pas de lectures dans `atomic()`**.

---

## Après la mise en ligne (commun aux deux options)

1. Soumettre le site aux annuaires de faucets (dutchycorp, faucetpay faucet list…) —
   c'est ce qui amène le trafic.
2. Créer les comptes partenaires (voir `docs/PARTENAIRES.md`) et **faire approuver le site**.
3. Dans `/admin`, saisir le vrai revenu par 1 000 points : le calculateur devient fiable.
4. Surveiller chaque semaine : coût par réclamation vs revenu par visiteur.
5. Ne jamais activer un module dont le partenaire interdit le trafic faucet.
