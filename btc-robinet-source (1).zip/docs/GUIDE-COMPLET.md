# BTC ROBINET — guide complet, étape par étape

Ce document reprend **tout** : de l'installation sur ton PC jusqu'à la mise en ligne
définitive et l'activation des paiements. Suis les phases dans l'ordre. Chaque commande est
donnée telle quelle, avec ce que tu dois voir à l'écran.

| Phase | Ce que tu obtiens | Temps | Bloqué par |
|---|---|---|---|
| 1 | Le site tourne sur ton PC | 10 min | rien |
| 2 | Le vrai code sur GitHub (+ tests automatiques) | 5 min | ton token GitHub |
| 3 | Le site en ligne, gratuitement, sur `workers.dev` | 20 min | ton compte Cloudflare |
| 4 | Les paiements FaucetPay réels | 15 min | ton compte FaucetPay + ton accord |
| 5 | Le site réglé à ta main (récompenses, modules) | 10 min | rien |
| 6 | Les partenaires (shortlinks, PTC, offerwalls) | variable | inscriptions partenaires |
| 7 | Entretien, sauvegardes, sécurité | 5 min/mois | rien |

---

# Phase 0 — Où on en est

**Déjà fait et vérifié (178 contrôles automatiques, 0 échec) :**

- Le site complet : accueil, inscription, connexion, tableau de bord, robinet BTC, shortlinks,
  PTC, offerwalls, parrainage, retraits, historique, administration, calculateur de rentabilité.
- Le portage Cloudflare testé dans le vrai moteur Cloudflare (`workerd`) + vraie base D1.
- Les 3 bugs qui auraient cassé le site en production sont corrigés et verrouillés par des tests.
- Un lien de démonstration temporaire existe, mais il **meurt quand l'atelier s'arrête**.
  Ce n'est pas un hébergement. La phase 3 le remplace par une vraie adresse permanente.

**Ce qui reste, et pourquoi je ne peux pas le faire à ta place :** GitHub, Cloudflare et
FaucetPay exigent **tes** comptes. Je n'ai aucun identifiant, et je ne dois jamais en recevoir
(coller un token dans le chat revient à le publier).

---

# Phase 1 — Faire tourner le site sur ton PC (Windows)

> Objectif : voir le site marcher chez toi, avec ta propre base de données, sans rien publier.

### 1.1 Installer Node.js

1. Va sur <https://nodejs.org/fr/download> et télécharge la version **LTS** (bouton de gauche).
2. Lance le `.msi`, clique *Suivant* partout, laisse tout par défaut.
3. Ouvre l'**Invite de commandes** (touche Windows → tape `cmd` → Entrée) et tape :

```bat
node -v
npm -v
```

Tu dois voir `v20.x` (ou `v22.x`) puis `10.x`. Si « n'est pas reconnu comme commande
interne », **redémarre le PC** : le PATH se met à jour à la connexion.

### 1.2 Récupérer les fichiers

Décompresse le projet dans `C:\btc-robinet` — **pas** sur le Bureau, **pas** dans OneDrive,
**pas** dans un dossier avec un accent ou un espace : ces chemins cassent `better-sqlite3`.

```bat
cd C:\btc-robinet
dir
```

Tu dois voir `package.json`, `src`, `public`, `db`, `docs`, `wrangler.toml`.

### 1.3 Installer les dépendances

```bat
cd C:\btc-robinet
npm install
```

Une seule dépendance réelle (`better-sqlite3`), précompilée pour Windows : aucun compilateur
nécessaire. Erreur `MSB3428` / `node-gyp` ? Tu n'es pas sur la LTS → réinstalle Node en LTS,
supprime `node_modules`, refais `npm install`.

### 1.4 Premier démarrage

```bat
npm start
```

Au premier lancement, le serveur crée `.env` (avec un secret de session aléatoire) et te
demande de relancer **une fois** :

```
[info] Fichier .env créé depuis .env.example (secret de session généré).
[info] Relancez le serveur pour appliquer cette configuration.
```

`Ctrl+C`, puis `npm start` de nouveau. Tu dois voir :

```
BTC ROBINET en écoute sur http://localhost:3000
```

Ouvre <http://localhost:3000> dans ton navigateur.

### 1.5 Créer ton compte administrateur

Dans une **seconde** fenêtre `cmd` (laisse le serveur tourner) :

```bat
cd C:\btc-robinet
node scripts\create-admin.js monpseudo moi@exemple.com "MotDePasseSolide!2026" moi@faucetpay.io
```

Techniquement : le mot de passe doit faire **10 caractères minimum** ; il est stocké haché en
PBKDF2-SHA256 (210 000 itérations), jamais en clair. Connecte-toi sur
<http://localhost:3000/login>, tu arrives sur `/admin`.

> Le compte de démonstration `demo_admin` / `DemoAdmin2026!` existe dans les copies livrées :
> **supprime-le ou change son mot de passe** avant toute mise en ligne.

### 1.6 Vérifier que tout fonctionne sur ton PC

```bat
npm test        :: 129 contrôles — doit finir par « 0 échec(s) »
npm run test:worker
```

C'est tout : si ces deux lignes finissent par **0 échec**, ton installation est saine.

---

# Phase 2 — Publier le vrai code sur GitHub

> Pourquoi : ton dépôt ne contient aujourd'hui **qu'un fichier zip**. Résultat : `git clone`
> ne récupère rien d'utilisable, l'historique est vide et les tests automatiques ne tournent
> jamais. On remplace ce zip par les 79 fichiers.

### 2.1 Créer le token (5 clics)

1. <https://github.com/settings/tokens?type=beta> → **Generate new token** (fine-grained).
2. *Token name* : `btc-robinet-push`.
3. *Expiration* : **7 days**.
4. *Repository access* → **Only select repositories** → choisis `btc-robinet`.
5. *Permissions* → *Repository permissions* → **Contents** → passe à **Read and write**.
   (C'est le seul droit nécessaire. Ne coche rien d'autre.)
6. **Generate token** → copie le `github_pat_…` affiché (il n'apparaîtra plus jamais).

⚠️ Ce token ne se colle **jamais** dans une conversation, un fichier, un e-mail ou un commit.
Il vit dans la mémoire de ton terminal, le temps d'une commande.

### 2.2 Lancer la publication

Ouvre **PowerShell** dans `C:\btc-robinet` (clic droit sur le dossier → *Ouvrir dans le
Terminal*), puis :

```powershell
$env:GITHUB_TOKEN="github_pat_colle_ton_token_ici"
node scripts\push-moi.mjs
```

Ou, si tu préfères l'invite de commandes classique :

```bat
cd C:\btc-robinet
set GITHUB_TOKEN=github_pat_colle_ton_token_ici
scripts\push-moi.bat
```

Le script fait **7 étapes** et s'arrête au premier problème, sans jamais rien casser :

| Étape | Ce qu'il fait | Garde-fou |
|---|---|---|
| 1 | Vérifie le token et `git` | s'arrête si le token est absent |
| 2 | Lance `npm test` | **n'envoie rien** si un test échoue |
| 3 | Se connecte à GitHub | vérifie que tu as le droit d'écrire |
| 4 | Supprime le zip déposé | via l'API, avec le bon SHA |
| 5 | Prépare le dépôt local | vérifie qu'aucun `.env`/base/secrets ne part |
| 6 | `git push --force` | token passé en variable d'environnement, **jamais écrit sur le disque** |
| 7 | Relit le dépôt en ligne | compte les fichiers, vérifie la présence du workflow CI |

Sortie attendue à la fin :

```
✓ 79 fichiers en ligne
✓ archive zip absente
✓ workflow CI présent (les tests vont tourner)
Terminé.
```

### 2.3 Vérifier

1. <https://github.com/thomasmartialfrancomme-oss/btc-robinet> : tu dois voir `src/`,
   `public/`, `wrangler.toml`, `README.md`… et **plus de zip**.
2. <https://github.com/thomasmartialfrancomme-oss/btc-robinet/actions> : un rond orange puis
   vert. Deux tâches : *Tests* (Node 20 et 22) et *workerd*.
3. **Révoque le token** : <https://github.com/settings/tokens> → `Delete`. Il a fini son travail.

### 2.4 Si ça échoue

| Message | Cause | Solution |
|---|---|---|
| `token refusé (401)` | token expiré, révoqué, mal copié | régénère-le, attention aux espaces |
| `dépôt introuvable (404)` | le token n'a pas accès à ce dépôt | refais 2.1 en cochant bien `btc-robinet` |
| `pas le droit d'écrire` | *Contents* laissé en *Read* | refais 2.1, mets **Read and write** |
| `les tests échouent` | ton code local a été modifié | lance `npm test`, lis les ✘, corrige |

---

# Phase 3 — Mettre le site en ligne pour de vrai (Cloudflare, 0 €)

> Résultat : une adresse permanente `https://btc-robinet.<ton-sous-domaine>.workers.dev`,
> gratuite, avec base D1 incluse. C'est cette adresse que tu partageras — plus de lien
> temporaire.

### 3.1 Créer le compte

<https://dash.cloudflare.com/sign-up> — e-mail + mot de passe, **aucune carte bancaire**
pour l'offre gratuite. Valide l'e-mail de confirmation.

### 3.2 Installer Wrangler et te connecter

```bat
cd C:\btc-robinet
npm install -g wrangler
wrangler --version
wrangler login
```

`wrangler login` ouvre ton navigateur : clique **Allow**. Retour au terminal :
`Successfully logged in`.

### 3.3 Créer la base de données

```bat
wrangler d1 create btc-robinet
```

La sortie contient un bloc à recopier :

```toml
[[d1_databases]]
binding = "DB"
database_name = "btc-robinet"
database_id = "a1b2c3d4-5678-90ab-cdef-1234567890ab"   ← CETTE valeur
```

Ouvre `wrangler.toml` et remplace la ligne :

```toml
database_id = "REMPLACER_PAR_L_ID_RENVOYE_PAR_WRANGLER"
```

…par ton identifiant. Sans cette étape, le déploiement échoue.

### 3.4 Créer les tables **dans la vraie base**

```bat
wrangler d1 execute btc-robinet --file=db\schema.sql --remote
```

Tu dois voir une longue liste de `"success": true`. C'est cette commande qui installe les 18
tables. (Le site sait aussi les créer tout seul au premier appel — mais le faire ici évite un
premier chargement lent.)

### 3.5 Enregistrer les secrets

Génère d'abord une clé de session solide :

```bat
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Copie le résultat (64 caractères) puis :

```bat
wrangler secret put SESSION_SECRET
```

Colle la valeur, Entrée. Répète pour la suite **quand tu en auras besoin** :

```bat
wrangler secret put TURNSTILE_SITE_KEY
wrangler secret put TURNSTILE_SECRET_KEY
wrangler secret put FAUCETPAY_API_KEY        :: phase 4 seulement
```

> Un secret n'est jamais dans `wrangler.toml`, jamais dans Git. `wrangler secret` le stocke
> chiffré chez Cloudflare et il n'est plus jamais réaffichable.

### 3.6 Vérifier puis déployer

```bat
npm run test:all
npm run build:worker
wrangler deploy --dry-run
wrangler deploy
```

- `test:all` → 178 contrôles, 0 échec.
- `build:worker` → régénère le schéma et les 13 pages embarqués.
- `deploy --dry-run` → affiche `Total Upload: 244 KiB`, rien n'est publié.
- `deploy` → publie et affiche ton URL :

```
Published btc-robinet
  https://btc-robinet.ton-sous-domaine.workers.dev
```

### 3.7 Mettre la bonne adresse dans la configuration

Dans `wrangler.toml`, remplace la ligne `SITE_URL` :

```toml
SITE_URL = "https://btc-robinet.ton-sous-domaine.workers.dev"
```

puis redéploie (l'adresse sert aux liens de parrainage et de retour des shortlinks) :

```bat
wrangler deploy
```

### 3.8 Créer ton administrateur **en ligne**

Génère le hash :

```bat
node -e "const{hashPassword}=require('./src/lib/security');hashPassword('TonMotDePasse!2026').then(h=>console.log(h))"
```

Crée un fichier `admin.sql` à la racine, avec **ton** pseudo, **ton** e-mail et le hash obtenu :

```sql
INSERT INTO users (username, email, password_hash, payout_address, referral_code, role, status)
VALUES ('admin','moi@exemple.com','pbkdf2$210000$............','monpseudo@faucetpay.io','ADMIN01','admin','active');
```

Puis :

```bat
wrangler d1 execute btc-robinet --file=admin.sql --remote
```

> Passe par un fichier `.sql` plutôt que par `--command` : PowerShell déforme les guillemets
> et les `$` du hash. Supprime `admin.sql` ensuite (il contient un hash de mot de passe).

### 3.9 Contrôles de sécurité à faire tout de suite

Sur ton URL publique :

| Test | Résultat attendu |
|---|---|
| ouvrir `/` | page d'accueil, mode test affiché |
| ouvrir `/dashboard` **sans être connecté** | **redirection** vers `/login?next=/dashboard` |
| ouvrir `/admin` **sans être connecté** | redirection vers `/login` |
| se connecter en membre puis ouvrir `/admin` | renvoi vers `/dashboard?error=admin_required` |
| ouvrir `/api/public/config` | JSON public, **aucune clé** |
| demander deux réclamations d'affilée | la seconde est refusée (`cooldown`) |

Si `/dashboard` s'ouvre **sans** connexion : tu as perdu `html_handling = "none"` dans
`[assets]` de `wrangler.toml`. Remets-le et redéploie. C'est la faille n°3 de la phase 0.

### 3.10 Activer le captcha Turnstile (recommandé avant d'ouvrir au public)

1. <https://dash.cloudflare.com> → **Turnstile** → *Add widget*.
2. *Widget name* : `btc-robinet` ; *Hostnames* : ton sous-domaine `workers.dev`.
3. Tu obtiens une **Site Key** (publique) et une **Secret Key**.
4. ```bat
   wrangler secret put TURNSTILE_SITE_KEY
   wrangler secret put TURNSTILE_SECRET_KEY
   ```
5. Dans `wrangler.toml` : `CAPTCHA_MODE = "turnstile"`, puis `wrangler deploy`.

Tant que tu restes en `math`, le captcha est un simple calcul — suffisant pour tester, trop
faible pour un site public.

### 3.11 Ce que tu as le droit de consommer (offre gratuite)

| Ressource | Offre gratuite | Ton usage typique |
|---|---|---|
| Requêtes Worker | 100 000/jour | ~2 000 pour 500 membres actifs |
| Écritures D1 | 100 000/jour | ~1 500 pour 500 membres |
| Stockage D1 | 5 Go | quelques Mo |
| Turnstile | gratuit | — |

Au-delà, l'offre Workers payante (~5 $/mois) suffit très largement. **Vérifie ces chiffres le
jour du déploiement** : Cloudflare les fait évoluer.

---

# Phase 4 — Activer les paiements FaucetPay réels

> ⚠️ Cette phase engage de l'argent réel. Le site est livré avec le verrou
> `PAYOUTS_LIVE=false` : tant qu'il est fermé, **aucun satoshi ne sort**, les retraits sont
> journalisés « simulés ». N'ouvre ce verrou qu'après avoir lu cette phase en entier.

### 4.1 Le compte faucet

1. <https://faucetpay.io> → inscription, puis **Faucet owner dashboard**.
2. *Manage* → **API & Webhooks** → génère une clé API.
3. **Whitelist d'IP** (API v1) : renseigne l'IP de sortie de ton Worker. En pratique, avec
   Cloudflare, l'API v1 peut refuser (`401 IP not whitelisted`) → dans ce cas, utilise l'**API
   v2** (clés scoped, pas de whitelist d'IP) : `FAUCETPAY_API_VERSION=v2` avec une clé
   `read` et une clé `send` séparées.
4. **Approvisionne le faucet** : les paiements partent du solde du faucet, pas de ton solde
   personnel. Solde insuffisant = `402 insufficient faucet balance`.

### 4.2 Configurer

```bat
:: API v1 (clé unique)
wrangler secret put FAUCETPAY_API_KEY
:: ou API v2 (deux clés scoped)
wrangler secret put FAUCETPAY_V2_READ_KEY
wrangler secret put FAUCETPAY_V2_SEND_KEY
```

Dans `wrangler.toml` :

```toml
FAUCETPAY_MODE = "faucetpay"
FAUCETPAY_API_VERSION = "v2"     # ou "v1"
```

Puis `wrangler deploy`. **`PAYOUTS_LIVE` reste `"false"`.**

### 4.3 Le test payant, encadré (obligatoire avant d'ouvrir)

1. Dans `/admin`, mets le **retrait minimum à 50 sats**.
2. Réclame 50 sats avec **ton propre compte de test**.
3. Vérifie que l'**adresse FaucetPay est validée** (`/api/payouts/verify-address`).
4. Passe le verrou :
   ```bat
   :: wrangler.toml
   PAYOUTS_LIVE = "true"
   ```
   `wrangler deploy`, puis demande **un seul** retrait de 50 sats.
5. Contrôles :
   - le solde du membre a bien diminué du montant **+ frais** ;
   - la ligne apparaît dans `payouts` avec un identifiant FaucetPay ;
   - **rejoue la même demande** : `idempotency_key` identique → aucun second débit ;
   - vide volontairement le solde du faucet et retente : tu dois obtenir un refus propre
     (`402`), **jamais** un solde négatif.
6. Si tout est bon, remets le minimum de retrait à sa valeur réelle (ex. 500 sats).

### 4.4 Les cas d'erreur déjà gérés

| Code FaucetPay | Signification | Comportement du site |
|---|---|---|
| 401 | IP non autorisée / owner suspendu | erreur claire, aucun débit conservé |
| 402 | solde faucet insuffisant | retrait refusé, solde du membre intact |
| 403 | clé API invalide | erreur de configuration signalée |
| 405 | montant invalide | refusé avant l'appel |
| 410 | devise invalide | refusé avant l'appel |
| 450/456/457 | limite ou destinataire refusé | message explicite au membre |
| 459 | trop de requêtes | réessai ultérieur, pas de doublon |

---

# Phase 5 — Régler le site à ta main (5 à 10 min)

Connecte-toi en admin → **`/admin`**. Tout se règle sans toucher au code.

| Réglage | Où | Conseil de départ |
|---|---|---|
| Récompense par réclamation | *Réglages* | 25 sats (≈ 0,02 $ à 90 000 $/BTC) |
| Délai entre deux réclamations | *Réglages* | 180 s (3 min) |
| Réclamations par jour | *Réglages* | 30 → plafonne le coût/jour/membre |
| Retrait minimum | *Réglages* | 500 sats |
| % de parrainage | *Réglages* | 20 % |
| Modules shortlinks / PTC / offerwalls | *Modules* | activer seulement avec un partenaire réel |
| Partenaires & liens | *Partenaires* | voir phase 6 |
| Rentabilité | *Rentabilité* | revenus − récompenses − hébergement − frais |

**Règle d'or de la rentabilité :** la récompense moyenne par membre et par jour doit rester
**inférieure** au revenu publicitaire moyen par membre et par jour. Le calculateur affiche
jour / semaine / mois ; regarde le **net** en rouge avant d'augmenter une récompense.

---

# Phase 6 — Partenaires : shortlinks, PTC, offerwalls

Le code est prêt et testé, mais **aucun partenaire n'est branché** : il faut tes comptes.

### 6.1 Shortlinks

1. Inscris-toi chez un raccourcisseur compatible faucet (ShrinkMe, Exe.io, etc.).
2. Récupère ton identifiant de publisher et le CPM.
3. Dans `/admin` → *Partenaires* → créer un partenaire `shortlink`, puis un lien avec sa
   récompense en sats.
4. Active le module **shortlinks**.

Le crédit n'est accordé **que** si le retour est validé après le délai minimal côté serveur :
un clic non validé ne rapporte rien (testé).

### 6.2 PTC

1. Dans `/admin` → *PTC* : annonceur, URL cible, durée, récompense, budget, limite/jour.
2. Alimente le budget (`fund`), passe l'annonce en `active`, active le module.
3. Une vue est créditée seulement si le temps de visibilité est atteint.

### 6.3 Offerwalls

1. Choisis un réseau d'offerwall qui accepte les faucets.
2. Dans `/admin` → *Partenaires* : type `offerwall`, `network_url`, **`callback_secret`**
   (fourni par le réseau).
3. Donne au réseau cette URL de rappel :
   `https://TON-SITE.workers.dev/api/offerwalls/<ID_PARTENAIRE>/callback`
4. Chaque callback est **vérifié par signature HMAC-SHA256** puis rendu **idempotent** :
   rejoué, il crédite 0 satoshi. Active le module.

⚠️ Aucune triche : pas de clic artificiel, pas de faux visiteur, pas de récompense sans
validation du partenaire. C'est écrit dans `CONTRIBUTING.md` et c'est la condition pour ne pas
être banni des réseaux.

---

# Phase 7 — Entretien, sauvegardes, sécurité

### 7.1 Sauvegarde de la base (à faire chaque semaine)

```bat
wrangler d1 export btc-robinet --remote --output=sauvegarde-%date%.sql
```

Conserve ces fichiers hors de Git (ils contiennent des e-mails et des adresses de paiement).

### 7.2 Routines

| Fréquence | Action |
|---|---|
| chaque semaine | export D1 (ci-dessus) + coup d'œil à *Rentabilité* |
| chaque mois | mettre à jour `wrangler` (`npm i -g wrangler@latest`), relancer `npm run test:all` |
| au moindre doute | révoquer un token GitHub, régénérer `SESSION_SECRET` (déconnecte tout le monde) |
| avant chaque déploiement | `npm run test:all` puis `wrangler deploy --dry-run` |

### 7.3 Les cinq choses à ne jamais faire

1. **Ne jamais** mettre `.env`, une clé API ou un token dans Git (le script le vérifie, mais
   reste vigilant).
2. **Ne jamais** retirer `html_handling = "none"` de `wrangler.toml` → zones privées ouvertes.
3. **Ne jamais** passer `PAYOUTS_LIVE=true` avant d'avoir fait le test à 50 sats de la phase 4.3.
4. **Ne jamais** payer un membre si le solde du faucet est insuffisant : le code refuse déjà,
   ne contourne pas ce refus.
5. **Ne jamais** mettre une clé API dans le code du navigateur (`public/`) : tout passe par le
   serveur.

### 7.4 Aspects légaux (à trancher par toi)

Un robinet qui paie de la cryptomonnaie et diffuse de la publicité touche à plusieurs sujets :
mentions légales, conditions d'utilisation, données personnelles (e-mail, adresse de paiement),
et selon ton pays fiscalité sur les revenus publicitaires. La page `/legal` fournit une base à
compléter. Ce n'est pas un conseil juridique : renseigne-toi localement avant d'ouvrir au public.

---

# Annexe A — Toutes les commandes utiles

| Commande | Effet |
|---|---|
| `npm install` | installe les dépendances |
| `npm start` | serveur local sur `http://localhost:3000` |
| `npm test` | 129 contrôles (serveur Node + SQLite) |
| `npm run test:worker` | 21 contrôles (chemin Cloudflare simulé) |
| `npm run test:workerd` | 28 contrôles dans le vrai runtime Cloudflare |
| `npm run test:all` | les trois + rapport consolidé |
| `npm run build:worker` | régénère le schéma et les pages embarqués |
| `npm run report` | régénère `docs/RAPPORT-DE-TESTS.md` |
| `node scripts\create-admin.js …` | crée/réinitialise un administrateur (local) |
| `wrangler login` | connecte Cloudflare |
| `wrangler d1 create btc-robinet` | crée la base, donne le `database_id` |
| `wrangler d1 execute btc-robinet --file=db\schema.sql --remote` | crée les tables en ligne |
| `wrangler secret put NOM` | enregistre un secret chiffré |
| `wrangler deploy --dry-run` | vérifie le bundle sans publier |
| `wrangler deploy` | publie |
| `wrangler d1 export btc-robinet --remote --output=…` | sauvegarde |
| `node scripts\push-moi.mjs` | publie le code sur GitHub |

# Annexe B — Dépannage express

| Symptôme | Cause probable | Solution |
|---|---|---|
| `EADDRINUSE :3000` | un serveur tourne déjà | ferme l'autre fenêtre, ou change `PORT` dans `.env` |
| `better-sqlite3` ne s'installe pas | Node non-LTS / chemin avec accent | réinstalle la LTS, déplace le dossier dans `C:\btc-robinet` |
| `git push` : `No anonymous write access` | pas de token / token sans droits | phase 2.1, droit *Contents: Read and write* |
| `wrangler deploy` : `database_id` invalide | phase 3.3 non faite | recopie l'identifiant renvoyé par `d1 create` |
| Le site en ligne renvoie 500 sur tout | secrets manquants | `wrangler secret put SESSION_SECRET` puis redéploie |
| `/dashboard` s'ouvre sans connexion | `html_handling` retiré | remets `html_handling = "none"` et redéploie |
| `402 insufficient faucet balance` | solde du faucet vide | approvisionne le compte faucet FaucetPay |
| `401 IP not whitelisted` | API v1 sans IP autorisée | passe en API v2 (clés scoped) |
| Un membre ne reçoit rien | adresse FaucetPay invalide | `/api/payouts/verify-address` doit répondre `ok` |
| Les modules sont vides | modules désactivés par défaut | `/admin` → *Modules* → activer, puis créer un partenaire |

# Annexe C — Ce que je peux encore faire pour toi

Sans aucun compte de ta part :

- écrire d'autres écrans, améliorer le design, ajouter des pages ;
- ajouter des tests, renforcer les contrôles antifraude ;
- rédiger les conditions d'utilisation et la politique de confidentialité ;
- préparer un script de sauvegarde automatique ou un tableau de bord de statistiques ;
- refaire le portage si Cloudflare change une règle.

Avec **tes** informations (jamais un token dans le chat, toujours par un script que tu lances) :

- t'accompagner pas à pas si une commande de ce guide échoue : copie-moi le message d'erreur,
  pas tes secrets.
