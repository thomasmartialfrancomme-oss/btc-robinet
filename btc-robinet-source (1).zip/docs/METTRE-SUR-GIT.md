# Mettre le code sur GitHub

> ## ✅ Méthode recommandée (une commande, testée)
>
> ```powershell
> $env:GITHUB_TOKEN="github_pat_xxx"      # token fine-grained, Contents: Read and write, 7 jours
> node scripts\push-moi.mjs
> ```
>
> ou en invite de commandes :
>
> ```bat
> set GITHUB_TOKEN=github_pat_xxx
> scripts\push-moi.bat
> ```
>
> Le script vérifie le token, **lance les tests**, supprime le zip déposé, envoie les 79
> fichiers, puis **vérifie en ligne** ce qui est réellement publié. Il s'arrête proprement au
> premier problème et n'écrit jamais le token sur le disque.
>
> Guide détaillé, étape par étape : `docs/GUIDE-COMPLET.md` (phase 2).


> ## ⚠️ État constaté le 12/11/2026
> - Dépôt cible : `https://github.com/thomasmartialfrancomme-oss/btc-robinet`
> - Il existe et il est **public**, mais **vide** (aucun commit).
> - Le push automatique est **impossible** : GitHub répond
>   `remote: No anonymous write access` — un envoi exige une authentification
>   (token ou clé SSH) que seul le propriétaire du compte peut fournir.
> - Le dépôt local est prêt : 4 commits, 68 fichiers, remote `origin` déjà configuré.
>   Il ne manque que l'authentification.
>
> 👉 **La solution la plus sûre, 30 secondes :** générer un token GitHub et l'utiliser
> dans le script fourni (`scripts/push-to-github.sh` ou `.bat`), qui ne l'écrit jamais
> sur le disque. Voir « Option 0 » ci-dessous.

Le dépôt Git est **déjà prêt** : 4 commits, 68 fichiers suivis, branche `main`,
`.gitignore` en place (aucun secret, aucune base, aucun `node_modules`).

---

## Option 0 — Script fourni, token jamais stocké (recommandé)

1. GitHub → *Settings → Developer settings → Personal access tokens → Fine-grained tokens*
   → **Generate new token** :
   - *Repository access* : **Only select repositories** → `btc-robinet`
   - *Permissions* → *Repository permissions* → **Contents : Read and write**
   - Expiration : 7 jours (le temps du push)
2. Lancez le script depuis le dossier du projet :

```bash
# Linux / macOS
GITHUB_TOKEN=github_pat_xxx ./scripts/push-to-github.sh
```

```bat
:: Windows
set GITHUB_TOKEN=github_pat_xxx
scripts\push-to-github.bat
```

Le script lance les tests, pousse `main`, puis vous rappelle de révoquer le token.
**Ne collez jamais le token dans une conversation, un fichier du dépôt ou un message.**

---

## Option 1 — Manuellement en ligne de commande

1. Créez un dépôt **vide** sur GitHub : <https://github.com/new>
   - Nom : `btc-robinet`
   - Visibilité : **Private** (recommandé : le code décrit votre modèle économique)
   - ⚠️ Ne cochez **pas** « Add a README », « .gitignore » ni « license » (le dépôt doit être vide)

2. Copiez-collez l'URL proposée par GitHub dans cette commande, puis exécutez-la
   depuis le dossier du projet :

```bash
cd btc-robinet
git remote set-url origin https://github.com/thomasmartialfrancomme-oss/btc-robinet.git
git push -u origin main
# Identifiant : votre nom d'utilisateur GitHub
# Mot de passe : le TOKEN personnel (pas votre mot de passe de compte)
```

GitHub demandera vos identifiants : utilisez un **token personnel**
(Settings → Developer settings → Personal access tokens → *Fine-grained*, droit
`Contents: Read and write` sur ce dépôt) comme mot de passe — GitHub n'accepte plus
les mots de passe simples en ligne de commande.

**Variantes** (mêmes deux commandes, autre URL) :

| Plateforme | URL à utiliser |
|---|---|
| GitLab | `https://gitlab.com/VOTRE_COMPTE/btc-robinet.git` |
| Codeberg / Gitea | `https://codeberg.org/VOTRE_COMPTE/btc-robinet.git` |
| Bitbucket | `https://bitbucket.org/VOTRE_COMPTE/btc-robinet.git` |

---

## Option 2 — Depuis votre PC Windows (si vous préférez tout faire en local)

```bat
:: 1. Décompressez btc-robinet-source.zip dans C:\btc-robinet
:: 2. Installez Git : https://git-scm.com/download/win
cd C:\btc-robinet
git init -b main
git add -A
git commit -m "BTC ROBINET - version initiale"
git remote add origin https://github.com/VOTRE_COMPTE/btc-robinet.git
git push -u origin main
```

---

## Option 3 — Récupérer l'historique complet (bundle Git)

Le fichier **`btc-robinet-repo.bundle`** contient le dépôt entier (commits, branches,
historique). Utile si vous voulez conserver les 2 commits existants :

```bash
git clone btc-robinet-repo.bundle btc-robinet
cd btc-robinet
git remote set-url origin https://github.com/VOTRE_COMPTE/btc-robinet.git
git push -u origin main
```

---

## Vérifications faites avant la remise

| Contrôle | Résultat |
|---|---|
| `.env` versionné ? | ❌ non (ignoré) — seul `.env.example` (placeholders) est présent |
| Base de données versionnée ? | ❌ non (`data/`, `*.db` ignorés) |
| `node_modules` versionné ? | ❌ non |
| Secret de session présent dans les fichiers suivis ? | ❌ non (recherche effectuée sur la valeur réelle) |
| Clé API FaucetPay en dur ? | ❌ non (lue uniquement depuis `process.env`) |
| Tests avant commit | ✅ 129 serveur + 13 Worker/D1, 0 échec |
| Restauration du bundle testée | ✅ clone propre → 66 fichiers, historique intact |

---

## Après le push

1. **Activez les tests automatiques** : l'onglet *Actions* exécutera
   `.github/workflows/ci.yml` (Node 20 et 22, tests serveur + Worker/D1) à chaque push.
2. **Protégez `main`** (Settings → Branches) et ajoutez vos secrets de déploiement
   dans *Settings → Secrets and variables → Actions* :
   `SESSION_SECRET`, `FAUCETPAY_API_KEY`, `CLOUDFLARE_API_TOKEN` (si déploiement Cloudflare).
3. **Ne mettez jamais** votre clé FaucetPay dans un fichier du dépôt, même privé :
   utilisez les secrets de la plateforme (`wrangler secret put` sur Cloudflare,
   variables d'environnement sur Render/Railway).

## Si un secret a été poussé par erreur

1. Révoquez-le immédiatement (FaucetPay → régénérer la clé ; Cloudflare → supprimer le token).
2. Retirez-le de l'historique :
   ```bash
   git filter-repo --path .env --invert-paths
   git push --force
   ```
3. Recréez un secret neuf. Un secret poussé est considéré comme compromis, même après suppression.
