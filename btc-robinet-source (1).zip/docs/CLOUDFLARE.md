# Cloudflare Workers + D1 — état du portage

**Statut : réalisé et testé dans le vrai runtime Cloudflare.** 21 contrôles passent sur ce
chemin (`npm run test:worker`) et **28 contrôles passent dans `workerd` avec une vraie base D1**
(`npm run test:workerd` : Worker compilé par Wrangler + base D1 locale + parcours complet).
La procédure de déploiement complète est dans `MISE-EN-LIGNE.md`, section « Option B ».

| Élément | État | Fichier |
|---|---|---|
| Entrée Worker (fetch, assets, routage) | ✅ | `worker/index.mjs` |
| Schéma embarqué | ✅ généré | `worker/schema.generated.js` (`npm run build:worker`) |
| Adaptateur base D1 | ✅ | `src/lib/d1.js` |
| Shim HTTP Request/Response | ✅ | `src/lib/httpshim.js` |
| Hachage mot de passe portable | ✅ PBKDF2-SHA256 | `src/lib/security.js` |
| Config depuis l'environnement Worker | ✅ | `src/lib/config.js` (`buildConfig`) |
| Transactions → écritures conditionnelles | ✅ | `src/services/faucet.js`, `payout.js`, `shortlink.js`, `ptc.js`, `offerwall.js` |
| Configuration de déploiement | ✅ | `wrangler.toml` |
| Simulateur D1 (tests hors Cloudflare) | ✅ | `test/d1-simulator.mjs` |
| Pages HTML embarquées (pas de disque en Worker) | ✅ généré | `worker/pages.generated.js` |
| Test dans le runtime réel `workerd` + D1 | ✅ 28 contrôles | `test/workerd-e2e.mjs` (`npm run test:workerd`) |

## Trois pièges du runtime Cloudflare (rencontrés pour de vrai)

Ces trois erreurs sont invisibles en Node : elles n'apparaissent qu'en déployant. Elles sont
corrigées et **verrouillées par des tests**, mais il faut les connaître pour ne pas les
réintroduire.

### 1. Pas de `fs`, ni `path`, ni `__dirname`

Symptôme : `Uncaught ReferenceError: __dirname is not defined`, le Worker ne démarre pas et
**toutes** les pages renvoient une 500.
Règle : dans le code partagé, ne jamais utiliser `fs`/`path` sans garde-fou. Voir le
chargement tolérant en tête de `src/lib/config.js`.

```js
let fs = null, path = null;
try { fs = require('node:fs'); path = require('node:path'); } catch { /* runtime Worker */ }
```

### 2. `D1Database.exec()` coupe sur les RETOURS À LA LIGNE

Symptôme : `D1_EXEC_ERROR: Error in line 1: CREATE TABLE IF NOT EXISTS users (: incomplete input`.
`exec()` n'exécute pas un script SQL : il s'arrête à la première ligne. Un `CREATE TABLE`
multiligne est donc tronqué et **aucune table n'est créée**.
Règle : découper le script puis exécuter chaque instruction avec `prepare().run()`
(fonction `splitSqlStatements()` dans `src/lib/d1.js`, qui gère les chaînes et les triggers).

### 3. `html_handling` sert les pages privées sans passer par le Worker

Symptôme : `/dashboard` et `/admin` s'affichent **sans être connecté** — la liaison ASSETS
résout `/dashboard` vers `dashboard.html` et renvoie le fichier directement.
Règle : `html_handling = "none"` dans `[assets]` (déjà dans `wrangler.toml`), et **toutes**
les pages passent par l'application, qui vérifie la session avant d'envoyer le HTML.
Les pages sont embarquées à la compilation (`npm run build:worker`) car il n'y a pas de disque.

## Règles à respecter pour toute évolution

1. **Jamais de lecture dans `db.atomic()`** : la boîte ne contient que `run()`.
   La cohérence se fait par `UPDATE … WHERE <invariant>` ou
   `INSERT … SELECT … WHERE NOT EXISTS (…)` puis contrôle de `changes`.
2. **Unicité par index SQL**, pas par vérification applicative
   (`idempotency_key`, `transaction_id`, `(user_id, module, claim_slot)`).
3. **Aucun `lastInsertRowid` en dépendance forte** : relire par clé unique.
4. Toute nouvelle route doit passer par `requireCsrf` + `requireUser`/`requireAdmin`.

## Limites D1 à connaître

- `batch()` = écritures uniquement, atomique ; pas de transaction interactive.
- 100 000 écritures/jour sur l'offre gratuite : largement suffisant pour un robinet,
  à surveiller si vous ajoutez des écritures par requête (ex. compteurs).
- Les timeouts de requête sont courts : les appels externes (FaucetPay) ont un
  `AbortSignal` de 15 s côté service.

## Vérifier avant chaque déploiement

```bash
npm run test:all      # 129 + 21 + 28 contrôles, puis régénère le rapport
npx wrangler deploy --dry-run   # vérifie le bundle (aucun compte requis)
```

`npm run test:workerd` est le test le plus proche d'un déploiement réel : il compile le
Worker, crée une base D1 locale avec le schéma du projet, démarre `wrangler dev` et exécute
le parcours complet (inscription, réclamation, retrait, administration, modules).
Il utilise un port aléatoire et nettoie son dossier temporaire.

