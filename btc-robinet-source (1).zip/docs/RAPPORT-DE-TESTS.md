# Rapport de tests — BTC ROBINET

**Date :** 2026-11-12 15:44 UTC  
**Total :** **178 contrôles réussis, 0 échec(s)**  
**Environnement :** Node local · SQLite · FaucetPay en simulation · `PAYOUTS_LIVE=false` · **aucun bitcoin réel déplacé**

| Suite | Commande | Résultat |
|---|---|---|
| Application (serveur Node + SQLite) | `npm test` | **129/129** — 0 échec(s) |
| Chemin Cloudflare Workers + D1 (adaptateur simulé) | `npm run test:worker` | **21/21** — 0 échec(s) |
| Runtime Cloudflare réel (`workerd` + D1 locale) | `npm run test:workerd` | **28/28** — 0 échec(s) |
| **Total** | `npm run test:all` | **178/178** — 0 échec(s) |

> Les trois suites exécutent le **même code métier**. La troisième est la plus proche
> d'un déploiement réel : c'est elle qui a révélé trois anomalies invisibles en Node
> (voir la section « Anomalies corrigées »).

Pour tout relancer d'un coup : `npm run test:all`.

## Anomalies corrigées grâce au runtime réel

Ces trois défauts ne pouvaient pas être vus par les tests Node : ils ne se produisent
que dans le runtime Cloudflare. Ils sont maintenant couverts par des tests permanents.

| # | Symptôme en production | Cause | Correction |
|---|---|---|---|
| 1 | Le Worker **plantait au démarrage** (`__dirname is not defined`) : toutes les pages renvoyaient une 500 | `src/lib/config.js` utilisait `fs`, `path` et `__dirname`, absents du runtime Workers | Chargement tolérant des modules ; racine de projet calculée seulement si possible ; `dbPath` vide en Worker |
| 2 | **Aucune table n'était créée** (`incomplete input: SQLITE_ERROR`) → site inutilisable | `D1Database.exec()` coupe l'entrée sur les **retours à la ligne**, pas sur `;` : le `CREATE TABLE` multiligne était tronqué | Nouveau découpage `splitSqlStatements()` + exécution par `prepare().run()` instruction par instruction |
| 3 | **`/dashboard` et `/admin` s'ouvraient sans être connecté** (faille d'accès) | `html_handling` par défaut : Cloudflare résolvait `/dashboard` → `dashboard.html` et servait le fichier sans passer par le Worker | `html_handling = "none"` dans `wrangler.toml` + routage unique par l'application ; pages HTML embarquées à la compilation |

Un quatrième défaut a été trouvé en cours de test : les pages HTML n'étaient pas
lisibles en Worker (pas de disque). Elles sont désormais embarquées dans le bundle
(`worker/pages.generated.js`), ce qui permet à l'application d'appliquer les contrôles
de session **avant** d'envoyer la page.

## Application (serveur Node + SQLite)

`npm test` — Vrai serveur HTTP, vraie base SQLite : parcours complet du site.

### 1. Démarrage & configuration (4/4)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Configuration publique accessible | — |
| ✅ | Aucune clé API exposée au navigateur | — |
| ✅ | Mode paiement annoncé = simulation | — |
| ✅ | Page d'accueil servie | — |

### 2. Inscription & sécurité du mot de passe (9/9)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Mot de passe trop court refusé | — |
| ✅ | Captcha incorrect rejeté | — |
| ✅ | Inscription réussie | {"ok":true,"user":{"id":1,"username":"alice","email":"alice@example.com","payout_address": |
| ✅ | Mot de passe jamais renvoyé par l'API | — |
| ✅ | Code de parrainage généré | — |
| ✅ | Cookie de session posé (HttpOnly) | — |
| ✅ | Mot de passe stocké haché (PBKDF2-SHA256, jamais en clair) | — |
| ✅ | Email en double refusé | — |
| ✅ | Anti multi-compte : variante email contrôlée | — |

### 3. Connexion / déconnexion (9/9)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Mauvais mot de passe refusé (401) | — |
| ✅ | Inscription avec code de parrainage | — |
| ✅ | Filleul peut réclamer normalement | {"ok":true,"claim_id":1,"amount_sats":25,"base_sats":25,"bonus_sats":0,"bonus_percent":0," |
| ✅ | Commission de parrainage renvoyée au filleul (info) | — |
| ✅ | Connexion par email réussie | — |
| ✅ | Session valide (/api/me) | — |
| ✅ | Jeton CSRF fourni au client | — |
| ✅ | Déconnexion invalide la session | — |
| ✅ | Cookie de session forgé rejeté | — |

### 4. Protection CSRF (1/1)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Réclamation sans jeton CSRF bloquée | — |

### 5. Robinet BTC — réclamation, minuterie, limites (18/18)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | État du robinet disponible | — |
| ✅ | Récompense configurable affichée | — |
| ✅ | Solde cohérent : uniquement les commissions de parrainage (aucune réclamation) | solde=5, commissions=5 |
| ✅ | Première réclamation créditée | {"ok":true,"claim_id":2,"amount_sats":25,"base_sats":25,"bonus_sats":0,"bonus_percent":0," |
| ✅ | Solde mis à jour après réclamation | attendu=30, obtenu=30 |
| ✅ | Deuxième réclamation immédiate bloquée (cooldown) | — |
| ✅ | Temps d'attente communiqué | — |
| ✅ | Rejeu de la même requête bloqué | — |
| ✅ | Une seule réclamation enregistrée en base | — |
| ✅ | Lien de parrainage enregistré | — |
| ✅ | Commission de parrainage créditée | earned=5 |
| ✅ | Réclamation après expiration du cooldown acceptée | — |
| ✅ | Plafond de réclamations par jour respecté | — |
| ✅ | 4e réclamation du jour refusée (limite = 3) | {"ok":false,"error":"Limite journalière de réclamations atteinte. Revenez demain.","code": |
| ✅ | Historique des réclamations disponible | — |
| ✅ | Total des gains cohérent | — |
| ✅ | 8 réclamations simultanées → 1 seul crédit | succès=1, en base=1 |
| ✅ | Solde cohérent avec les crédits (pas de double crédit) | — |

### 6. FaucetPay — adresse, solde, retraits simulés (16/16)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Mode mock : aucun paiement réel possible | — |
| ✅ | Solde faucet (mock) récupérable | — |
| ✅ | Adresse invalide refusée | — |
| ✅ | Adresse FaucetPay acceptée (mock) | — |
| ✅ | Retrait sous le minimum refusé | — |
| ✅ | Retrait supérieur au solde refusé | — |
| ✅ | Retrait simulé accepté | {"ok":true,"duplicate":false,"payout":{"id":1,"user_id":1,"amount_sats":100,"currency":"BT |
| ✅ | Solde débité après retrait | — |
| ✅ | Mouvement inscrit au grand livre | — |
| ✅ | Double paiement impossible (clé d'idempotence) | — |
| ✅ | Un seul paiement enregistré malgré le rejeu | count=1 |
| ✅ | Erreur FaucetPay 456 => paiement en échec | {"ok":false,"error":"Paiement refusé par FaucetPay (Destinataire non payable). Montant rec |
| ✅ | Remboursement automatique du solde | avant=525, après=525 |
| ✅ | Remboursement tracé au grand livre | — |
| ✅ | Aucun paiement si le faucet est à découvert | — |
| ✅ | Solde interne intact en cas de refus de financement | — |

### 7. Parrainage (5/5)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Lien de parrainage personnel | — |
| ✅ | Filleul listé | — |
| ✅ | Commission cumulée > 0 | — |
| ✅ | Historique des commissions disponible | — |
| ✅ | Pourcentage de commission configurable | — |

### 8. Shortlinks (Étape 4) (16/16)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Admin : listes shortlinks accessibles | — |
| ✅ | Module désactivé => clic refusé | — |
| ✅ | Création d'un partenaire shortlink | — |
| ✅ | Création d'un lien shortlink | — |
| ✅ | Activation du module shortlinks | — |
| ✅ | Liste des liens pour le membre | — |
| ✅ | Démarrage : redirection vers le partenaire | — |
| ✅ | URL de retour signée (HMAC) | — |
| ✅ | Retour avec signature invalide => refusé | — |
| ✅ | Retour trop rapide (délai minimal) => refusé | — |
| ✅ | Retour validé => redirection avec gain | — |
| ✅ | Récompense shortlink créditée (15 sats) | avant=1980, après=1995 |
| ✅ | Rejeu du même retour impossible (session déjà validée) | — |
| ✅ | Revenu partenaire enregistré (cpm/1000) | usd=0.0035 |
| ✅ | Retour sans session => redirection connexion | — |
| ✅ | Lien en mode démonstration (sans secret partenaire) | — |

### 9. PTC (Étape 5) (11/11)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | PTC désactivé par défaut | — |
| ✅ | Création d'une campagne PTC | — |
| ✅ | URL de campagne invalide rejetée | — |
| ✅ | Campagne visible par le membre | — |
| ✅ | Ouverture d'une vue PTC (jeton unique) | — |
| ✅ | Validation avant la durée minimale refusée | — |
| ✅ | Vue PTC validée après la durée | — |
| ✅ | Récompense PTC créditée | avant=1995, après=2003 |
| ✅ | Double validation PTC impossible | — |
| ✅ | Budget annonceur débité | spent=8/100 |
| ✅ | Onglet non visible pendant la durée => refusé | — |

### 10. Offerwalls (Étape 6) (9/9)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Création d'un partenaire offerwall | — |
| ✅ | Callbacks refusés quand le module est désactivé | — |
| ✅ | Partenaire offerwall listé pour le membre | — |
| ✅ | Callback avec signature invalide => 401 | — |
| ✅ | Callback signé => conversion créditée | {"ok":true,"duplicate":false,"username":"alice","usd":0.01,"credited_sats":8,"balance_sats |
| ✅ | Solde augmenté du montant de la conversion | — |
| ✅ | Rejeu du callback ignoré (idempotence transaction_id) | — |
| ✅ | Mission non complétée => aucun crédit | — |
| ✅ | Admin : callbacks journalisés | — |

### 11. Administration (suite : modules) (4/4)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Admin : statistiques shortlinks | — |
| ✅ | Admin : campagnes PTC avec budget | — |
| ✅ | Suspension d'un lien par l'admin | — |
| ✅ | Lien suspendu inaccessible | — |

### 12. Administration (17/17)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Accès admin refusé aux membres | — |
| ✅ | Page /admin protégée (redirection) | — |
| ✅ | Connexion administrateur | — |
| ✅ | Page /admin accessible à l'admin | — |
| ✅ | Tableau de bord admin | — |
| ✅ | Solde FaucetPay visible en admin | — |
| ✅ | Récompense modifiable en admin | — |
| ✅ | Minuterie modifiable en admin | — |
| ✅ | Nouvelle récompense appliquée immédiatement | {"enabled":true,"maintenance":false,"reward_sats":40,"cooldown_seconds":60,"daily_limit":5 |
| ✅ | Valeurs aberrantes bornées | — |
| ✅ | Suspension d'un membre | — |
| ✅ | Membre suspendu : session invalidée / réclamation bloquée | status=401 |
| ✅ | Ajustement de solde manuel tracé | — |
| ✅ | Module robinet suspensible | — |
| ✅ | Robinet désactivé côté membre | — |
| ✅ | Paiements FaucetPay visibles en admin | — |
| ✅ | Recherche de membres | — |

### 13. Rentabilité (6/6)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Rapport financier disponible | — |
| ✅ | Résultat par jour/semaine/mois | — |
| ✅ | Coûts = récompenses + frais + hébergement | — |
| ✅ | Bénéfice net calculé (peut être négatif en MVP) | net=-0.13 |
| ✅ | Saisie manuelle d'un revenu | — |
| ✅ | Simulateur de rentabilité | {"daily_claims":1000,"reward_sats":25000,"revenue_usd":0.05,"reward_usd":22.5,"fees_usd":0 |

### 14. Sécurité complémentaire (4/4)

| Résultat | Test | Détail |
|---|---|---|
| ✅ | Limitation de débit sur la connexion | — |
| ✅ | Traversée de répertoire bloquée | — |
| ✅ | API retrait protégée sans session | — |
| ✅ | Journal d'audit alimenté | — |

## Chemin Cloudflare Workers + D1 (adaptateur simulé)

`npm run test:worker` — Même code applicatif, entrée Web (Request/Response) et adaptateur D1.

| Résultat | Contrôle | Détail |
|---|---|---|
| ✅ | Configuration publique servie par le Worker | — |
| ✅ | Aucun secret exposé | — |
| ✅ | Inscription via Worker (PBKDF2 Web Crypto) | {"ok":true,"user":{"id":1,"username":"worker_user","email":"worker@example.com","payout_ad |
| ✅ | Cookie de session émis avec Secure | — |
| ✅ | Réclamation créditée (INSERT conditionnel + index unique) | {"ok":true,"amount_sats":25,"base_sats":25,"bonus_sats":0,"bonus_percent":0,"streak_days": |
| ✅ | Solde mis à jour | — |
| ✅ | 6 réclamations simultanées → 1 seul crédit (index unique claim_slot) | succès=0 |
| ✅ | Une seule réclamation en base | count=1 |
| ✅ | Retrait simulé via Worker | {"ok":true,"duplicate":false,"payout":{"id":1,"user_id":1,"amount_sats":100,"currency":"BT |
| ✅ | Rejeu de la clé d'idempotence : aucun second débit | solde=300 |
| ✅ | Démarrage shortlink via Worker | — |
| ✅ | Retour immédiat refusé (délai minimal) | — |
| ✅ | Page privée sans session → redirection | — |
| ✅ | Schéma découpé en instructions complètes | 31 instructions |
| ✅ | CREATE TABLE complet (pas tronqué à la 1re ligne) | — |
| ✅ | Aucune instruction vide ou commentaire seul | — |
| ✅ | Points-virgules internes préservés (chaînes) | — |
| ✅ | config.js charge sans fs/path (Worker) | — |
| ✅ | Configuration Worker construite sans disque | — |
| ✅ | Page servie depuis le bundle embarqué | — |
| ✅ | Page privée reste protégée sans session | — |

## Runtime Cloudflare réel (`workerd` + D1 locale)

`npm run test:workerd` — Worker compilé par Wrangler, exécuté dans workerd avec une vraie base D1.

| Résultat | Contrôle | Détail |
|---|---|---|
| ✅ | Schéma appliqué à une vraie base D1 (wrangler d1 execute) | — |
| ✅ | Administrateur créé dans D1 | — |
| ✅ | Le Worker démarre dans workerd | — |
| ✅ | Accueil servi par le Worker | — |
| ✅ | Connexion accessible | — |
| ✅ | /dashboard redirige vers /login sans session | — |
| ✅ | /admin protégé sans session | — |
| ✅ | Feuille de style servie (liaison ASSETS) | — |
| ✅ | Inscription (PBKDF2 dans workerd) | status 201 |
| ✅ | Réclamation créditée | 25 sats |
| ✅ | Double réclamation immédiate refusée | code cooldown |
| ✅ | Solde crédité | 25 sats |
| ✅ | Retrait sous le minimum refusé | — |
| ✅ | Retrait refusé si solde insuffisant | insufficient_balance |
| ✅ | Vérification adresse FaucetPay (simulation) | — |
| ✅ | Connexion administrateur sur D1 | — |
| ✅ | Tableau de bord administrateur | — |
| ✅ | Récompense modifiable par l'admin | — |
| ✅ | Calculateur de rentabilité | — |
| ✅ | Page /admin accessible à l'admin | — |
| ✅ | Page /admin refusée au membre | — |
| ✅ | Module shortlinks inactif par défaut | — |
| ✅ | Module ptc inactif par défaut | — |
| ✅ | Module offerwalls inactif par défaut | — |
| ✅ | Callback offerwall signé crédité | 16 sats |
| ✅ | Callback rejoué : aucun second paiement | — |
| ✅ | Déconnexion : tableau de bord de nouveau protégé | — |
| ✅ | Aucune erreur fatale dans les journaux workerd | — |

## Garanties vérifiées

| Garantie | Où elle est testée |
|---|---|
| Aucun paiement réel sans autorisation | `PAYOUTS_LIVE=false`, mode simulation, aucune clé API dans les tests |
| Jamais de paiement si le solde est insuffisant | Débit conditionnel SQL + erreur `insufficient_balance` testée |
| Double paiement impossible | `payouts.idempotency_key` UNIQUE, rejeu testé à l'identique |
| Double réclamation impossible | `claims(user_id, nonce)` UNIQUE + `claim_slot` UNIQUE + 6 requêtes simultanées |
| Un clic de shortlink non validé ne rapporte rien | Retour immédiat refusé (délai minimal) |
| Callback de partenaire rejoué = 0 satoshi | Réponse `duplicate: true`, `credited_sats: 0` |
| Zones privées inaccessibles sans session | `/dashboard`, `/admin` → redirection (testé dans workerd) |
| `/admin` réservé à l'administrateur | Membre → redirection `admin_required` |
| Aucun secret côté navigateur | `/api/public/config` inspecté |
| Mots de passe jamais stockés en clair | PBKDF2-SHA256 210 000 itérations vérifié en base |

## Ce qui reste à valider hors de ce poste

- **Paiement FaucetPay réel** : nécessite une clé API et une autorisation écrite du propriétaire (`PAYOUTS_LIVE=true`, montant de test).
- **Déploiement Cloudflare** : le bundle est validé (`wrangler deploy --dry-run`, 244 Kio) mais la publication demande `wrangler login` et la création de la base D1 (`database_id`).
- **Cloudflare Turnstile** : code en place ; les clés site/secret sont à créer dans le tableau de bord Cloudflare.
- **Conformité** : les conditions d'utilisation des partenaires (shortlinks, offerwalls) doivent être acceptées par le propriétaire.
