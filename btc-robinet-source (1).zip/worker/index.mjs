/**
 * Cloudflare Worker — BTC ROBINET
 *
 * Réutilise l'intégralité du code applicatif de `src/` (aucune duplication) :
 *  - les fichiers statiques sont servis par la liaison `ASSETS` (dossier public/) ;
 *  - l'API et les pages protégées passent par `app.handle` via un shim Request/Response ;
 *  - la base est Cloudflare D1, exposée par un adaptateur à l'interface identique.
 *
 * Secrets / variables à configurer (wrangler secret put / [vars]) :
 *   SESSION_SECRET, SITE_URL, COOKIE_SECURE, CAPTCHA_MODE,
 *   FAUCETPAY_MODE, FAUCETPAY_API_VERSION, FAUCETPAY_API_KEY (ou clés v2), PAYOUTS_LIVE,
 *   TURNSTILE_SITE_KEY, TURNSTILE_SECRET_KEY
 */
import { buildConfig } from '../src/lib/config.js';
import { D1Adapter } from '../src/lib/d1.js';
import { createApp } from '../src/app.js';
import { handleToResponse } from '../src/lib/httpshim.js';

// Schéma embarqué (généré depuis db/schema.sql — voir npm run build:worker)
import SCHEMA from './schema.generated.js';
// Pages HTML embarquées (générées par npm run build:worker)
import PAGES_HTML from './pages.generated.js';

let cachedApp = null;
let lastDb = null;

async function getApp(env) {
  if (cachedApp && lastDb === env.DB) return cachedApp;

  const config = buildConfig(env);
  const db = new D1Adapter(env.DB);
  // Pas de disque en Worker : publicDir vide + pages embarquées.
  const app = createApp({ config, db, schemaSql: SCHEMA, publicDir: '', pages: PAGES_HTML });
  await app.init();

  cachedApp = app;
  lastDb = env.DB;
  return app;
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    // 1. Fichiers statiques (CSS, JS, images) servis par les assets Cloudflare.
    //    On ne sert ICI que les ressources sans logique d'accès : les pages
    //    passent par l'application, qui applique le contrôle de session et les
    //    redirections (/dashboard sans connexion → /login?next=/dashboard).
    const p = url.pathname;
    const isStaticFile =
      p.startsWith('/css/') || p.startsWith('/js/') || p.startsWith('/img/') || p === '/favicon.ico';

    if (request.method === 'GET' && isStaticFile) {
      const res = await env.ASSETS.fetch(request);
      if (res.status !== 404) return res;
    }

    // 2. Tout le reste (pages, API, callbacks partenaires) → application
    try {
      const app = await getApp(env);
      return await handleToResponse(request, app, { assets: env.ASSETS });
    } catch (err) {
      console.error('[worker] échec global:', err && err.stack);
      return new Response(JSON.stringify({
        ok: false,
        error: 'Erreur interne du serveur (worker).',
        code: 'worker_error',
      }), { status: 500, headers: { 'Content-Type': 'application/json; charset=utf-8' } });
    }
  },
};
