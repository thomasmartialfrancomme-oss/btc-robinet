# Contribuer / modifier le projet

## Mise en route

```bash
git clone <URL_DU_DEPOT> btc-robinet
cd btc-robinet
npm install
cp .env.example .env      # puis renseigner SESSION_SECRET
npm run init-db
npm start
```

## Avant chaque commit

```bash
npm test          # 129 contrôles serveur — doit rester à 0 échec
npm run test:worker   # 21 contrôles Cloudflare Workers + D1
npm run test:workerd  # 28 contrôles dans le runtime Cloudflare réel (workerd + D1)
```

## Règles techniques à respecter

1. **Jamais de secret dans Git.** `.env` est ignoré ; les secrets de production passent
   par les variables d'environnement de l'hébergeur (`wrangler secret put` sur Cloudflare).
2. **Aucune lecture dans `db.atomic()`** : cette boîte ne contient que `run()`.
   Utiliser des écritures conditionnelles (`WHERE <invariant>`) et contrôler `changes`.
   Voir `docs/CLOUDFLARE.md`.
3. **Unicité par index SQL**, jamais par simple vérification applicative.
4. **Toute route mutante** : `requireCsrf` + `requireUser`/`requireAdmin`.
5. **Montants en satoshis entiers** (jamais de flottants).
6. **Pas de fraude publicitaire** : aucun clic automatique, aucun faux visiteur,
   aucun gonflement de trafic. Une contribution de ce type sera refusée.
7. Migrations SQL dans `db/migrations/` (nommées `NNN_description.sql`, compatibles
   SQLite *et* D1 : pas de `ALTER` multiple, pas de transaction explicite).

## Structure

| Dossier | Rôle |
|---|---|
| `src/lib` | infrastructure (config, base, HTTP, sécurité) |
| `src/services` | logique métier (auth, robinet, paiements, modules, finance) |
| `public` | interface (HTML/CSS/JS, aucune dépendance externe) |
| `worker` | entrée Cloudflare Workers |
| `db` | schéma et migrations |
| `test` | suites de tests (serveur et Worker) |
| `docs` | documentation d'installation, de mise en ligne et de sécurité |
