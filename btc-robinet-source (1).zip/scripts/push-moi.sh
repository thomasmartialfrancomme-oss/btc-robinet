#!/usr/bin/env bash
# Remplace l'archive déposée sur GitHub par le dépôt Git complet.
# Le token n'est JAMAIS écrit sur le disque.
#
#   GITHUB_TOKEN=github_pat_xxx ./scripts/push-moi.sh
#
# Toute la logique est dans scripts/push-moi.mjs (une seule source de vérité,
# identique sous Windows, macOS et Linux).
set -euo pipefail
cd "$(dirname "$0")/.."
exec node scripts/push-moi.mjs "$@"
