#!/usr/bin/env node
/**
 * Déploiement Cloudflare complet, en une commande.
 *
 *   node scripts/deploy-cloudflare.mjs
 *
 * Ce script fait à ta place tout ce qui est automatisable :
 *   1. vérifie que tu es connecté (sinon il lance `wrangler login`) ;
 *   2. crée la base D1 `btc-robinet` si elle n'existe pas, et récupère son ID ;
 *   3. écrit cet ID dans wrangler.toml ;
 *   4. crée les tables dans la vraie base (`d1 execute --remote`) ;
 *   5. demande le secret de session et le stocke chiffré chez Cloudflare
 *      (jamais dans un fichier, jamais dans Git) ;
 *   6. applique les migrations, génère le bundle, déploie ;
 *   7. met à jour SITE_URL avec l'URL réelle, redéploie, puis teste le site en ligne.
 *
 * Ce qu'il ne peut pas faire : créer ton compte Cloudflare (aucune API ne le permet).
 *
 * Options :
 *   --skip-login     ne pas proposer `wrangler login`
 *   --dry-run        tout préparer, ne rien publier
 *   --location=weur  région de la base D1 (weur, eeur, apac, oc, wnam, enam)
 */
import { spawn, spawnSync } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DB_NAME = 'btc-robinet';
const WORKER_NAME = 'btc-robinet';
const isWin = process.platform === 'win32';
const args = process.argv.slice(2);
const DRY = args.includes('--dry-run');
const SKIP_LOGIN = args.includes('--skip-login');
const LOCATION = (args.find((a) => a.startsWith('--location=')) || '').split('=')[1] || 'weur';

const c = {
  b: (s) => `\u001b[1m${s}\u001b[0m`,
  g: (s) => `\u001b[32m${s}\u001b[0m`,
  y: (s) => `\u001b[33m${s}\u001b[0m`,
  r: (s) => `\u001b[31m${s}\u001b[0m`,
  d: (s) => `\u001b[2m${s}\u001b[0m`,
};
const step = (n, t) => console.log(`\n${c.b(`→ ${n}. ${t}`)}`);
const ok = (t) => console.log(`   ${c.g('✓')} ${t}`);
const warn = (t) => console.log(`   ${c.y('!')} ${t}`);
const die = (t) => { console.error(`\n   ${c.r('✗ ' + t)}`); process.exit(1); };

function wrangler(wrArgs, { inherit = false, input = null, json = false } = {}) {
  const full = ['--yes', 'wrangler', ...wrArgs, ...(json ? ['--json'] : [])];
  const res = spawnSync(isWin ? 'npx.cmd' : 'npx', full, {
    cwd: ROOT, encoding: 'utf8', input: input === null ? undefined : input,
    stdio: inherit ? 'inherit' : ['pipe', 'pipe', 'pipe'],
    shell: false,
  });
  const out = `${res.stdout || ''}${res.stderr || ''}`;
  return { code: res.status, out };
}

function ask(question, { hidden = false } = {}) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    if (hidden) {
      rl._writeToOutput = function (str) {
        if (str.includes(question)) rl.output.write(str);
        else rl.output.write('*');
      };
    }
    rl.question(question, (answer) => { rl.close(); process.stdout.write('\n'); resolve(answer.trim()); });
  });
}

function toml() {
  return fs.readFileSync(path.join(ROOT, 'wrangler.toml'), 'utf8');
}
function writeToml(content) {
  fs.writeFileSync(path.join(ROOT, 'wrangler.toml'), content, 'utf8');
}
function setTomlVar(name, value) {
  const re = new RegExp(`^${name}\\s*=.*$`, 'm');
  const current = toml();
  writeToml(re.test(current) ? current.replace(re, `${name} = ${JSON.stringify(value)}`) : `${current}\n${name} = ${JSON.stringify(value)}\n`);
}

(async () => {
  console.log(c.b('\nBTC ROBINET — déploiement Cloudflare'));
  console.log(c.d(`Dossier : ${ROOT}`));

  /* 1. Authentification ------------------------------------------------ */
  step(1, 'Vérification de la connexion Cloudflare');
  let who = wrangler(['whoami']);
  if (/not authenticated|You are not authenticated/i.test(who.out)) {
    if (SKIP_LOGIN) die('tu n\'es pas connecté. Lance `npx wrangler login` puis relance ce script.');
    warn('pas encore connecté → ouverture du navigateur pour `wrangler login`');
    console.log(c.d('   (autorise Wrangler dans la page qui s\'ouvre, puis reviens ici)'));
    const login = wrangler(['login'], { inherit: true });
    if (login.code !== 0) die('la connexion a échoué.');
    who = wrangler(['whoami']);
  }
  if (/not authenticated/i.test(who.out)) die('toujours pas connecté.');
  const account = (who.out.match(/([^\s]+@[^\s]+)/) || [])[1] || (who.out.match(/Account ID:\s*(\S+)/) || [])[1] || 'compte détecté';
  ok(`connecté (${account})`);

  /* 2. Base D1 --------------------------------------------------------- */
  step(2, `Base de données D1 « ${DB_NAME} »`);
  let databaseId = null;
  const list = wrangler(['d1', 'list', '--json'], { json: false });
  try {
    const jsonStart = list.out.indexOf('[');
    const parsed = JSON.parse(list.out.slice(jsonStart));
    const found = parsed.find((d) => d.name === DB_NAME);
    if (found) { databaseId = found.uuid || found.id; ok(`base existante réutilisée (${databaseId})`); }
  } catch { /* pas de JSON exploitable : on crée */ }

  if (!databaseId) {
    console.log(c.d(`   création en région ${LOCATION}…`));
    const create = wrangler(['d1', 'create', DB_NAME, `--location=${LOCATION}`]);
    databaseId = (create.out.match(/database_id\s*=\s*"([0-9a-f-]{36})"/i) || create.out.match(/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i) || [])[1];
    if (!databaseId) {
      console.log(create.out.trim().split('\n').slice(-8).join('\n'));
      die('impossible de créer la base D1 (voir le message ci-dessus).');
    }
    ok(`base créée : ${databaseId}`);
  }

  /* 3. wrangler.toml --------------------------------------------------- */
  step(3, 'Écriture du database_id dans wrangler.toml');
  const before = toml();
  const after = before.replace(/^database_id\s*=.*$/m, `database_id = "${databaseId}"`);
  if (after === before) warn('ligne database_id introuvable dans wrangler.toml — vérifie le fichier');
  else { writeToml(after); ok('wrangler.toml à jour'); }

  if (DRY) {
    warn('mode --dry-run : arrêt après la préparation (rien n\'est publié)');
    return;
  }

  /* 4. Tables ---------------------------------------------------------- */
  step(4, 'Création des tables dans la vraie base');
  const schemaRun = wrangler(['d1', 'execute', DB_NAME, '--remote', '--file=db/schema.sql']);
  if (schemaRun.code !== 0) {
    console.log(schemaRun.out.trim().split('\n').slice(-10).join('\n'));
    die('la création des tables a échoué.');
  }
  ok('18 tables créées / vérifiées');

  const migDir = path.join(ROOT, 'db', 'migrations');
  if (fs.existsSync(migDir)) {
    for (const file of fs.readdirSync(migDir).filter((f) => f.endsWith('.sql')).sort()) {
      const r = wrangler(['d1', 'execute', DB_NAME, '--remote', `--file=db/migrations/${file}`]);
      if (r.code === 0) ok(`migration ${file} appliquée`);
      else warn(`migration ${file} : déjà appliquée ou en échec (sans gravité si les tables existent)`);
    }
  }

  /* 5. Secrets --------------------------------------------------------- */
  step(5, 'Secret de session (SESSION_SECRET)');
  const generate = await ask('   Générer automatiquement une clé de session solide ? [O/n] ');
  let sessionSecret = '';
  if (/^n/i.test(generate)) {
    sessionSecret = await ask('   Colle ta clé (32 caractères minimum, elle ne s\'affichera pas) : ', { hidden: true });
    if (sessionSecret.length < 32) die('clé trop courte (32 caractères minimum).');
  } else {
    sessionSecret = crypto.randomBytes(32).toString('hex');
    ok('clé de 64 caractères générée');
  }
  const put = wrangler(['secret', 'put', 'SESSION_SECRET'], { input: sessionSecret });
  if (put.code !== 0) {
    console.log(put.out.trim().split('\n').slice(-6).join('\n'));
    die('impossible d\'enregistrer le secret.');
  }
  ok('SESSION_SECRET enregistré (chiffré chez Cloudflare, jamais sur le disque)');

  const turnstile = await ask('   As-tu des clés Cloudflare Turnstile à ajouter maintenant ? [o/N] ');
  if (/^o/i.test(turnstile)) {
    const siteKey = await ask('   Turnstile SITE KEY (publique) : ');
    const secretKey = await ask('   Turnstile SECRET KEY (cachée) : ', { hidden: true });
    if (siteKey && secretKey) {
      wrangler(['secret', 'put', 'TURNSTILE_SITE_KEY'], { input: siteKey });
      wrangler(['secret', 'put', 'TURNSTILE_SECRET_KEY'], { input: secretKey });
      setTomlVar('CAPTCHA_MODE', 'turnstile');
      ok('captcha Turnstile activé');
    } else warn('clés incomplètes : captcha arithmétique conservé');
  } else {
    warn('captcha arithmétique conservé (à remplacer avant d\'ouvrir au public)');
  }

  /* 6. Déploiement ----------------------------------------------------- */
  step(6, 'Génération du bundle et déploiement');
  const build = spawnSync(isWin ? 'npm.cmd' : 'npm', ['run', 'build:worker'], { cwd: ROOT, encoding: 'utf8', shell: false });
  if (build.status !== 0) die(`npm run build:worker a échoué : ${(build.stderr || '').slice(-300)}`);
  ok('schéma et pages embarqués régénérés');

  const deploy = wrangler(['deploy']);
  const url = (deploy.out.match(/https:\/\/[a-z0-9-]+\.[a-z0-9-]+\.workers\.dev/i) || [])[0];
  if (deploy.code !== 0 || !url) {
    console.log(deploy.out.trim().split('\n').slice(-14).join('\n'));
    die('le déploiement a échoué.');
  }
  ok(`publié : ${url}`);

  /* 7. URL définitive puis contrôles ----------------------------------- */
  step(7, 'URL définitive dans la configuration, puis contrôles en ligne');
  setTomlVar('SITE_URL', url);
  const redeploy = wrangler(['deploy']);
  if (redeploy.code !== 0) warn('le second déploiement a échoué : SITE_URL devra être réglé à la main');
  else ok('SITE_URL réglé sur l\'URL réelle');

  const checks = [];
  const get = async (p, opts = {}) => {
    try { return await fetch(url + p, { redirect: 'manual', ...opts }); }
    catch (e) { return { status: 0, headers: new Map(), error: e.message }; }
  };
  let r = await get('/');
  checks.push(['Page d\'accueil', r.status === 200]);
  r = await get('/dashboard');
  checks.push(['/dashboard protégé (redirection)', r.status === 302]);
  r = await get('/admin');
  checks.push(['/admin protégé (redirection)', r.status === 302]);
  r = await get('/api/public/config');
  let config = null;
  try { config = await r.json(); } catch { /* ignore */ }
  checks.push(['Configuration publique servie', r.status === 200 && !!config]);
  checks.push(['Aucune clé API exposée', !/api_key|secret|sendKey|readKey/i.test(JSON.stringify(config || {}))]);
  r = await get('/css/style.css');
  checks.push(['Feuille de style servie', r.status === 200]);

  let failed = 0;
  for (const [label, pass] of checks) {
    if (pass) ok(label); else { failed += 1; console.log(`   ${c.r('✗')} ${label}`); }
  }

  console.log(`\n${c.b('Résumé')}`);
  console.log(`  Site            : ${url}`);
  console.log(`  Base D1         : ${DB_NAME} (${databaseId})`);
  console.log(`  Paiements       : ${c.y('verrouillés')} (PAYOUTS_LIVE=false) — aucun argent ne sort`);
  console.log(`  Captcha         : ${/TURNSTILE/.test(toml()) ? 'Turnstile' : 'arithmétique (à remplacer avant ouverture publique)'}`);

  if (failed === 0) {
    console.log(`\n${c.g('Déploiement vérifié : les 6 contrôles passent.')}`);
  } else {
    console.log(`\n${c.r(`${failed} contrôle(s) en échec.`)} Envoie-moi la sortie de ce script, je corrige.`);
  }
  console.log(`\n${c.b('Il te reste 2 choses (2 minutes) :')}`);
  console.log('  1. créer ton compte administrateur :');
  console.log(c.d('     node scripts/create-admin-cloud.mjs'));
  console.log('  2. (plus tard) activer les paiements FaucetPay réels : voir docs/GUIDE-COMPLET.md phase 4');
  process.exit(failed === 0 ? 0 : 1);
})().catch((e) => die(e && e.message));
