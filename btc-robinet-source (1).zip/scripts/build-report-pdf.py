#!/usr/bin/env python3
"""Génère docs/Rapport-de-tests-BTC-ROBINET.pdf à partir des JSON de tests.

Usage :
    pip install reportlab      (une seule fois)
    python3 scripts/build-report-pdf.py
"""
import json
import os
from datetime import datetime, timezone

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DOCS = os.path.join(ROOT, 'docs')
OUT = os.path.join(DOCS, 'Rapport-de-tests-BTC-ROBINET.pdf')

ORANGE = colors.HexColor('#F7931A')
DARK = colors.HexColor('#12100E')
GREY = colors.HexColor('#5b5751')
LIGHT = colors.HexColor('#f5f1ea')
GREEN = colors.HexColor('#1a7f37')
RED = colors.HexColor('#c0392b')


def load(name):
    path = os.path.join(DOCS, name)
    if not os.path.exists(path):
        return None
    try:
        with open(path, encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return None


node = load('TEST-REPORT.json')
worker = load('TEST-REPORT-WORKER.json')
workerd = load('TEST-REPORT-WORKERD.json')

suites = [
    ('Application (serveur Node + SQLite)', 'npm test', node,
     'Vrai serveur HTTP, vraie base SQLite : parcours complet du site.'),
    ('Chemin Cloudflare Workers + D1', 'npm run test:worker', worker,
     'Même code applicatif avec une entrée Web (Request/Response) et un adaptateur D1.'),
    ('Runtime Cloudflare réel (workerd + D1)', 'npm run test:workerd', workerd,
     'Worker compilé par Wrangler, exécuté dans workerd avec une vraie base D1 locale.'),
]
suites = [s for s in suites if s[2]]


def summary(data, key='passed'):
    if not data or 'summary' not in data:
        return 0
    return data['summary'].get(key, 0) or 0


total_ok = sum(summary(s[2]) for s in suites)
total_ko = sum(summary(s[2], 'failed') for s in suites)

styles = getSampleStyleSheet()
styles.add(ParagraphStyle('Title2', parent=styles['Title'], fontName='Helvetica-Bold',
                          fontSize=22, leading=26, textColor=DARK, alignment=TA_LEFT,
                          spaceAfter=2))
styles.add(ParagraphStyle('Sub', parent=styles['Normal'], fontSize=10.5, leading=15,
                          textColor=GREY, spaceAfter=10))
styles.add(ParagraphStyle('H1x', parent=styles['Heading1'], fontName='Helvetica-Bold',
                          fontSize=14, leading=18, textColor=DARK, spaceBefore=14, spaceAfter=6))
styles.add(ParagraphStyle('H2x', parent=styles['Heading2'], fontName='Helvetica-Bold',
                          fontSize=11, leading=14, textColor=colors.HexColor('#2b2620'),
                          spaceBefore=10, spaceAfter=4))
styles.add(ParagraphStyle('Cell', parent=styles['Normal'], fontSize=7.4, leading=9.2))
styles.add(ParagraphStyle('CellB', parent=styles['Normal'], fontName='Helvetica-Bold',
                          fontSize=7.4, leading=9.2))
styles.add(ParagraphStyle('CellH', parent=styles['Normal'], fontName='Helvetica-Bold',
                          fontSize=7.4, leading=9.2, textColor=colors.white))
styles.add(ParagraphStyle('Note', parent=styles['Normal'], fontSize=9, leading=13,
                          textColor=GREY, spaceBefore=4, spaceAfter=8))


def esc(text, limit=110):
    text = str(text or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    return text[:limit] + ('…' if len(text) > limit else '')


def table(rows, widths, header_bg=DARK):
    data = [[Paragraph(c, styles['CellH']) for c in rows[0]]]
    for row in rows[1:]:
        data.append([Paragraph(c, styles['Cell']) for c in row])
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), header_bg),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#d8d2c8')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT]),
        ('LEFTPADDING', (0, 0), (-1, -1), 4),
        ('RIGHTPADDING', (0, 0), (-1, -1), 4),
        ('TOPPADDING', (0, 0), (-1, -1), 2.6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2.6),
    ]))
    return t


story = []
story.append(Paragraph('BTC ROBINET', styles['Title2']))
story.append(Paragraph('Rapport de tests — vérification du site, du robinet, des paiements et du portage Cloudflare',
                       styles['Sub']))

badge_color = GREEN if total_ko == 0 else RED
badge = Table([[Paragraph(
    f'<font color="white" size="13"><b>{total_ok} contrôles réussis — {total_ko} échec(s)</b></font>',
    styles['Normal'])]], colWidths=[170 * mm])
badge.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, -1), badge_color),
    ('LEFTPADDING', (0, 0), (-1, -1), 8), ('TOPPADDING', (0, 0), (-1, -1), 6),
    ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
]))
story.append(badge)
story.append(Spacer(1, 8))
story.append(Paragraph(
    f'Date : {datetime.now(timezone.utc).strftime("%d/%m/%Y %H:%M")} UTC · '
    'Environnement : Node.js + SQLite local, runtime Cloudflare <i>workerd</i>, '
    'FaucetPay en <b>mode simulation</b>, verrou <font face="Courier">PAYOUTS_LIVE=false</font>. '
    '<b>Aucun bitcoin réel n\'a été déplacé.</b>', styles['Note']))

story.append(Paragraph('1. Synthèse par suite', styles['H1x']))
rows = [['Suite de tests', 'Commande', 'Résultat']]
for label, cmd, data, _ in suites:
    ok, ko = summary(data), summary(data, 'failed')
    rows.append([esc(label, 60), f'<font face="Courier" size="6.8">{esc(cmd, 40)}</font>',
                 f'<b>{ok}/{ok}</b> — {ko} échec(s)' if ko == 0 else f'<font color="#c0392b"><b>{ok}/{ok + ko}</b></font>'])
rows.append(['<b>TOTAL</b>', '<font face="Courier" size="6.8">npm run test:all</font>',
             f'<b>{total_ok}/{total_ok}</b> — {total_ko} échec(s)'])
story.append(table(rows, [58 * mm, 45 * mm, 67 * mm]))
story.append(Paragraph(
    'Les trois suites exécutent le même code métier. La troisième est la plus proche d\'un '
    'déploiement réel : c\'est elle qui a mis au jour les anomalies corrigées ci-dessous.',
    styles['Note']))

story.append(Paragraph('2. Anomalies réelles trouvées puis corrigées', styles['H1x']))
story.append(Paragraph(
    'Ces défauts ne se produisaient que dans le runtime Cloudflare : les tests Node, même '
    'complets, ne pouvaient pas les voir. Ils sont désormais couverts par des tests permanents.',
    styles['Note']))
fixes = [
    ['#', 'Symptôme en production', 'Cause', 'Correction'],
    ['1', 'Le Worker <b>plantait au démarrage</b> (<font face="Courier" size="6.6">__dirname is not defined</font>) : toutes les pages en erreur 500',
     'config.js utilisait fs, path et __dirname, absents du runtime Workers',
     'Chargement tolérant des modules, racine calculée seulement si possible'],
    ['2', '<b>Aucune table créée</b> (<font face="Courier" size="6.6">incomplete input: SQLITE_ERROR</font>) : site inutilisable',
     'D1Database.exec() coupe l\'entrée sur les retours à la ligne, pas sur « ; » : les CREATE TABLE multilignes étaient tronqués',
     'Nouveau découpage SQL + exécution instruction par instruction'],
    ['3', '<b>/dashboard et /admin s\'ouvraient sans être connecté</b> : faille d\'accès aux zones privées',
     'html_handling par défaut : Cloudflare servait dashboard.html directement, sans passer par le Worker',
     'html_handling = "none" + routage unique par l\'application'],
    ['4', 'Les pages HTML étaient introuvables en Worker (pas de disque)',
     'serveStatic() lisait des fichiers sur le disque',
     'Pages embarquées dans le bundle et servies par l\'application, après contrôle de session'],
]
story.append(table(fixes, [7 * mm, 52 * mm, 55 * mm, 56 * mm]))

story.append(PageBreak())

story.append(Paragraph('3. Détail des contrôles — runtime Cloudflare réel', styles['H1x']))
story.append(Paragraph(
    'Exécution de <font face="Courier" size="7.5">npm run test:workerd</font> : Worker compilé '
    'par Wrangler, exécuté dans workerd, base D1 créée par le schéma du projet.', styles['Note']))
rows = [['Résultat', 'Contrôle', 'Détail']]
for r in (workerd or {}).get('results', []):
    rows.append(['✔' if r.get('ok') else '✘', esc(r.get('name'), 62), esc(r.get('info'), 52) or '—'])
story.append(table(rows, [15 * mm, 78 * mm, 77 * mm]))

story.append(Paragraph('4. Détail des contrôles — chemin Cloudflare simulé', styles['H1x']))
rows = [['Résultat', 'Contrôle', 'Détail']]
for r in (worker or {}).get('results', []):
    rows.append(['✔' if r.get('ok') else '✘', esc(r.get('name'), 62), esc(r.get('info'), 52) or '—'])
story.append(table(rows, [15 * mm, 78 * mm, 77 * mm]))

story.append(Paragraph('5. Détail des contrôles — application Node (129 contrôles)', styles['H1x']))
rows = [['Résultat', 'Contrôle', 'Section']]
for r in (node or {}).get('results', []):
    rows.append(['✔' if r.get('ok') else '✘', esc(r.get('name'), 88), esc(r.get('section'), 24)])
story.append(table(rows, [15 * mm, 110 * mm, 45 * mm]))

story.append(PageBreak())

story.append(Paragraph('6. Garanties vérifiées', styles['H1x']))
guarantees = [
    ['Garantie', 'Vérification'],
    ['Aucun paiement réel sans autorisation', 'Mode simulation, verrou PAYOUTS_LIVE=false, aucune clé API utilisée'],
    ['Jamais de paiement si solde insuffisant', 'Débit conditionnel SQL, erreur insufficient_balance testée'],
    ['Double paiement impossible', 'Clé d\'idempotence UNIQUE, rejeu testé à l\'identique'],
    ['Double réclamation impossible', 'Contraintes UNIQUE + 6 réclamations simultanées → 1 seul crédit'],
    ['Clic de shortlink non validé = 0 satoshi', 'Retour immédiat refusé (délai minimal côté serveur)'],
    ['Callback partenaire rejoué = 0 satoshi', 'Réponse duplicate: true, credited_sats: 0'],
    ['Zones privées inaccessibles sans session', '/dashboard et /admin redirigent vers /login (testé en workerd)'],
    ['/admin réservé à l\'administrateur', 'Un membre est renvoyé avec admin_required'],
    ['Aucun secret exposé au navigateur', 'Contenu de /api/public/config inspecté'],
    ['Mots de passe jamais en clair', 'PBKDF2-SHA256, 210 000 itérations, vérifié en base'],
]
story.append(table(guarantees, [72 * mm, 98 * mm]))

story.append(Paragraph('7. Ce qui reste à valider hors de ce poste', styles['H1x']))
remaining = [
    ['Élément', 'Pourquoi ce n\'est pas fait ici', 'Ce qu\'il faut fournir'],
    ['Paiement FaucetPay réel', 'Engagement d\'argent réel : interdit sans autorisation écrite',
     'Clé API + autorisation + montant de test'],
    ['Déploiement Cloudflare', 'Bundle validé (Wrangler dry-run) mais publication = compte Cloudflare',
     'wrangler login + base D1 créée (database_id)'],
    ['Cloudflare Turnstile', 'Code en place, clés non créées', 'Clés site et secrète Turnstile'],
    ['Nom de domaine', 'Aucun domaine acheté (budget 0 €)', 'Sous-domaine workers.dev suffit, sinon un domaine'],
]
story.append(table(remaining, [40 * mm, 65 * mm, 65 * mm]))

story.append(Spacer(1, 10))
story.append(Paragraph(
    '<b>Conclusion.</b> Le site, le robinet, les retraits en simulation, le parrainage, '
    'l\'administration, la rentabilité et les trois modules (shortlinks, PTC, offerwalls) '
    f'passent {total_ok} contrôles, y compris dans le runtime Cloudflare réel. Le site est '
    'prêt à être publié et testé de bout en bout ; il n\'est pas encore « en production » '
    'tant que le déploiement et un paiement réel encadré n\'ont pas été faits.', styles['Normal']))


def footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(ORANGE)
    canvas.setLineWidth(1.2)
    canvas.line(18 * mm, 15 * mm, 192 * mm, 15 * mm)
    canvas.setFont('Helvetica', 7.5)
    canvas.setFillColor(GREY)
    canvas.drawString(18 * mm, 10.5 * mm, 'BTC ROBINET — rapport de tests généré automatiquement')
    canvas.drawRightString(192 * mm, 10.5 * mm, f'page {doc.page}')
    canvas.restoreState()


doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm,
                        topMargin=16 * mm, bottomMargin=20 * mm,
                        title='BTC ROBINET — Rapport de tests',
                        author='BTC ROBINET')
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print(f'✓ {OUT} — {total_ok} contrôles, {total_ko} échec(s)')
