#!/usr/bin/env node
/**
 * Remplace le ZIP déposé sur GitHub par le dépôt Git complet.
 *
 *   GITHUB_TOKEN=github_pat_xxx node scripts/push-moi.mjs
 *
 * Windows (cmd)      : set GITHUB_TOKEN=github_pat_xxx && scripts\push-moi.bat
 * Windows (PowerShell): $env:GITHUB_TOKEN="github_pat_xxx"; node scripts/push-moi.mjs
 * macOS / Linux      : GITHUB_TOKEN=github_pat_xxx ./scripts/push-moi.sh
 *
 * Le token n'est jamais écrit sur le disque, ni affiché, ni commité.
 * Aucune dépendance : fetch natif de Node 18+ et la commande git.
 */
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const TOKEN = process.env.GITHUB_TOKEN || '';
const OWNER_REPO = process.env.GITHUB_REPO || 'thomasmartialfrancomme-oss/btc-robinet';
const API = `https://api.github.com/repos/${OWNER_REPO}`;
const ZIP_NAME = 'btc-robinet-source.zip';

const step = (n, text) => console.log(`\n\u001b[1m→ ${n}. ${text}\u001b[0m`);
const ok = (text) => console.log(`   \u001b[32m✓\u001b[0m ${text}`);
const warn = (text) => console.log(`   \u001b[33m!\u001b[0m ${text}`);
const die = (text, code = 1) => {
  console.error(`   \u001b[31m✗ ${text}\u001b[0m`);
  process.exit(code);
};

function git(args, opts = {}) {
  const res = spawnSync('git', args, { cwd: ROOT, encoding: 'utf8', ...opts });
  return { code: res.status, out: (res.stdout || '') + (res.stderr || '') };
}

async function api(urlPath, init = {}) {
  const res = await fetch(urlPath.startsWith('http') ? urlPath : API + urlPath, {
    ...init,
    headers: {
      Authorization: `Bearer ${TOKEN}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      'User-Agent': 'btc-robinet-push',
      ...(init.headers || {}),
    },
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* réponse non JSON */ }
  return { status: res.status, json, text };
}

(async () => {
  console.log('\u001b[1mBTC ROBINET — publication du dépôt sur GitHub\u001b[0m');
  console.log(`Dépôt cible : ${OWNER_REPO}`);

  /* 1. Vérifications préalables --------------------------------------- */
  step(1, 'Vérification du token et des outils');
  if (!TOKEN) {
    die('GITHUB_TOKEN n\'est pas défini.\n'
      + '     Windows PowerShell : $env:GITHUB_TOKEN="github_pat_xxx"; node scripts/push-moi.mjs\n'
      + '     Windows cmd        : set GITHUB_TOKEN=github_pat_xxx\n'
      + '     Ne collez jamais le token dans la conversation : il doit rester chez vous.');
  }
  if (!/^github_pat_|^ghp_/.test(TOKEN)) {
    warn('Le token ne ressemble pas à un token GitHub (github_pat_… ou ghp_…). On continue quand même.');
  }
  if (git(['--version']).code !== 0) die('git n\'est pas installé ou n\'est pas dans le PATH.');
  ok(`git présent — ${fs.existsSync(path.join(ROOT, '.git')) ? 'dépôt local trouvé' : 'pas de dépôt local (initialisation)'}`);

  /* 2. Tests avant envoi ---------------------------------------------- */
  step(2, 'Exécution des tests (rien n\'est envoyé si un test échoue)');
  const test = spawnSync('npm', ['test'], { cwd: ROOT, encoding: 'utf8', shell: process.platform === 'win32' });
  const testOut = (test.stdout || '') + (test.stderr || '');
  const summary = testOut.split('\n').find((l) => /R[ÉE]SULTAT\s*:/i.test(l) && /test\(s\)/i.test(l))
    || testOut.split('\n').find((l) => /R[ÉE]SULTAT\s*:/i.test(l)) || '';
  if (test.status !== 0) {
    console.log(testOut.split('\n').slice(-15).join('\n'));
    die('les tests échouent : envoi annulé (aucune modification sur GitHub).');
  }
  ok(summary.trim() || 'tests OK');

  /* 3. Identité GitHub et branche par défaut -------------------------- */
  step(3, 'Connexion à l\'API GitHub');
  const me = await api('https://api.github.com/user');
  if (me.status === 401) die('token refusé (401). Il est expiré, révoqué ou mal copié.');
  if (me.status !== 200) die(`réponse inattendue de GitHub (${me.status}) : ${String(me.text).slice(0, 160)}`);
  ok(`authentifié comme ${me.json.login}`);

  const repo = await api(API);
  if (repo.status === 404) {
    die(`dépôt introuvable (404). Vérifiez « ${OWNER_REPO} » et que le token a bien le droit Contents sur CE dépôt.`);
  }
  if (repo.status !== 200) die(`impossible de lire le dépôt (${repo.status}).`);
  const branch = repo.json.default_branch || 'main';
  const perms = repo.json.permissions || {};
  if (perms.push === false) die('le token n\'a pas le droit d\'écrire (Contents: Read and write manquant).');
  ok(`dépôt accessible — branche par défaut « ${branch} », privé : ${repo.json.private ? 'oui' : 'non'}`);

  /* 4. Retrait du zip déposé par l'interface web ---------------------- */
  step(4, `Retrait de l'archive ${ZIP_NAME}`);
  const zip = await api(`/contents/${ZIP_NAME}?ref=${branch}`);
  if (zip.status === 200 && zip.json && zip.json.sha) {
    const del = await api(`/contents/${ZIP_NAME}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: 'chore: retrait de l\'archive (le code source est désormais versionné)',
        sha: zip.json.sha,
        branch,
      }),
    });
    if (del.status === 200 || del.status === 204) ok('archive supprimée du dépôt');
    else warn(`suppression impossible (${del.status}) — le push la remplacera de toute façon`);
  } else {
    ok('aucune archive à supprimer (déjà propre)');
  }

  /* 5. Configuration du dépôt local ----------------------------------- */
  step(5, 'Préparation du dépôt local');
  if (!fs.existsSync(path.join(ROOT, '.git'))) {
    const init = git(['init', '-b', 'main']);
    if (init.code !== 0) die(`git init a échoué : ${init.out.trim()}`);
    ok('dépôt Git initialisé');
  }
  if (!git(['config', 'user.email']).out.trim()) git(['config', 'user.email', 'dev@btc-robinet.local']);
  if (!git(['config', 'user.name']).out.trim()) git(['config', 'user.name', 'BTC ROBINET']);

  const status = git(['status', '--porcelain']).out.trim();
  if (status) {
    git(['add', '-A']);
    const commit = git(['commit', '-m', 'chore: état courant du site avant publication']);
    if (commit.code !== 0) warn(`commit non créé : ${commit.out.trim().split('\n')[0]}`);
    else ok('modifications locales enregistrées dans un commit');
  } else {
    ok('arbre de travail propre');
  }
  const fileCount = git(['ls-files']).out.trim().split('\n').filter(Boolean).length;
  ok(`${fileCount} fichiers suivis`);

  // Garde-fou : aucun secret ne doit partir.
  const tracked = git(['ls-files']).out.split('\n');
  const dangerous = tracked.filter((f) => /(^|\/)\.env$|^data\/|node_modules|\.db$|\.wrangler|\.dev\.vars/.test(f));
  if (dangerous.length) die(`arrêt : fichiers sensibles suivis par Git → ${dangerous.join(', ')}`);
  ok('aucun fichier sensible (`.env`, base de données, secrets) dans l\'envoi');

  /* 6. Envoi ---------------------------------------------------------- */
  step(6, 'Envoi du code source (force : le dépôt distant ne doit contenir que ce projet)');
  git(['remote', 'remove', 'origin']);
  const addRemote = git(['remote', 'add', 'origin', `https://github.com/${OWNER_REPO}.git`]);
  if (addRemote.code !== 0) die(`impossible de configurer le remote : ${addRemote.out.trim()}`);

  // Le token passe par une variable d'environnement du processus git uniquement.
  // Il n'est écrit ni dans .git/config, ni dans l'historique du shell.
  const askpass = path.join(ROOT, '.git', 'askpass.sh');
  const askpassBat = path.join(ROOT, '.git', 'askpass.bat');
  const isWin = process.platform === 'win32';
  const helper = isWin
    ? `!f() { echo username=x-access-token; echo password=%GITHUB_TOKEN%; }; f`
    : `!f() { echo username=x-access-token; echo password="$GITHUB_TOKEN"; }; f`;

  const push = spawnSync('git', ['-c', `credential.helper=${helper}`, 'push', '--force', '-u', 'origin', `HEAD:${branch}`], {
    cwd: ROOT,
    encoding: 'utf8',
    env: { ...process.env, GIT_TERMINAL_PROMPT: '0', GITHUB_TOKEN: TOKEN },
  });
  const pushOut = ((push.stdout || '') + (push.stderr || '')).replace(new RegExp(TOKEN.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), '***');

  if (push.status !== 0) {
    console.log(pushOut.trim().split('\n').slice(-12).join('\n'));
    if (/No anonymous write access|Authentication failed|403/i.test(pushOut)) {
      die('GitHub a refusé l\'écriture : le token n\'a pas le droit « Contents: Read and write » sur ce dépôt,\n'
        + '     ou il est expiré. Régénérez-le puis relancez.');
    }
    die('le push a échoué.');
  }
  ok('code source publié');

  /* 7. Vérification finale -------------------------------------------- */
  step(7, 'Vérification de ce qui est réellement en ligne');
  const tree = await api(`/git/trees/${branch}?recursive=1`);
  if (tree.status === 200 && tree.json) {
    const files = (tree.json.tree || []).filter((e) => e.type === 'blob');
    ok(`${files.length} fichiers en ligne`);
    const hasZip = files.some((f) => f.path === ZIP_NAME);
    const hasCi = files.some((f) => f.path === '.github/workflows/ci.yml');
    console.log(`   ${hasZip ? '\u001b[31m✗\u001b[0m' : '\u001b[32m✓\u001b[0m'} archive zip ${hasZip ? 'encore présente' : 'absente'}`);
    console.log(`   ${hasCi ? '\u001b[32m✓\u001b[0m' : '\u001b[31m✗\u001b[0m'} workflow CI ${hasCi ? 'présent (les tests vont tourner)' : 'absent'}`);
  }

  console.log('\n\u001b[1m\u001b[32mTerminé.\u001b[0m');
  console.log(`Dépôt  : https://github.com/${OWNER_REPO}`);
  console.log('Actions: https://github.com/' + OWNER_REPO + '/actions  (les tests démarrent en ~1 min)');
  console.log('\n\u001b[33mDernière étape : révoquez le token\u001b[0m');
  console.log('  https://github.com/settings/tokens  →  Delete');
  // Nettoyage des fichiers d'aide éventuels
  for (const f of [askpass, askpassBat]) { try { fs.rmSync(f, { force: true }); } catch { /* sans effet */ } }
})().catch((err) => {
  console.error(`\n\u001b[31mErreur inattendue : ${err && err.message}\u001b[0m`);
  process.exit(1);
});
