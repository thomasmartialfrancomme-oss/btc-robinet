#!/usr/bin/env node
/**
 * Test de connexion FaucetPay — LECTURE SEULE, AUCUN PAIEMENT.
 *
 *   FAUCETPAY_MODE=faucetpay FAUCETPAY_API_VERSION=v2 \
 *   FAUCETPAY_V2_READ_KEY=xxx node scripts/test-faucetpay.mjs
 *
 * ou API v1 :
 *   FAUCETPAY_MODE=faucetpay FAUCETPAY_API_KEY=xxx node scripts/test-faucetpay.mjs
 *
 * Ce script appelle uniquement des points de lecture :
 *   v1 : /getbalance, /checkaddress, /payouts
 *   v2 : /balance, /check-address, /payouts
 * Il n'appelle JAMAIS /send. Il est impossible qu'il déplace un satoshi.
 *
 * La clé peut aussi être fournie à l'invite (elle ne s'affiche pas et n'est pas
 * enregistrée) : plus sûr que de la mettre dans l'historique du shell.
 */
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const c = {
  b: (s) => `\u001b[1m${s}\u001b[0m`, g: (s) => `\u001b[32m${s}\u001b[0m`,
  y: (s) => `\u001b[33m${s}\u001b[0m`, r: (s) => `\u001b[31m${s}\u001b[0m`, d: (s) => `\u001b[2m${s}\u001b[0m`,
};
const ok = (t, extra = '') => console.log(`   ${c.g('✓')} ${t}${extra ? c.d(' — ' + extra) : ''}`);
const warn = (t, extra = '') => console.log(`   ${c.y('!')} ${t}${extra ? c.d(' — ' + extra) : ''}`);
const bad = (t, extra = '') => console.log(`   ${c.r('✗')} ${t}${extra ? c.d(' — ' + extra) : ''}`);

function ask(question, { hidden = false } = {}) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    if (hidden) {
      rl._writeToOutput = (str) => {
        if (str.includes(question)) rl.output.write(str); else rl.output.write('*');
      };
    }
    rl.question(question, (a) => { rl.close(); process.stdout.write('\n'); resolve(a.trim()); });
  });
}

const STATUS = {
  401: 'IP non autorisée ou compte faucet suspendu',
  402: 'solde du faucet insuffisant',
  403: 'clé API invalide ou manquante',
  405: 'montant invalide',
  410: 'devise non supportée',
  450: 'limite d\'envoi du faucet atteinte',
  456: 'destinataire non payable',
  457: 'destinataire refusé par les règles du faucet',
  459: 'trop de requêtes (rate limit)',
};

let FAILED = 0;

async function v1(base, key, method, params = {}) {
  const body = new URLSearchParams({ api_key: key, ...params });
  const res = await fetch(`${base}/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
    signal: AbortSignal.timeout(15000),
  });
  const data = await res.json().catch(() => ({}));
  return { httpStatus: res.status, ...data };
}

async function v2(base, key, endpoint, body = {}) {
  const res = await fetch(`${base}${endpoint}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(15000),
  });
  const data = await res.json().catch(() => ({}));
  return { httpStatus: res.status, ok: res.ok, ...data };
}

(async () => {
  console.log(c.b('\nBTC ROBINET — test de connexion FaucetPay (lecture seule, aucun paiement)\n'));

  const version = (process.env.FAUCETPAY_API_VERSION || 'v2').toLowerCase();
  const baseV1 = 'https://faucetpay.io/api/v1';
  const baseV2 = 'https://faucetpay.io/api/v2';

  console.log(c.d(`Mode : ${version} — ${
    version === 'v2' ? 'clé scoped (read), aucun whitelist d\'IP requis' : 'clé API v1 (whitelist d\'IP requise pour /send)'}\n`));

  /* --- 1. Clé ------------------------------------------------------- */
  console.log(c.b('→ 1. Clé API'));
  let key = version === 'v2'
    ? (process.env.FAUCETPAY_V2_READ_KEY || process.env.FAUCETPAY_API_KEY || '')
    : (process.env.FAUCETPAY_API_KEY || '');

  if (!key) {
    warn('aucune clé dans l\'environnement → saisie manuelle');
    key = await ask(`   Colle la clé ${version === 'v2' ? 'scoped READ' : 'API v1'} (masquée, non enregistrée) : `, { hidden: true });
  }
  if (!key || key.length < 12) { bad('clé absente ou trop courte'); process.exit(1); }
  ok(`clé fournie (${key.length} caractères, jamais affichée)`);

  /* --- 2. Solde du faucet ------------------------------------------- */
  console.log(c.b('\n→ 2. Solde du faucet (c\'est ce solde qui paie les membres)'));
  let balanceSats = null;
  try {
    if (version === 'v2') {
      const r = await v2(baseV2, key, '/balance', { currency: 'BTC' });
      if (r.httpStatus === 401 || r.httpStatus === 403) {
        bad('clé refusée', r.message || STATUS[r.httpStatus] || `HTTP ${r.httpStatus}`);
        FAILED += 1;
      } else if (!r.ok) {
        bad('réponse inattendue', r.message || `HTTP ${r.httpStatus}`);
        FAILED += 1;
      } else {
        const btc = r.balance ?? r.balance_bitcoin ?? r.amount;
        balanceSats = typeof btc === 'string' ? parseInt(btc, 10) : btc;
        ok('clé acceptée, solde lu', `${balanceSats} sats`);
      }
    } else {
      const r = await v1(baseV1, key, 'getbalance', { currency: 'BTC' });
      if (r.status === 200) {
        balanceSats = parseInt(r.balance, 10);
        ok('clé acceptée, solde lu', `${balanceSats} sats`);
      } else {
        bad('refus', `code ${r.status} — ${STATUS[r.status] || r.message || ''}`);
        FAILED += 1;
      }
    }
  } catch (e) {
    bad('erreur réseau', e.message);
    FAILED += 1;
  }

  if (balanceSats !== null) {
    if (balanceSats <= 0) warn('solde à 0 : les retraits des membres seront refusés (402) tant que tu n\'approvisionnes pas');
    else if (balanceSats < 1000) warn(`solde faible (${balanceSats} sats) : de quoi payer environ ${Math.floor(balanceSats / 500)} retrait(s) au minimum de 500 sats`);
    else ok('solde suffisant pour les retraits configurés');
  }

  /* --- 3. Adresse de paiement --------------------------------------- */
  console.log(c.b('\n→ 3. Vérification d\'une adresse de destinataire'));
  let address = process.env.FAUCETPAY_TEST_ADDRESS || '';
  if (!address) address = await ask('   Adresse FaucetPay à tester (ton compte, ex. monpseudo@faucetpay.io) : ');
  if (address) {
    try {
      if (version === 'v2') {
        const r = await v2(baseV2, key, '/check-address', { address, currency: 'BTC' });
        if (r.ok && (r.valid === undefined || r.valid)) ok('adresse valide', `hash ${(r.payout_user_hash || r.hash || '').slice(0, 16)}…`);
        else { bad('adresse refusée', r.message || `HTTP ${r.httpStatus}`); FAILED += 1; }
      } else {
        const r = await v1(baseV1, key, 'checkaddress', { address, currency: 'BTC' });
        if (r.status === 200) ok('adresse valide', `hash ${String(r.payout_user_hash || '').slice(0, 16)}…`);
        else { bad('adresse refusée', `code ${r.status} — ${STATUS[r.status] || r.message || ''}`); FAILED += 1; }
      }
    } catch (e) { bad('erreur réseau', e.message); FAILED += 1; }
  } else {
    warn('adresse non testée');
  }

  /* --- 4. Historique ------------------------------------------------ */
  console.log(c.b('\n→ 4. Historique des paiements du faucet'));
  try {
    if (version === 'v2') {
      const r = await v2(baseV2, key, '/payouts', { currency: 'BTC', count: 5 });
      if (r.ok) ok('historique lisible', `${(r.rewards || r.payouts || []).length} paiement(s) récent(s)`);
      else { warn('historique indisponible', r.message || `HTTP ${r.httpStatus}`); }
    } else {
      const r = await v1(baseV1, key, 'payouts', { currency: 'BTC', count: 5 });
      if (r.status === 200) ok('historique lisible', `${(r.rewards || []).length} paiement(s) récent(s)`);
      else warn('historique indisponible', `code ${r.status}`);
    }
  } catch (e) { warn('erreur réseau', e.message); }

  /* --- 5. Empreinte de la clé (utile pour comparer) ----------------- */
  console.log(c.b('\n→ 5. Empreinte de la clé'));
  const fingerprint = crypto.createHash('sha256').update(key).digest('hex').slice(0, 12);
  console.log(`   ${c.d('empreinte')} ${fingerprint} ${c.d('(à comparer avec ce que tu as enregistré sur Cloudflare — jamais la clé elle-même)')}`);

  /* --- Résumé ------------------------------------------------------- */
  console.log(`\n${c.b('Résumé')}`);
  if (FAILED === 0) {
    console.log(c.g('   La clé fonctionne en lecture. Tu peux passer à l\'étape suivante du guide (phase 4.3).'));
    console.log(c.d('   Rappel : PAYOUTS_LIVE reste "false" jusqu\'à ton test encadré à 50 sats.'));
  } else {
    console.log(c.r(`   ${FAILED} contrôle(s) en échec — corrige avant d'ouvrir les paiements.`));
    console.log(c.d('   Aucun paiement n\'a été tenté : ce script ne fait que lire.'));
  }
  process.exit(FAILED === 0 ? 0 : 1);
})().catch((e) => { console.error(c.r(e && e.message)); process.exit(1); });
