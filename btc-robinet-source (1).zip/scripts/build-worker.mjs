/**
 * Prépare le worker Cloudflare :
 *  - génère worker/schema.generated.js (schéma SQL embarqué) ;
 *  - vérifie que les dossiers nécessaires existent.
 *
 * Usage : npm run build:worker
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const schema = fs.readFileSync(path.join(ROOT, 'db', 'schema.sql'), 'utf8');

const banner = `// FICHIER GÉNÉRÉ AUTOMATIQUEMENT — ne pas éditer.
// Source : db/schema.sql — régénérer avec : npm run build:worker
`;
fs.writeFileSync(
  path.join(ROOT, 'worker', 'schema.generated.js'),
  `${banner}export default ${JSON.stringify(schema)};\n`,
  'utf8'
);

// Pages HTML embarquées : le Worker n'a pas de disque. La liaison ASSETS sert
// les fichiers de public/, mais l'application (contrôle de session, redirections)
// a besoin du CONTENU des pages. On les embarque donc à la compilation.
const pages = {};
for (const file of fs.readdirSync(path.join(ROOT, 'public'))) {
  if (file.endsWith('.html')) pages[file] = fs.readFileSync(path.join(ROOT, 'public', file), 'utf8');
}
fs.writeFileSync(
  path.join(ROOT, 'worker', 'pages.generated.js'),
  `${banner}export default ${JSON.stringify(pages)};\n`,
  'utf8'
);

console.log('✓ worker/schema.generated.js généré');
console.log(`✓ worker/pages.generated.js généré (${Object.keys(pages).length} pages)`);
console.log('  → déploiement : npx wrangler deploy  (voir docs/MISE-EN-LIGNE.md, option B)');
