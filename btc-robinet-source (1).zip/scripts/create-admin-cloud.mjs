#!/usr/bin/env node
/**
 * Crée (ou réinitialise) ton compte administrateur dans la base D1 EN LIGNE.
 *
 *   node scripts/create-admin-cloud.mjs
 *
 * Le script demande le pseudo, l'e-mail, le mot de passe et l'adresse FaucetPay,
 * calcule le hash PBKDF2 exactement comme le site, écrit un fichier .sql temporaire
 * (supprimé aussitôt après) puis l'exécute avec :
 *   npx wrangler d1 execute btc-robinet --remote --file=...
 *
 * Pourquoi un fichier plutôt qu'un --command : PowerShell déforme les guillemets
 * et les « $ » du hash, ce qui insère un mot de passe inutilisable.
 */
import { spawnSync } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import readline from 'node:readline';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const { hashPassword, randomCode } = require('../src/lib/security.js');
const isWin = process.platform === 'win32';
const DB_NAME = process.env.D1_NAME || 'btc-robinet';

const g = (s) => `\u001b[32m${s}\u001b[0m`;
const r = (s) => `\u001b[31m${s}\u001b[0m`;
const d = (s) => `\u001b[2m${s}\u001b[0m`;

function ask(question, { hidden = false } = {}) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    if (hidden) {
      rl._writeToOutput = (str) => {
        if (str.includes(question)) rl.output.write(str);
        else rl.output.write('*');
      };
    }
    rl.question(question, (a) => { rl.close(); process.stdout.write('\n'); resolve(a.trim()); });
  });
}
const sqlStr = (v) => `'${String(v).replace(/'/g, "''")}'`;

(async () => {
  console.log('\u001b[1mCréation d\'un administrateur dans la base D1 en ligne\u001b[0m');
  console.log(d(`Base : ${DB_NAME} — utilise bien ton compte Cloudflare (wrangler login déjà fait).\n`));

  const username = await ask('Pseudo (ex. admin) : ');
  if (!/^[A-Za-z0-9_.-]{3,32}$/.test(username)) { console.error(r('Pseudo invalide : 3 à 32 caractères, lettres/chiffres/_ . -')); process.exit(1); }

  const email = await ask('E-mail de connexion : ');
  if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(email)) { console.error(r('E-mail invalide.')); process.exit(1); }

  const payout = await ask('Adresse FaucetPay (e-mail ou pseudo) : ');
  if (payout.length < 3) { console.error(r('Adresse FaucetPay invalide.')); process.exit(1); }

  const password = await ask('Mot de passe (10 caractères minimum, masqué) : ', { hidden: true });
  if (password.length < 10) { console.error(r('Mot de passe trop court : 10 caractères minimum.')); process.exit(1); }
  const confirm = await ask('Confirmation du mot de passe : ', { hidden: true });
  if (confirm !== password) { console.error(r('Les deux mots de passe ne correspondent pas.')); process.exit(1); }

  console.log(d('\nCalcul du hash PBKDF2-SHA256 (210 000 itérations)…'));
  const hash = await hashPassword(password);
  const code = randomCode(7);

  // ON CONFLICT évite un doublon si le pseudo ou l'e-mail existe déjà.
  const sql = `INSERT INTO users (username, email, password_hash, payout_address, referral_code, role, status)
VALUES (${sqlStr(username)}, ${sqlStr(email.toLowerCase())}, ${sqlStr(hash)}, ${sqlStr(payout)}, ${sqlStr(code)}, 'admin', 'active')
ON CONFLICT(username) DO UPDATE SET
  email = excluded.email,
  password_hash = excluded.password_hash,
  payout_address = excluded.payout_address,
  role = 'admin',
  status = 'active';
`;
  const tmp = path.join(os.tmpdir(), `btc-robinet-admin-${crypto.randomBytes(6).toString('hex')}.sql`);
  fs.writeFileSync(tmp, sql, { encoding: 'utf8', mode: 0o600 });

  try {
    console.log(d('Envoi à la base D1 distante…\n'));
    const res = spawnSync(isWin ? 'npx.cmd' : 'npx',
      ['--yes', 'wrangler', 'd1', 'execute', DB_NAME, '--remote', `--file=${tmp}`],
      { cwd: ROOT, stdio: 'inherit' });
    if (res.status !== 0) {
      console.error(r('\nÉchec. Vérifie que tu es connecté (`npx wrangler login`) et que la base existe.'));
      process.exit(1);
    }
  } finally {
    // Le fichier contient un hash de mot de passe : il ne doit pas rester.
    try { fs.rmSync(tmp, { force: true }); } catch { /* sans effet */ }
  }

  console.log(g('\n✓ Administrateur créé ou mis à jour.'));
  console.log(`  Pseudo : ${username}`);
  console.log('  Connexion : ' + d('https://<ton-sous-domaine>.workers.dev/login'));
  console.log(d('\n  Le fichier SQL temporaire a été supprimé.'));
})().catch((e) => { console.error(r(e && e.message)); process.exit(1); });
