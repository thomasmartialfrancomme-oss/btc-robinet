@echo off
REM Remplace l'archive deposee sur GitHub par le depot Git complet.
REM Le token n'est jamais ecrit sur le disque.
REM
REM   set GITHUB_TOKEN=github_pat_xxx
REM   scripts\push-moi.bat
REM
REM Toute la logique est dans scripts\push-moi.mjs.
if "%GITHUB_TOKEN%"=="" (
  echo ERREUR : definissez d'abord le token, par exemple :
  echo    set GITHUB_TOKEN=github_pat_xxx
  exit /b 1
)
cd /d "%~dp0.."
node scripts\push-moi.mjs %*
