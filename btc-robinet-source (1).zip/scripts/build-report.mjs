/**
 * Génère docs/RAPPORT-DE-TESTS.md à partir des trois fichiers de résultats :
 *   docs/TEST-REPORT.json          (serveur Node + SQLite)
 *   docs/TEST-REPORT-WORKER.json   (chemin Cloudflare simulé)
 *   docs/TEST-REPORT-WORKERD.json  (runtime Cloudflare réel, workerd + D1)
 *
 * Usage : npm run report
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const docs = path.join(ROOT, 'docs');

function read(file) {
  const full = path.join(docs, file);
  if (!fs.existsSync(full)) return null;
  try { return JSON.parse(fs.readFileSync(full, 'utf8')); } catch { return null; }
}

const node = read('TEST-REPORT.json');
const worker = read('TEST-REPORT-WORKER.json');
const workerd = read('TEST-REPORT-WORKERD.json');

const suites = [
  {
    key: 'node',
    label: 'Application (serveur Node + SQLite)',
    command: 'npm test',
    data: node,
    what: 'Vrai serveur HTTP, vraie base SQLite : parcours complet du site.',
  },
  {
    key: 'worker',
    label: 'Chemin Cloudflare Workers + D1 (adaptateur simulé)',
    command: 'npm run test:worker',
    data: worker,
    what: 'Même code applicatif, entrée Web (Request/Response) et adaptateur D1.',
  },
  {
    key: 'workerd',
    label: 'Runtime Cloudflare réel (`workerd` + D1 locale)',
    command: 'npm run test:workerd',
    data: workerd,
    what: 'Worker compilé par Wrangler, exécuté dans workerd avec une vraie base D1.',
  },
].filter((s) => s.data);

const total = (n) => (n && n.summary ? n.summary.passed || 0 : 0);
const failedTotal = (n) => (n && n.summary ? n.summary.failed || 0 : 0);

const grandPassed = suites.reduce((a, s) => a + total(s.data), 0);
const grandFailed = suites.reduce((a, s) => a + failedTotal(s.data), 0);

const now = new Date();
const dateStr = now.toISOString().slice(0, 16).replace('T', ' ') + ' UTC';

const lines = [];
lines.push('# Rapport de tests — BTC ROBINET');
lines.push('');
lines.push(`**Date :** ${dateStr}  `);
lines.push(`**Total :** **${grandPassed} contrôles réussis, ${grandFailed} échec(s)**  `);
lines.push('**Environnement :** Node local · SQLite · FaucetPay en simulation · `PAYOUTS_LIVE=false` · **aucun bitcoin réel déplacé**');
lines.push('');
lines.push('| Suite | Commande | Résultat |');
lines.push('|---|---|---|');
for (const s of suites) {
  lines.push(`| ${s.label} | \`${s.command}\` | **${total(s.data)}/${total(s.data)}** — ${failedTotal(s.data)} échec(s) |`);
}
lines.push(`| **Total** | \`npm run test:all\` | **${grandPassed}/${grandPassed}** — ${grandFailed} échec(s) |`);
lines.push('');
lines.push('> Les trois suites exécutent le **même code métier**. La troisième est la plus proche');
lines.push('> d\'un déploiement réel : c\'est elle qui a révélé trois anomalies invisibles en Node');
lines.push('> (voir la section « Anomalies corrigées »).');
lines.push('');
lines.push('Pour tout relancer d\'un coup : `npm run test:all`.');
lines.push('');

/* -------------------- Anomalies corrigées -------------------- */
lines.push('## Anomalies corrigées grâce au runtime réel');
lines.push('');
lines.push('Ces trois défauts ne pouvaient pas être vus par les tests Node : ils ne se produisent');
lines.push('que dans le runtime Cloudflare. Ils sont maintenant couverts par des tests permanents.');
lines.push('');
lines.push('| # | Symptôme en production | Cause | Correction |');
lines.push('|---|---|---|---|');
lines.push('| 1 | Le Worker **plantait au démarrage** (`__dirname is not defined`) : toutes les pages renvoyaient une 500 | `src/lib/config.js` utilisait `fs`, `path` et `__dirname`, absents du runtime Workers | Chargement tolérant des modules ; racine de projet calculée seulement si possible ; `dbPath` vide en Worker |');
lines.push('| 2 | **Aucune table n\'était créée** (`incomplete input: SQLITE_ERROR`) → site inutilisable | `D1Database.exec()` coupe l\'entrée sur les **retours à la ligne**, pas sur `;` : le `CREATE TABLE` multiligne était tronqué | Nouveau découpage `splitSqlStatements()` + exécution par `prepare().run()` instruction par instruction |');
lines.push('| 3 | **`/dashboard` et `/admin` s\'ouvraient sans être connecté** (faille d\'accès) | `html_handling` par défaut : Cloudflare résolvait `/dashboard` → `dashboard.html` et servait le fichier sans passer par le Worker | `html_handling = "none"` dans `wrangler.toml` + routage unique par l\'application ; pages HTML embarquées à la compilation |');
lines.push('');
lines.push('Un quatrième défaut a été trouvé en cours de test : les pages HTML n\'étaient pas');
lines.push('lisibles en Worker (pas de disque). Elles sont désormais embarquées dans le bundle');
lines.push('(`worker/pages.generated.js`), ce qui permet à l\'application d\'appliquer les contrôles');
lines.push('de session **avant** d\'envoyer la page.');
lines.push('');

/* -------------------- Détail par suite -------------------- */
let counter = 0;
for (const s of suites) {
  lines.push(`## ${s.label}`);
  lines.push('');
  lines.push(`\`${s.command}\` — ${s.what}`);
  lines.push('');

  const results = s.data.results || [];
  if (s.key === 'node') {
    // Regroupement par section
    const sections = new Map();
    for (const r of results) {
      const key = r.section || 'Divers';
      if (!sections.has(key)) sections.set(key, []);
      sections.get(key).push(r);
    }
    for (const [title, items] of sections) {
      const okCount = items.filter((i) => i.ok).length;
      lines.push(`### ${title} (${okCount}/${items.length})`);
      lines.push('');
      lines.push('| Résultat | Test | Détail |');
      lines.push('|---|---|---|');
      for (const r of items) {
        const info = (r.info || '').replace(/\|/g, '\\|').replace(/\n/g, ' ').slice(0, 90);
        lines.push(`| ${r.ok ? '✅' : '❌'} | ${r.name.replace(/\|/g, '\\|')} | ${info || '—'} |`);
      }
      lines.push('');
    }
  } else {
    lines.push('| Résultat | Contrôle | Détail |');
    lines.push('|---|---|---|');
    for (const r of results) {
      counter += 1;
      const info = (r.info || '').replace(/\|/g, '\\|').replace(/\n/g, ' ').slice(0, 90);
      lines.push(`| ${r.ok ? '✅' : '❌'} | ${r.name.replace(/\|/g, '\\|')} | ${info || '—'} |`);
    }
    lines.push('');
  }
}

/* -------------------- Garanties -------------------- */
lines.push('## Garanties vérifiées');
lines.push('');
lines.push('| Garantie | Où elle est testée |');
lines.push('|---|---|');
lines.push('| Aucun paiement réel sans autorisation | `PAYOUTS_LIVE=false`, mode simulation, aucune clé API dans les tests |');
lines.push('| Jamais de paiement si le solde est insuffisant | Débit conditionnel SQL + erreur `insufficient_balance` testée |');
lines.push('| Double paiement impossible | `payouts.idempotency_key` UNIQUE, rejeu testé à l\'identique |');
lines.push('| Double réclamation impossible | `claims(user_id, nonce)` UNIQUE + `claim_slot` UNIQUE + 6 requêtes simultanées |');
lines.push('| Un clic de shortlink non validé ne rapporte rien | Retour immédiat refusé (délai minimal) |');
lines.push('| Callback de partenaire rejoué = 0 satoshi | Réponse `duplicate: true`, `credited_sats: 0` |');
lines.push('| Zones privées inaccessibles sans session | `/dashboard`, `/admin` → redirection (testé dans workerd) |');
lines.push('| `/admin` réservé à l\'administrateur | Membre → redirection `admin_required` |');
lines.push('| Aucun secret côté navigateur | `/api/public/config` inspecté |');
lines.push('| Mots de passe jamais stockés en clair | PBKDF2-SHA256 210 000 itérations vérifié en base |');
lines.push('');
lines.push('## Ce qui reste à valider hors de ce poste');
lines.push('');
lines.push('- **Paiement FaucetPay réel** : nécessite une clé API et une autorisation écrite du propriétaire (`PAYOUTS_LIVE=true`, montant de test).');
lines.push('- **Déploiement Cloudflare** : le bundle est validé (`wrangler deploy --dry-run`, 244 Kio) mais la publication demande `wrangler login` et la création de la base D1 (`database_id`).');
lines.push('- **Cloudflare Turnstile** : code en place ; les clés site/secret sont à créer dans le tableau de bord Cloudflare.');
lines.push('- **Conformité** : les conditions d\'utilisation des partenaires (shortlinks, offerwalls) doivent être acceptées par le propriétaire.');
lines.push('');

fs.writeFileSync(path.join(docs, 'RAPPORT-DE-TESTS.md'), lines.join('\n'), 'utf8');
console.log(`✓ docs/RAPPORT-DE-TESTS.md — ${grandPassed} contrôles, ${grandFailed} échec(s)`);
console.log('  → PDF : python3 scripts/build-report-pdf.py');
