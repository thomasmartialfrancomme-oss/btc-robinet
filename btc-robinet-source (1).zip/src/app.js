'use strict';
/**
 * Application BTC ROBINET — câblage HTTP, routes API et pages.
 */
const path = require('node:path');
const config = require('./lib/config');
const { createDb } = require('./lib/db');
const {
  Router, readBody, parseCookies, serializeCookie, clientIp,
  sendJson, redirect, serveStatic, RateLimiter,
} = require('./lib/http');
const { SettingsService } = require('./services/settings');
const { AuthService, AuthError } = require('./services/auth');
const { AntifraudService } = require('./services/antifraud');
const { FaucetPayService } = require('./services/faucetpay');
const { FaucetService, FaucetError } = require('./services/faucet');
const { PayoutService, PayoutError } = require('./services/payout');
const { ReferralService } = require('./services/referral');
const { FinanceService } = require('./services/finance');
const { ShortlinkService, ShortlinkError } = require('./services/shortlink');
const { PtcService, PtcError } = require('./services/ptc');
const { OfferwallService, OfferwallError } = require('./services/offerwall');
const {
  createMathCaptcha, verifyMathCaptcha, verifyTurnstile,
} = require('./lib/security');

const SESSION_COOKIE = 'btr_session';
const DEFAULT_PUBLIC_DIR = path.join(config.root, 'public');

/** Pages HTML servies (le contrôle d'accès fin est fait par l'API). */
const PAGES = {
  '/': 'index.html',
  '/index.html': 'index.html',
  '/register': 'register.html',
  '/login': 'login.html',
  '/dashboard': 'dashboard.html',
  '/faucet': 'faucet.html',
  '/shortlinks': 'shortlinks.html',
  '/ptc': 'ptc.html',
  '/offerwalls': 'offerwalls.html',
  '/referral': 'referral.html',
  '/withdraw': 'withdraw.html',
  '/history': 'history.html',
  '/admin': 'admin.html',
  '/legal': 'legal.html',
};

function createApp(options = {}) {
  const cfg = options.config || config;
  const PUBLIC_DIR = options.publicDir || DEFAULT_PUBLIC_DIR;
  const db = options.db || createDb(cfg.dbPath);
  const settings = new SettingsService(db);
  const antifraud = new AntifraudService(db, settings);
  const auth = new AuthService(db, settings, cfg, antifraud);
  const faucetpay = new FaucetPayService(cfg, options.fetch || globalThis.fetch);
  const faucet = new FaucetService(db, settings, faucetpay, cfg, antifraud);
  const payouts = new PayoutService(db, settings, faucetpay, cfg);
  const referral = new ReferralService(db, settings, cfg);
  const finance = new FinanceService(db, settings);
  const shortlinks = new ShortlinkService(db, settings, cfg);
  const ptc = new PtcService(db, settings, cfg);
  const offerwalls = new OfferwallService(db, settings, cfg);
  const limiter = new RateLimiter(db);

  const router = new Router();
  const app = {
    db,
    services: { settings, auth, faucet, faucetpay, payouts, referral, finance, antifraud, limiter, shortlinks, ptc, offerwalls },
    cfg,
  };

  /* ------------------------------------------------------------------ */
  /*  Helpers                                                            */
  /* ------------------------------------------------------------------ */

  class HttpError extends Error {
    constructor(message, status = 400, code = 'error', details) {
      super(message); this.status = status; this.code = code; this.details = details;
    }
  }

  const requireUser = (ctx) => {
    if (!ctx.user) throw new HttpError('Authentification requise.', 401, 'unauthenticated');
    return ctx.user;
  };
  const requireAdmin = (ctx) => {
    const u = requireUser(ctx);
    if (u.role !== 'admin') throw new HttpError('Accès administrateur requis.', 403, 'forbidden');
    return u;
  };
  const requireCsrf = (ctx) => {
    const token = ctx.req.headers['x-csrf-token'];
    if (!auth.verifyCsrf(ctx.session, token)) throw new HttpError('Jeton CSRF invalide ou absent.', 403, 'csrf');
  };
  const guard = async (name, limit, windowSeconds, ctx) => {
    const r = await limiter.hit(`${name}:${ctx.ip}`, limit, windowSeconds);
    if (!r.allowed) throw new HttpError(`Trop de tentatives. Réessayez dans ${r.retryAfter} s.`, 429, 'rate_limited', { retry_after: r.retryAfter });
  };
  /** Origine publique réelle de la requête (proxy, aperçu, production). */
  const originOf = (ctx) => {
    const proto = (ctx.req.headers['x-forwarded-proto'] || '').split(',')[0].trim()
      || (ctx.req.socket && ctx.req.socket.encrypted ? 'https' : 'http');
    const host = ctx.req.headers['x-forwarded-host'] || ctx.req.headers.host;
    return host ? `${proto}://${host}` : cfg.siteUrl;
  };
  const checkCaptcha = async (ctx) => {
    const mode = cfg.captcha.mode;
    if (mode === 'off') return;
    const body = ctx.body || {};
    if (mode === 'math') {
      const res = verifyMathCaptcha(cfg.sessionSecret, body.captcha_challenge, body.captcha_signature, body.captcha_answer);
      if (!res.ok) {
        throw new HttpError(
          res.reason === 'expired' ? 'Captcha expiré, rechargez la page.' : 'Captcha incorrect.',
          400, 'captcha'
        );
      }
      return;
    }
    if (mode === 'turnstile') {
      const res = await verifyTurnstile(cfg.captcha.turnstileSecret, body.turnstile_token, ctx.ip);
      if (!res.ok) throw new HttpError('Vérification Turnstile échouée.', 400, 'captcha', { reason: res.reason });
    }
  };
  const setSessionCookie = (res, token) => {
    res.setHeader('Set-Cookie', serializeCookie(SESSION_COOKIE, token, {
      maxAge: cfg.sessionTtlHours * 3600,
      secure: cfg.cookieSecure,
      httpOnly: true,
      sameSite: 'Lax',
    }));
  };
  const clearSessionCookie = (res) => {
    res.setHeader('Set-Cookie', serializeCookie(SESSION_COOKIE, '', { maxAge: 0, secure: cfg.cookieSecure }));
  };

  /* ------------------------------------------------------------------ */
  /*  Routes publiques                                                   */
  /* ------------------------------------------------------------------ */

  router.get('/api/public/config', async () => {
    const cfgAll = await settings.all();
    return {
      status: 200,
      body: {
        site_name: cfgAll.site_name,
        captcha: { mode: cfg.captcha.mode, site_key: cfg.captcha.turnstileSiteKey },
        modules: cfgAll.modules,
        maintenance: cfgAll.maintenance,
        faucet: {
          reward_sats: cfgAll.faucet_reward_sats,
          cooldown_seconds: cfgAll.faucet_cooldown_seconds,
          daily_limit: cfgAll.faucet_daily_limit,
        },
        min_withdraw_sats: cfgAll.min_withdraw_sats,
        referral_percent: cfgAll.referral_percent,
        payments: {
          mode: cfg.faucetpay.mode,
          live: faucetpay.live,
          label: faucetpay.live ? 'Paiements réels actifs' : (cfg.faucetpay.mode === 'mock' ? 'Mode simulation' : 'Paiements réels verrouillés'),
        },
      },
    };
  });

  router.get('/api/auth/captcha', async () => {
    if (cfg.captcha.mode !== 'math') return { status: 200, body: { mode: cfg.captcha.mode } };
    const c = createMathCaptcha(cfg.sessionSecret, 300);
    return { status: 200, body: { mode: 'math', ...c } };
  });

  router.post('/api/auth/register', async (ctx) => {
    await guard('register', 8, 3600, ctx);
    await checkCaptcha(ctx);
    const b = ctx.body || {};
    const user = await auth.register({
      username: b.username,
      email: b.email,
      password: b.password,
      payoutAddress: b.payout_address,
      refCode: b.ref,
      ip: ctx.ip,
      userAgent: ctx.req.headers['user-agent'],
    });
    const session = await auth.createSession(user.id, ctx.ip, ctx.req.headers['user-agent']);
    setSessionCookie(ctx.res, session.token);
    return { status: 201, body: { ok: true, user, csrf: session.csrf } };
  });

  router.post('/api/auth/login', async (ctx) => {
    await guard('login', 10, 900, ctx);
    const b = ctx.body || {};
    const { user, session } = await auth.login({
      login: b.login, password: b.password, ip: ctx.ip, userAgent: ctx.req.headers['user-agent'],
    });
    setSessionCookie(ctx.res, session.token);
    return { status: 200, body: { ok: true, user, csrf: session.csrf } };
  });

  router.post('/api/auth/logout', async (ctx) => {
    if (ctx.token) await auth.destroySession(ctx.token);
    clearSessionCookie(ctx.res);
    return { status: 200, body: { ok: true } };
  });

  router.get('/api/me', async (ctx) => {
    if (!ctx.user) return { status: 200, body: { authenticated: false } };
    const cfgAll = await settings.all();
    const referralSummary = await referral.summary(ctx.user, originOf(ctx));
    const provider = await payouts.getProviderStatus('BTC');
    return {
      status: 200,
      body: {
        authenticated: true,
        user: ctx.user,
        csrf: ctx.session.csrf,
        referral: referralSummary,
        settings: {
          modules: cfgAll.modules,
          min_withdraw_sats: cfgAll.min_withdraw_sats,
          faucet_reward_sats: cfgAll.faucet_reward_sats,
          maintenance: cfgAll.maintenance,
        },
        provider: { mode: provider.mode, live: provider.live, ok: provider.ok, simulated: provider.simulated },
      },
    };
  });

  router.post('/api/me/profile', async (ctx) => {
    requireCsrf(ctx);
    const user = requireUser(ctx);
    const b = ctx.body || {};
    const payoutAddress = String(b.payout_address || '').trim();
    if (payoutAddress.length < 3) throw new HttpError('Adresse FaucetPay invalide.', 422, 'bad_address');
    await db.run('UPDATE users SET payout_address = ?, payout_hash = NULL WHERE id = ?', [payoutAddress, user.id]);
    return { status: 200, body: { ok: true, user: await auth.getUserById(user.id) } };
  });

  router.post('/api/me/password', async (ctx) => {
    requireCsrf(ctx);
    const user = requireUser(ctx);
    const b = ctx.body || {};
    await auth.changePassword(user.id, b.current_password, b.new_password);
    clearSessionCookie(ctx.res);
    return { status: 200, body: { ok: true, message: 'Mot de passe modifié. Reconnectez-vous.' } };
  });

  /* ------------------------------------------------------------------ */
  /*  Robinet                                                            */
  /* ------------------------------------------------------------------ */

  router.get('/api/faucet/state', async (ctx) => {
    const user = requireUser(ctx);
    const state = await faucet.getState(user, { ip: ctx.ip });
    const cfgAll = await settings.all();
    const provider = await payouts.getProviderStatus('BTC');
    return {
      status: 200,
      body: {
        ...state,
        provider: {
          mode: provider.mode,
          live: provider.live,
          ok: provider.ok,
          balance_sats: provider.balance_sats ?? null,
          simulated: provider.simulated,
        },
        limits: { min_withdraw_sats: cfgAll.min_withdraw_sats },
      },
    };
  });

  router.post('/api/faucet/claim', async (ctx) => {
    requireCsrf(ctx);
    const user = requireUser(ctx);
    await guard('claim', 40, 3600, ctx);
    await checkCaptcha(ctx);
    const b = ctx.body || {};
    const result = await faucet.claim(user, {
      ip: ctx.ip,
      userAgent: ctx.req.headers['user-agent'],
      nonce: b.nonce,
    });
    return { status: 200, body: { ok: true, ...result } };
  });

  router.get('/api/claims/history', async (ctx) => {
    const user = requireUser(ctx);
    const limit = Number(ctx.url.searchParams.get('limit') || 50);
    const offset = Number(ctx.url.searchParams.get('offset') || 0);
    const moduleFilter = ctx.url.searchParams.get('module');
    const data = await faucet.history(user.id, limit, offset);
    return {
      status: 200,
      body: moduleFilter ? { ...data, items: data.items.filter((i) => i.module === moduleFilter) } : data,
    };
  });

  /* ------------------------------------------------------------------ */
  /*  Retraits / FaucetPay                                               */
  /* ------------------------------------------------------------------ */

  router.get('/api/payouts', async (ctx) => {
    const user = requireUser(ctx);
    const history = await payouts.history(user.id);
    const provider = await payouts.getProviderStatus('BTC');
    const cfgAll = await settings.all();
    return {
      status: 200,
      body: {
        ...history,
        balance_sats: user.balance_sats,
        min_withdraw_sats: cfgAll.min_withdraw_sats,
        payout_address: user.payout_address,
        provider: {
          mode: provider.mode, live: provider.live, ok: provider.ok,
          balance_sats: provider.balance_sats ?? null, simulated: provider.simulated, error: provider.error || null,
        },
      },
    };
  });

  router.post('/api/payouts/verify-address', async (ctx) => {
    requireCsrf(ctx);
    const user = requireUser(ctx);
    await guard('verify_address', 20, 3600, ctx);
    const res = await payouts.verifyAddress(user, (ctx.body || {}).address);
    return { status: 200, body: { ok: true, ...res } };
  });

  router.post('/api/payouts/withdraw', async (ctx) => {
    requireCsrf(ctx);
    const user = requireUser(ctx);
    await guard('withdraw', 15, 3600, ctx);
    const b = ctx.body || {};
    const result = await payouts.requestWithdraw(user, {
      amountSats: b.amount_sats,
      ip: ctx.ip,
      userAgent: ctx.req.headers['user-agent'],
      idempotencyKey: b.idempotency_key,
    });
    return {
      status: 200,
      body: {
        ok: true,
        duplicate: result.duplicate,
        payout: result.payout,
        message: result.payout.status === 'simulated'
          ? 'Retrait simulé avec succès (aucun argent réel envoyé).'
          : 'Paiement envoyé à FaucetPay.',
        new_balance_sats: (await auth.getUserById(user.id)).balance_sats,
      },
    };
  });

  /* ------------------------------------------------------------------ */
  /*  Parrainage                                                         */
  /* ------------------------------------------------------------------ */

  router.get('/api/referral', async (ctx) => {
    const user = requireUser(ctx);
    const summary = await referral.summary(user, originOf(ctx));
    const referred = await referral.listReferred(user.id);
    const commissions = await referral.commissions(user.id);
    return { status: 200, body: { ...summary, referred, commissions } };
  });

  /* ------------------------------------------------------------------ */
  /*  SHORTLINKS (Étape 4)                                               */
  /* ------------------------------------------------------------------ */

  router.get('/api/shortlinks', async (ctx) => {
    const user = requireUser(ctx);
    return { status: 200, body: await shortlinks.listForUser(user) };
  });

  router.post('/api/shortlinks/:id/start', async (ctx) => {
    requireCsrf(ctx);
    const user = requireUser(ctx);
    await guard('shortlink_start', 60, 3600, ctx);
    const res = await shortlinks.start(user, Number(ctx.params.id), { origin: originOf(ctx) });
    return { status: 200, body: { ok: true, ...res } };
  });

  // Retour du réseau partenaire : navigation navigateur (cookie SameSite=Lax envoyé)
  router.get('/shortlink/return', async (ctx) => {
    const token = ctx.url.searchParams.get('token');
    const sig = ctx.url.searchParams.get('sig');
    if (!ctx.user) return redirect(ctx.res, `/login?next=${encodeURIComponent('/shortlinks')}`);
    try {
      const res = await shortlinks.complete({
        token, sig, user: ctx.user, ip: ctx.ip, userAgent: ctx.req.headers['user-agent'],
      });
      return redirect(ctx.res, `/shortlinks?valide=1&gain=${res.amount_sats}`);
    } catch (err) {
      const reason = encodeURIComponent(err.message);
      return redirect(ctx.res, `/shortlinks?erreur=${reason}`);
    }
  });

  /* ------------------------------------------------------------------ */
  /*  PTC (Étape 5)                                                      */
  /* ------------------------------------------------------------------ */

  router.get('/api/ptc', async (ctx) => {
    const user = requireUser(ctx);
    return { status: 200, body: await ptc.listForUser(user) };
  });

  router.post('/api/ptc/:id/start', async (ctx) => {
    requireCsrf(ctx);
    const user = requireUser(ctx);
    await guard('ptc_start', 60, 3600, ctx);
    return { status: 200, body: { ok: true, ...(await ptc.start(user, Number(ctx.params.id))) } };
  });

  router.post('/api/ptc/complete', async (ctx) => {
    requireCsrf(ctx);
    const user = requireUser(ctx);
    const b = ctx.body || {};
    return { status: 200, body: await ptc.complete(user, { token: b.token, visible_seconds: b.visible_seconds }) };
  });

  /* ------------------------------------------------------------------ */
  /*  OFFERWALLS (Étape 6)                                               */
  /* ------------------------------------------------------------------ */

  router.get('/api/offerwalls', async (ctx) => {
    const user = requireUser(ctx);
    return { status: 200, body: await offerwalls.listForUser(user, originOf(ctx)) };
  });

  // Postback serveur-à-serveur du partenaire (aucune session requise : signature HMAC)
  router.add('GET', '/api/offerwalls/:id/callback', async (ctx) => {
    await guard('offerwall_cb', 600, 3600, ctx);
    const q = Object.fromEntries(ctx.url.searchParams.entries());
    const res = await offerwalls.handleCallback(Number(ctx.params.id), q);
    return { status: 200, body: res };
  });
  router.add('POST', '/api/offerwalls/:id/callback', async (ctx) => {
    await guard('offerwall_cb', 600, 3600, ctx);
    const q = { ...Object.fromEntries(ctx.url.searchParams.entries()), ...(ctx.body || {}) };
    const res = await offerwalls.handleCallback(Number(ctx.params.id), q);
    return { status: 200, body: res };
  });

  /* ------------------------------------------------------------------ */
  /*  Administration                                                     */
  /* ------------------------------------------------------------------ */

  router.get('/api/admin/overview', async (ctx) => {
    requireAdmin(ctx);
    const [statsDay, statsWeek, fa, allSettings] = await Promise.all([
      faucet.stats('day'), faucet.stats('week'), finance.overview(), settings.all(),
    ]);
    const provider = await payouts.getProviderStatus('BTC');
    const counts = await db.get(`SELECT
        (SELECT COUNT(*) FROM users) AS users,
        (SELECT COUNT(*) FROM users WHERE status = 'active') AS active_users,
        (SELECT COUNT(*) FROM users WHERE status = 'suspended') AS suspended_users,
        (SELECT COUNT(*) FROM payouts WHERE status IN ('sent','simulated')) AS payouts_done,
        (SELECT COUNT(*) FROM payouts WHERE status = 'failed') AS payouts_failed,
        (SELECT COALESCE(SUM(balance_sats),0) FROM users) AS liability_sats`);
    return {
      status: 200,
      body: { stats: { day: statsDay, week: statsWeek }, finance: fa, provider, counts, settings: allSettings },
    };
  });

  router.get('/api/admin/settings', async (ctx) => {
    requireAdmin(ctx);
    return { status: 200, body: await settings.all() };
  });

  router.post('/api/admin/settings', async (ctx) => {
    requireCsrf(ctx);
    const admin = requireAdmin(ctx);
    const patch = {};
    for (const [k, v] of Object.entries(ctx.body || {})) {
      if (v === '' || v === null) continue;
      patch[k] = typeof v === 'string' && /^-?\d+(\.\d+)?$/.test(v) ? Number(v) : v;
    }
    // Garde-fous de validation
    if (patch.faucet_reward_sats !== undefined) {
      patch.faucet_reward_sats = Math.max(1, Math.min(100000, Math.round(Number(patch.faucet_reward_sats))));
    }
    if (patch.faucet_cooldown_seconds !== undefined) {
      patch.faucet_cooldown_seconds = Math.max(30, Math.min(86400, Math.round(Number(patch.faucet_cooldown_seconds))));
    }
    if (patch.faucet_daily_limit !== undefined) {
      patch.faucet_daily_limit = Math.max(1, Math.min(1000, Math.round(Number(patch.faucet_daily_limit))));
    }
    if (patch.referral_percent !== undefined) {
      patch.referral_percent = Math.max(0, Math.min(50, Math.round(Number(patch.referral_percent))));
    }
    if (patch.min_withdraw_sats !== undefined) {
      patch.min_withdraw_sats = Math.max(1, Math.round(Number(patch.min_withdraw_sats)));
    }
    const applied = await settings.bulkSet(patch);
    await db.run(
      `INSERT INTO audit_log (actor_id, action, target, meta, ip) VALUES (?, 'settings_update', 'settings', ?, ?)`,
      [admin.id, JSON.stringify(applied), ctx.ip]
    );
    return { status: 200, body: { ok: true, applied, settings: await settings.all() } };
  });

  router.post('/api/admin/users/:id/:action', async (ctx) => {
    requireCsrf(ctx);
    const admin = requireAdmin(ctx);
    const userId = Number(ctx.params.id);
    const action = ctx.params.action;
    const target = await db.get('SELECT * FROM users WHERE id = ?', [userId]);
    if (!target) throw new HttpError('Membre introuvable.', 404, 'not_found');
    if (target.role === 'admin' && action !== 'note') throw new HttpError('Impossible de modifier un administrateur.', 403, 'protected');

    if (action === 'suspend') await db.run(`UPDATE users SET status = 'suspended' WHERE id = ?`, [userId]);
    else if (action === 'ban') await db.run(`UPDATE users SET status = 'banned' WHERE id = ?`, [userId]);
    else if (action === 'activate') await db.run(`UPDATE users SET status = 'active', risk_score = 0 WHERE id = ?`, [userId]);
    else if (action === 'reset-risk') await db.run(`UPDATE users SET risk_score = 0 WHERE id = ?`, [userId]);
    else if (action === 'logout-all') await auth.destroyAllSessions(userId);
    else if (action === 'adjust-balance') {
      const delta = Math.round(Number((ctx.body || {}).delta_sats));
      if (!Number.isFinite(delta) || delta === 0) throw new HttpError('delta_sats invalide.', 422, 'bad_delta');
      await db.atomic((tx) => {
        tx.run(`UPDATE users SET balance_sats = MAX(0, balance_sats + ?), updated_at = datetime('now') WHERE id = ?`, [delta, userId]);
        tx.run(
          `INSERT INTO ledger (user_id, type, module, amount_sats, meta) VALUES (?, ?, 'admin', ?, ?)`,
          [userId, delta > 0 ? 'credit_reward' : 'debit_payout', delta, JSON.stringify({ by: admin.id, reason: (ctx.body || {}).reason || null })]
        );
      });
    } else {
      throw new HttpError('Action inconnue.', 400, 'unknown_action');
    }

    await db.run(
      `INSERT INTO audit_log (actor_id, action, target, meta, ip) VALUES (?, ?, ?, ?, ?)`,
      [admin.id, `user_${action}`, String(userId), JSON.stringify(ctx.body || {}), ctx.ip]
    );
    const updated = await db.get('SELECT id, username, status, role, risk_score, balance_sats FROM users WHERE id = ?', [userId]);
    return { status: 200, body: { ok: true, user: updated } };
  });

  router.get('/api/admin/users', async (ctx) => {
    requireAdmin(ctx);
    const q = (ctx.url.searchParams.get('q') || '').trim();
    const status = ctx.url.searchParams.get('status');
    const params = [];
    const where = [];
    if (q) { where.push('(username LIKE ? OR email LIKE ?)'); params.push(`%${q}%`, `%${q}%`); }
    if (status) { where.push('status = ?'); params.push(status); }
    params.push(Math.min(500, Number(ctx.url.searchParams.get('limit') || 100)));
    const rows = await db.all(
      `SELECT id, username, email, payout_address, balance_sats, total_earned_sats, total_paid_sats,
              referral_code, referred_by, role, status, risk_score, signup_ip, last_ip, created_at, last_login_at
       FROM users ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY id DESC LIMIT ?`, params
    );
    return { status: 200, body: { items: rows, count: rows.length } };
  });

  router.get('/api/admin/payouts', async (ctx) => {
    requireAdmin(ctx);
    const items = await payouts.adminList({
      limit: Number(ctx.url.searchParams.get('limit') || 100),
      status: ctx.url.searchParams.get('status'),
    });
    return { status: 200, body: { items } };
  });

  router.post('/api/admin/payouts/:id/:action', async (ctx) => {
    requireCsrf(ctx);
    const admin = requireAdmin(ctx);
    const id = Number(ctx.params.id);
    const action = ctx.params.action;
    const p = await db.get('SELECT * FROM payouts WHERE id = ?', [id]);
    if (!p) throw new HttpError('Paiement introuvable.', 404, 'not_found');

    if (action === 'retry') {
      if (!['failed', 'pending'].includes(p.status)) throw new HttpError('Ce paiement ne peut pas être relancé.', 409, 'bad_state');
      const res = await payouts.executePayout(id, { ip: ctx.ip });
      return { status: 200, body: { ok: true, payout: res.payout } };
    }
    if (action === 'mark-sent') {
      await db.run(`UPDATE payouts SET status = 'sent', provider_message = 'Marqué payé manuellement par admin', updated_at = datetime('now') WHERE id = ?`, [id]);
      await db.run(`UPDATE users SET total_paid_sats = total_paid_sats + ? WHERE id = ?`, [p.amount_sats, p.user_id]);
    } else if (action === 'cancel-refund') {
      if (['sent', 'simulated'].includes(p.status)) throw new HttpError('Paiement déjà traité.', 409, 'bad_state');
      await db.atomic((tx) => {
        tx.run(`UPDATE payouts SET status = 'cancelled', updated_at = datetime('now') WHERE id = ?`, [id]);
        tx.run(`UPDATE users SET balance_sats = balance_sats + ? WHERE id = ?`, [p.amount_sats, p.user_id]);
        tx.run(
          `INSERT INTO ledger (user_id, type, module, amount_sats, meta) VALUES (?, 'refund', 'withdraw', ?, ?)`,
          [p.user_id, p.amount_sats, JSON.stringify({ payout_id: id, by_admin: admin.id })]
        );
      });
    } else {
      throw new HttpError('Action inconnue.', 400, 'unknown_action');
    }
    await db.run(
      `INSERT INTO audit_log (actor_id, action, target, meta, ip) VALUES (?, ?, ?, ?, ?)`,
      [admin.id, `payout_${action}`, String(id), null, ctx.ip]
    );
    return { status: 200, body: { ok: true } };
  });

  router.get('/api/admin/finance', async (ctx) => {
    requireAdmin(ctx);
    const [overview, entries] = await Promise.all([finance.overview(), finance.listEntries(200)]);
    const cfgAll = await settings.all();
    return { status: 200, body: { overview, entries, rates: { btc_usd: cfgAll.btc_usd, usd_per_1000_points: cfgAll.usd_per_1000_points } } };
  });

  router.post('/api/admin/finance/entry', async (ctx) => {
    requireCsrf(ctx);
    const admin = requireAdmin(ctx);
    const b = ctx.body || {};
    await finance.addEntry({ kind: b.kind, category: b.category, amount_usd: b.amount_usd, note: b.note, entry_date: b.entry_date });
    await db.run(`INSERT INTO audit_log (actor_id, action, meta, ip) VALUES (?, 'finance_entry', ?, ?)`, [admin.id, JSON.stringify(b), ctx.ip]);
    return { status: 200, body: { ok: true, overview: await finance.overview() } };
  });

  router.post('/api/admin/finance/simulate', async (ctx) => {
    requireAdmin(ctx);
    const b = ctx.body || {};
    return {
      status: 200,
      body: await finance.simulate({
        users: b.users, claims_per_user: b.claims_per_user, reward_sats: b.reward_sats,
        revenue_per_1000_points: b.revenue_per_1000_points, hosting_usd_month: b.hosting_usd_month,
      }),
    };
  });

  router.post('/api/admin/modules/:name/:state', async (ctx) => {
    requireCsrf(ctx);
    const admin = requireAdmin(ctx);
    const state = ctx.params.state === 'on';
    const modules = await settings.setModule(ctx.params.name, state);
    await db.run(
      `INSERT INTO audit_log (actor_id, action, target, meta, ip) VALUES (?, 'module_toggle', ?, ?, ?)`,
      [admin.id, ctx.params.name, JSON.stringify({ enabled: state }), ctx.ip]
    );
    return { status: 200, body: { ok: true, modules } };
  });

  router.get('/api/admin/audit', async (ctx) => {
    requireAdmin(ctx);
    const rows = await db.all(
      `SELECT a.*, u.username FROM audit_log a LEFT JOIN users u ON u.id = a.actor_id ORDER BY a.id DESC LIMIT ?`,
      [Math.min(300, Number(ctx.url.searchParams.get('limit') || 100))]
    );
    return { status: 200, body: { items: rows } };
  });

  router.get('/api/admin/partners', async (ctx) => {
    requireAdmin(ctx);
    const rows = await db.all('SELECT * FROM partners ORDER BY id DESC');
    return { status: 200, body: { items: rows } };
  });

  /* --- Shortlinks : partenaires, liens, statistiques --- */

  router.get('/api/admin/shortlinks', async (ctx) => {
    requireAdmin(ctx);
    return { status: 200, body: await shortlinks.adminList() };
  });

  router.post('/api/admin/partners', async (ctx) => {
    requireCsrf(ctx);
    const admin = requireAdmin(ctx);
    const b = ctx.body || {};
    const res = await shortlinks.createPartner({
      name: b.name, type: b.type, networkUrl: b.network_url, callbackSecret: b.callback_secret,
      cpmUsd: b.cpm_usd, revenueShare: b.revenue_share, notes: b.notes,
    });
    await db.run(`INSERT INTO audit_log (actor_id, action, target, meta, ip) VALUES (?, 'partner_create', ?, ?, ?)`,
      [admin.id, String(res.id), JSON.stringify({ name: b.name, type: b.type }), ctx.ip]);
    return { status: 201, body: { ok: true, ...res } };
  });

  router.post('/api/admin/shortlinks', async (ctx) => {
    requireCsrf(ctx);
    const admin = requireAdmin(ctx);
    const b = ctx.body || {};
    const res = await shortlinks.createShortlink({
      partnerId: b.partner_id ? Number(b.partner_id) : null,
      title: b.title, targetUrl: b.target_url, rewardSats: b.reward_sats, dailyLimit: b.daily_limit,
    });
    await db.run(`INSERT INTO audit_log (actor_id, action, target, meta, ip) VALUES (?, 'shortlink_create', ?, ?, ?)`,
      [admin.id, String(res.id), JSON.stringify({ title: b.title }), ctx.ip]);
    return { status: 201, body: { ok: true, ...res } };
  });

  router.post('/api/admin/shortlinks/:kind/:id/:status', async (ctx) => {
    requireCsrf(ctx);
    const admin = requireAdmin(ctx);
    await shortlinks.setStatus(ctx.params.kind, Number(ctx.params.id), ctx.params.status);
    await db.run(`INSERT INTO audit_log (actor_id, action, target, meta, ip) VALUES (?, 'shortlink_status', ?, ?, ?)`,
      [admin.id, `${ctx.params.kind}:${ctx.params.id}`, JSON.stringify({ status: ctx.params.status }), ctx.ip]);
    return { status: 200, body: { ok: true } };
  });

  /* --- PTC : campagnes --- */

  router.get('/api/admin/ptc', async (ctx) => {
    requireAdmin(ctx);
    return { status: 200, body: await ptc.adminList() };
  });

  router.post('/api/admin/ptc', async (ctx) => {
    requireCsrf(ctx);
    const admin = requireAdmin(ctx);
    const b = ctx.body || {};
    const res = await ptc.createAd({
      advertiser: b.advertiser, title: b.title, targetUrl: b.target_url, durationSec: b.duration_sec,
      rewardSats: b.reward_sats, budgetSats: b.budget_sats, dailyLimit: b.daily_limit,
    });
    await db.run(`INSERT INTO audit_log (actor_id, action, target, meta, ip) VALUES (?, 'ptc_create', ?, ?, ?)`,
      [admin.id, String(res.id), JSON.stringify({ advertiser: b.advertiser }), ctx.ip]);
    return { status: 201, body: { ok: true, ...res } };
  });

  router.post('/api/admin/ptc/:id/:action', async (ctx) => {
    requireCsrf(ctx);
    const admin = requireAdmin(ctx);
    const id = Number(ctx.params.id);
    const action = ctx.params.action;
    if (['active', 'paused', 'suspended'].includes(action)) {
      await ptc.setAdStatus(id, action);
    } else if (action === 'fund') {
      await ptc.fundAd(id, (ctx.body || {}).amount_sats, (ctx.body || {}).note);
    } else {
      throw new HttpError('Action inconnue.', 400, 'unknown_action');
    }
    await db.run(`INSERT INTO audit_log (actor_id, action, target, meta, ip) VALUES (?, ?, ?, ?, ?)`,
      [admin.id, `ptc_${action}`, String(id), JSON.stringify(ctx.body || {}), ctx.ip]);
    return { status: 200, body: { ok: true } };
  });

  /* --- Offerwalls : callbacks et statistiques --- */

  router.get('/api/admin/offerwalls', async (ctx) => {
    requireAdmin(ctx);
    return { status: 200, body: await offerwalls.adminList() };
  });

  /* ------------------------------------------------------------------ */
  /*  Gestion des requêtes                                               */
  /* ------------------------------------------------------------------ */

  async function handle(req, res) {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const ip = clientIp(req);
    const cookies = parseCookies(req);
    const token = cookies[SESSION_COOKIE] || null;

    // Sécurité HTTP de base
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');

    if (req.method === 'OPTIONS') {
      res.writeHead(204, { Allow: 'GET, POST, OPTIONS' });
      return res.end();
    }

    let session = null;
    let user = null;
    if (token) {
      const s = await auth.resolveSession(token);
      if (s) { session = s; user = s.user; }
    }

    // Pages HTML : protection serveur des zones privées
    const page = PAGES[url.pathname];
    if (page && (req.method === 'GET' || req.method === 'HEAD')) {
      if (url.pathname === '/admin' && (!user || user.role !== 'admin')) {
        return redirect(res, user ? '/dashboard?error=admin_required' : '/login?next=/admin');
      }
      const privatePages = ['/dashboard', '/faucet', '/referral', '/withdraw', '/history', '/shortlinks', '/ptc', '/offerwalls'];
      if (privatePages.includes(url.pathname) && !user) {
        return redirect(res, `/login?next=${encodeURIComponent(url.pathname)}`);
      }
      // Pages embarquées (Worker) : le contenu est fourni par options.pages.
      const embedded = options.pages && options.pages[page];
      if (embedded) {
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Cache-Control': 'no-store',
          'X-Content-Type-Options': 'nosniff',
        });
        res.end(embedded);
        return;
      }
      const ok = await serveStatic(res, PUBLIC_DIR, page);
      if (ok) return;
      return sendJson(res, 404, { error: 'Page introuvable' });
    }

    // Fichiers statiques
    if (req.method === 'GET' && (url.pathname.startsWith('/css/') || url.pathname.startsWith('/js/') || url.pathname.startsWith('/img/') || url.pathname === '/favicon.ico')) {
      const ok = await serveStatic(res, PUBLIC_DIR, url.pathname);
      if (ok) return;
      res.writeHead(404).end('Not found');
      return;
    }

    const match = router.match(req.method, url.pathname);
    if (!match) {
      if (url.pathname.startsWith('/api/')) return sendJson(res, 404, { ok: false, error: 'Route inconnue', code: 'not_found' });
      return sendJson(res, 404, { error: 'Introuvable' });
    }

    const ctx = { req, res, url, params: match.params, body: {}, session, user, token, ip };

    try {
      if (req.method === 'POST') {
        const parsed = await readBody(req);
        ctx.body = parsed.data;
      }
      const out = await match.route.handler(ctx);
      if (out && !res.writableEnded) {
        return sendJson(res, out.status || 200, out.body ?? { ok: true });
      }
    } catch (err) {
      const status = err.status || err.statusCode || 500;
      if (status >= 500) console.error('[erreur]', err && (err.stack || err.message));
      if (res.writableEnded) return;
      return sendJson(res, status, {
        ok: false,
        error: status >= 500 && !(err instanceof FaucetError) && !(err instanceof PayoutError) && !(err instanceof AuthError)
          ? 'Erreur interne du serveur.'
          : err.message,
        code: err.code || 'server_error',
        details: err.details || undefined,
      });
    }
  }

  app.handle = handle;
  app.init = async () => {
    let schema = options.schemaSql;
    if (!schema) {
      const fs = require('node:fs');
      schema = fs.readFileSync(path.join(cfg.root || config.root, 'db', 'schema.sql'), 'utf8');
    }
    await db.exec(schema);
    await settings.init({
      faucet_reward_sats: cfg.defaults.faucetRewardSats,
      faucet_cooldown_seconds: cfg.defaults.faucetCooldownSeconds,
      faucet_daily_limit: cfg.defaults.faucetDailyLimit,
      shortlink_reward_sats: cfg.defaults.shortlinkRewardSats,
      ptc_reward_sats: cfg.defaults.ptcRewardSats,
      min_withdraw_sats: cfg.defaults.minWithdrawSats,
      referral_percent: cfg.defaults.referralPercent,
      points_per_sat: cfg.defaults.pointsPerSat,
    });
    return app;
  };

  return app;
}

module.exports = { createApp, PAGES };
