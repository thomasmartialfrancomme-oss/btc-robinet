# Cloudflare + FaucetPay — ce que TOI tu dois faire

Tout ce qui pouvait être automatisé l'est déjà. Il reste deux étapes qui exigent **tes comptes**
(aucune API ne permet de créer un compte à ta place).

Temps total : **≈ 25 minutes**. Coût : **0 €**.

---

## ⚡ Version courte (3 commandes)

Dans PowerShell, à la racine du projet décompressé :

```powershell
npm install
npx wrangler login
node scripts\deploy-cloudflare.mjs
```

Puis, pour ton compte admin :

```powershell
node scripts\create-admin-cloud.mjs
```

C'est fini : le script t'affiche l'adresse de ton site et vérifie 6 points de sécurité en ligne.
Les détails de chaque étape sont plus bas.

---

# PARTIE 1 — CLOUDFLARE

## 1.1 Ce qu'il faut créer

| Élément | Où | Coût | Obligatoire |
|---|---|---|---|
| Un compte Cloudflare | <https://dash.cloudflare.com/sign-up> | 0 € | oui |
| Validation de l'e-mail | boîte mail | — | oui |
| Base D1 `btc-robinet` | créée **par le script** | 0 € | oui |
| Worker `btc-robinet` | déployé **par le script** | 0 € | oui |
| Clés Turnstile (captcha) | <https://dash.cloudflare.com> → Turnstile | 0 € | recommandé |
| Nom de domaine | *facultatif* | ~10 €/an | non |

**Aucune carte bancaire n'est demandée** pour l'offre gratuite. Si Cloudflare t'en réclame une,
c'est que tu as cliqué sur une offre payante (Workers Paid) : reviens à l'offre Free.

## 1.2 Créer le compte (5 min)

1. <https://dash.cloudflare.com/sign-up>
2. E-mail + mot de passe solide → **Sign up**.
3. Ouvre le mail de Cloudflare → clique **Verify email**.
4. Note ton **Account ID** (visible dans l'URL du tableau de bord ou dans *Workers & Pages*) :
   il ne sert à rien dans ce projet, mais il identifie ton compte si tu demandes de l'aide.

## 1.3 Se connecter en ligne de commande (2 min)

```powershell
cd C:\btc-robinet
npm install -g wrangler
npx wrangler login
```

Une page s'ouvre dans le navigateur → clique **Allow**.
Si le navigateur ne s'ouvre pas : lance `npx wrangler login` depuis un terminal normal (pas
depuis un IDE), ou copie l'URL affichée à la main.

Vérifie :

```powershell
npx wrangler whoami
```

Tu dois voir ton e-mail et la liste de tes comptes. Si « not authenticated » → refais `login`.

## 1.4 Lancer le déploiement automatique (5 min)

```powershell
node scripts\deploy-cloudflare.mjs
```

Le script fait **7 étapes** et ne saute rien :

| Étape | Ce qu'il fait | Ce que tu dois voir |
|---|---|---|
| 1 | Détecte la connexion | `✓ connecté (ton@email)` |
| 2 | Crée la base D1 (ou réutilise) | `✓ base créée : xxxxxxxx-…` |
| 3 | Écrit le `database_id` dans `wrangler.toml` | `✓ wrangler.toml à jour` |
| 4 | Crée les 18 tables dans la vraie base + migrations | `✓ 18 tables créées` |
| 5 | Demande et enregistre `SESSION_SECRET` (généré aléatoirement) | `✓ SESSION_SECRET enregistré` |
| 6 | Génère le bundle et déploie | `✓ publié : https://btc-robinet.….workers.dev` |
| 7 | Réécrit `SITE_URL`, redéploie, teste 6 points en ligne | `Déploiement vérifié` |

À l'étape 5, il te propose de générer la clé de session : **réponds O (Entrée)**.
C'est un secret de 64 caractères créé sur ton PC, envoyé chiffré à Cloudflare, jamais écrit
dans un fichier ni dans Git.

À l'étape 5 toujours, il te demande si tu as des clés **Turnstile**. Tu peux répondre **N** pour
l'instant (captcha arithmétique) et les ajouter plus tard, section 1.6.

### Si tu préfères le faire à la main

C'est possible, tout est documenté dans `docs/GUIDE-COMPLET.md` (phase 3, étapes 3.3 à 3.8).
Le script ne fait qu'enchaîner ces commandes, avec les vérifications en plus.

## 1.5 Créer ton compte administrateur (2 min)

```powershell
node scripts\create-admin-cloud.mjs
```

Il te demande : pseudo, e-mail, adresse FaucetPay, mot de passe (masqué, 10 caractères min).
Il calcule le hash **comme le fait le site** (PBKDF2-SHA256, 210 000 itérations), écrit un
fichier `.sql` temporaire, l'exécute à distance, puis **supprime le fichier**.

Puis connecte-toi sur `https://<ton-site>.workers.dev/login` avec ce pseudo et ce mot de passe :
tu arrives sur `/admin`.

> Si le pseudo existait déjà, le script le **réinitialise** et le repasse en administrateur.
> C'est la procédure à utiliser si tu perds ton mot de passe admin.

## 1.6 Activer le captcha Turnstile (5 min — recommandé avant d'ouvrir au public)

1. <https://dash.cloudflare.com> → menu **Turnstile** → **Add widget**.
2. *Widget name* : `btc-robinet`.
3. *Hostname* : ajoute celui de ton site, par exemple
   `btc-robinet.ton-sous-domaine.workers.dev`.
4. *Widget mode* : **Managed** (par défaut).
5. **Create**. Tu obtiens deux clés :
   - **Site Key** (publique, commence par `0x4AAA…`) ;
   - **Secret Key** (privée, commence par `0x4AAA…` aussi mais ne la montre à personne).
6. Enregistre-les :

```powershell
npx wrangler secret put TURNSTILE_SITE_KEY
:: colle la Site Key, Entrée
npx wrangler secret put TURNSTILE_SECRET_KEY
:: colle la Secret Key, Entrée
```

7. Passe le mode captcha à `turnstile` dans `wrangler.toml` :

```toml
CAPTCHA_MODE = "turnstile"
```

8. Redéploie : `npx wrangler deploy`.

Tant que tu restes sur `CAPTCHA_MODE = "math"`, le captcha est un simple calcul : suffisant pour
tester, trop faible pour un site public.

## 1.7 Les 6 contrôles à faire sur ton site (1 min)

| Vérification | Résultat attendu |
|---|---|
| ouvrir `/` | page d'accueil, mention « mode test » |
| ouvrir `/dashboard` sans être connecté | **redirection** vers `/login?next=/dashboard` |
| ouvrir `/admin` sans être connecté | redirection vers `/login` |
| se connecter en membre, puis `/admin` | renvoi vers `/dashboard?error=admin_required` |
| ouvrir `/api/public/config` | JSON public, **aucune clé** |
| cliquer deux fois sur CLAIM | 2ᵉ refusé (« cooldown ») |

Le script fait déjà ces six contrôles. Si `/dashboard` s'ouvre **sans** connexion, c'est que
`html_handling = "none"` a disparu de `wrangler.toml` — remets-le et redéploie.

## 1.8 Ce que tu as le droit de consommer (gratuit)

| Ressource | Offre gratuite | Ton usage pour 500 membres actifs |
|---|---|---|
| Requêtes Worker | 100 000 / jour | ≈ 2 000 |
| Écritures D1 | 100 000 / jour | ≈ 1 500 |
| Lectures D1 | 5 000 000 / jour | ≈ 20 000 |
| Stockage D1 | 5 Go | quelques Mo |
| Turnstile | gratuit | — |

**Vérifie ces chiffres le jour du déploiement** : Cloudflare les fait évoluer. Au-delà, l'offre
Workers payante (~5 $/mois) suffit très largement.

## 1.9 Sauvegarde (à faire chaque semaine)

```powershell
npx wrangler d1 export btc-robinet --remote --output=sauvegarde-2026-11-12.sql
```

Garde ce fichier **hors de Git** : il contient les e-mails et les adresses de paiement.

---

# PARTIE 2 — FAUCETPAY

> ⚠️ Le site est livré avec `PAYOUTS_LIVE = "false"` : **aucun satoshi ne sort** tant que tu ne
> l'ouvres pas explicitement. Tu peux faire toute cette partie sans risque.

## 2.1 Ce qu'il faut créer

| Élément | Où | Coût | Obligatoire |
|---|---|---|---|
| Un compte FaucetPay | <https://faucetpay.io> | 0 € | oui |
| Un **compte faucet** (Faucet owner) | dashboard FaucetPay | 0 € | oui |
| Une clé API | *Manage* → *API & Webhooks* | 0 € | oui |
| Un approvisionnement du faucet | dépôt BTC | selon ton budget | oui, pour payer |
| Le mode API v2 (clés scoped) | même page | 0 € | recommandé |

## 2.2 Créer le compte faucet (10 min)

1. <https://faucetpay.io> → **Register** (e-mail + mot de passe, puis validation par e-mail).
2. Dans le tableau de bord, ouvre **Faucet owner** / **My faucets** → **Create faucet**.
3. Renseigne le nom (`BTC ROBINET`), la devise (**BTC**) et l'URL de ton site.

## 2.3 Générer la clé API

1. Faucet owner dashboard → **Manage** → **API & Webhooks**.
2. **API v2 (recommandé)** : crée deux clés *scoped* :
   - une avec le scope **read** (lecture : solde, vérification d'adresse, historique) ;
   - une avec le scope **send** (envoi de paiements).
   Copie-les immédiatement : elles ne sont plus affichées ensuite.
3. **API v1 (si tu préfères)** : une seule clé API. Attention, `/send` en v1 exige que l'IP
   appelante soit **whitelistée**. Sur Cloudflare, les IP de sortie changent : c'est la raison
   pour laquelle **v2 est recommandé** ici. Si tu restes en v1 et obtiens `401 IP not
   whitelisted`, passe en v2.

## 2.4 Tester la connexion AVANT d'ouvrir les paiements (2 min)

Le projet contient un script **de lecture seule** : il n'appelle jamais `/send`, il est donc
impossible qu'il déplace un satoshi.

```powershell
:: API v2
$env:FAUCETPAY_API_VERSION="v2"
$env:FAUCETPAY_V2_READ_KEY="ta_cle_read"
$env:FAUCETPAY_TEST_ADDRESS="tonpseudo@faucetpay.io"
node scripts\test-faucetpay.mjs
```

ou en v1 :

```powershell
$env:FAUCETPAY_API_VERSION="v1"
$env:FAUCETPAY_API_KEY="ta_cle_v1"
node scripts\test-faucetpay.mjs
```

Il vérifie : la clé, le **solde du faucet**, une **adresse de destinataire**, l'historique, et
affiche une **empreinte** de la clé (pour comparer avec celle enregistrée sur Cloudflare sans
jamais l'exposer).

Sortie attendue :

```
→ 2. Solde du faucet (c'est ce solde qui paie les membres)
   ✓ clé acceptée, solde lu — 12500 sats
→ 3. Vérification d'une adresse de destinataire
   ✓ adresse valide — hash 8f3c1a…
Résumé
   La clé fonctionne en lecture.
```

Sans clé, tu peux aussi le lancer et la coller à l'invite (elle ne s'affiche pas et n'est pas
enregistrée).

## 2.5 Enregistrer la clé sur Cloudflare

```powershell
:: API v2
npx wrangler secret put FAUCETPAY_V2_READ_KEY
npx wrangler secret put FAUCETPAY_V2_SEND_KEY

:: ou API v1
npx wrangler secret put FAUCETPAY_API_KEY
```

Puis dans `wrangler.toml` :

```toml
FAUCETPAY_MODE = "faucetpay"
FAUCETPAY_API_VERSION = "v2"      # ou "v1"
PAYOUTS_LIVE = "false"            # ⚠️ NE PAS TOUCHER pour l'instant
```

Et redéploie : `npx wrangler deploy`.

## 2.6 Approvisionner le faucet

Les paiements partent du **solde du faucet**, pas de ton solde personnel.

1. FaucetPay → **Deposit** → BTC. Tu obtiens une adresse de dépôt.
2. Envoie le montant que tu acceptes de distribuer (commence petit : l'équivalent de 5 à 10 €).
3. Vérifie avec `node scripts\test-faucetpay.mjs` : le solde doit apparaître.

Sans ce solde, chaque retrait sera refusé proprement avec `402 insufficient faucet balance` —
le site ne paiera **jamais** au-delà de ce qu'il possède.

## 2.7 Le test payant encadré (obligatoire, avant d'ouvrir au public)

C'est **le seul moment où de l'argent réel circule**. Fais-le calmement, dans cet ordre :

1. **Baisse le minimum de retrait à 50 sats** : `/admin` → *Réglages* → *Retrait minimum* → 50.
2. Crée un **compte de test** sur ton site et réclame jusqu'à 50 sats.
3. Vérifie son adresse FaucetPay (bouton de vérification sur `/withdraw`).
4. Ouvre le verrou dans `wrangler.toml` :
   ```toml
   PAYOUTS_LIVE = "true"
   ```
   puis `npx wrangler deploy`.
5. Demande **un seul** retrait de 50 sats avec le compte de test.
6. Vérifie les 4 points suivants :
   - [ ] le solde du membre baisse du montant **+ frais** ;
   - [ ] le paiement apparaît dans l'historique FaucetPay ;
   - [ ] **rejoue la même demande** : aucun second débit (clé d'idempotence) ;
   - [ ] vide volontairement le solde du faucet et retente : refus propre, **jamais** de solde
         négatif.
7. Remets le minimum de retrait à sa valeur réelle (ex. 500 sats).
8. Laisse `PAYOUTS_LIVE = "true"` : le site est ouvert aux paiements.

**Si un point échoue** : remets `PAYOUTS_LIVE = "false"`, redéploie, et envoie-moi le message
d'erreur exact (jamais ta clé) — je corrige.

## 2.8 Les erreurs FaucetPay et ce que le site en fait

| Code | Signification | Comportement déjà codé |
|---|---|---|
| 401 | IP non autorisée / compte suspendu | erreur claire, aucun débit conservé |
| 402 | solde faucet insuffisant | retrait refusé, solde du membre intact |
| 403 | clé API invalide | erreur de configuration signalée |
| 405 | montant invalide | refusé avant l'appel |
| 410 | devise invalide | refusé avant l'appel |
| 450 / 456 / 457 | limite atteinte / destinataire refusé | message explicite au membre |
| 459 | trop de requêtes | réessai ultérieur, jamais de doublon |

---

# Ce qu'il ne faut JAMAIS faire

1. Mettre une clé API, un mot de passe ou un token dans Git, dans un fichier `.txt` ou dans ce
   chat.
2. Passer `PAYOUTS_LIVE = "true"` avant le test à 50 sats de la section 2.7.
3. Retirer `html_handling = "none"` de `wrangler.toml` → les pages privées s'ouvriraient sans
   connexion.
4. Payer un membre quand le solde du faucet est insuffisant : le code refuse déjà, ne
   contourne pas ce refus.
5. Mettre une clé dans `public/` : tout le code du navigateur est public.

---

# Récapitulatif de tes actions

| # | Action | Où | Temps |
|---|---|---|---|
| 1 | Créer un compte Cloudflare + valider l'e-mail | dash.cloudflare.com | 5 min |
| 2 | `npx wrangler login` | terminal | 2 min |
| 3 | `node scripts\deploy-cloudflare.mjs` | terminal | 5 min |
| 4 | `node scripts\create-admin-cloud.mjs` | terminal | 2 min |
| 5 | (recommandé) clés Turnstile | dash.cloudflare.com → Turnstile | 5 min |
| 6 | Créer le compte faucet FaucetPay | faucetpay.io | 10 min |
| 7 | Générer la clé API v2 (read + send) | dashboard faucet | 2 min |
| 8 | `node scripts\test-faucetpay.mjs` | terminal | 2 min |
| 9 | `wrangler secret put …` + redéployer | terminal | 3 min |
| 10 | Approvisionner le faucet | FaucetPay → Deposit | 5 min |
| 11 | Test encadré à 50 sats puis `PAYOUTS_LIVE=true` | `/admin` + terminal | 10 min |

Blocages les plus fréquents et leur solution : voir `docs/GUIDE-COMPLET.md`, annexe B.
