/**
 * Test de fumée du CHEMIN CLOUDFLARE WORKERS.
 *
 * Vérifie que le code applicatif fonctionne à l'identique lorsque :
 *   - l'entrée est une requête Web (Request) et non node:http ;
 *   - la base est un adaptateur D1 (simulé ici par SQLite) et non better-sqlite3 ;
 *   - la configuration vient des variables d'environnement du Worker.
 *
 * Lancement : npm run test:worker
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

import { D1Simulator } from './d1-simulator.mjs';

const require = createRequire(import.meta.url);
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const { buildConfig } = require('../src/lib/config.js');
const { D1Adapter } = require('../src/lib/d1.js');
const { createApp } = require('../src/app.js');
const { handleToResponse } = require('../src/lib/httpshim.js');

const schemaSql = fs.readFileSync(path.join(ROOT, 'db', 'schema.sql'), 'utf8');

let passed = 0;
let failed = 0;
const workerResults = [];
const check = (name, ok, info = '') => {
  workerResults.push({ name, ok, info: String(info || ''), section: 'Worker + D1 (chemin Cloudflare)' });
  if (ok) { passed++; console.log(`  \x1b[32m✔\x1b[0m ${name}`); }
  else { failed++; console.log(`  \x1b[31m✘\x1b[0m ${name} ${info || ''}`); }
};

const env = {
  SESSION_SECRET: 'worker-test-secret-'.padEnd(48, 'x'),
  SITE_URL: 'https://btc-robinet.example.workers.dev',
  COOKIE_SECURE: 'true',
  CAPTCHA_MODE: 'math',
  FAUCETPAY_MODE: 'mock',
  PAYOUTS_LIVE: 'false',
  FAUCETPAY_API_VERSION: 'v1',
  FAUCET_COOLDOWN_SECONDS: '30',
  FAUCET_DAILY_LIMIT: '3',
  MIN_WITHDRAW_SATS: '50',
  NODE_ENV: 'production',
};

const d1 = new D1Simulator(':memory:');
const config = buildConfig(env);
const app = createApp({ config, db: new D1Adapter(d1), schemaSql });
await app.init();

/* ------------------------- client HTTP simulé ------------------------- */
let cookieJar = {};
const BASE = 'https://btc-robinet.example.workers.dev';

async function call(method, urlPath, body, headers = {}) {
  const headersObj = { ...headers };
  const cookie = Object.entries(cookieJar).map(([k, v]) => `${k}=${v}`).join('; ');
  if (cookie) headersObj.Cookie = cookie;
  let payload;
  if (body !== undefined) {
    headersObj['Content-Type'] = 'application/json';
    payload = JSON.stringify(body);
  }
  const request = new Request(BASE + urlPath, { method, headers: headersObj, body: payload });
  const response = await handleToResponse(request, app);
  // Récupération des cookies : getSetCookie() si disponible, sinon en-tête combiné
  let setCookie = response.headers.getSetCookie ? response.headers.getSetCookie() : [];
  if (!setCookie.length) {
    const combined = response.headers.get('set-cookie');
    if (combined) setCookie = combined.split(/,(?=\s*[^;=]+=)/);
  }
  for (const c of setCookie) {
    const [pair] = c.split(';');
    const i = pair.indexOf('=');
    cookieJar[pair.slice(0, i).trim()] = pair.slice(i + 1).trim();
  }
  const text = await response.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* HTML */ }
  return { status: response.status, json, text, headers: response.headers };
}

async function captcha() {
  const c = await call('GET', '/api/auth/captcha');
  const m = /(\d+)\s*([+×])\s*(\d+)/.exec(c.json.question);
  return {
    captcha_challenge: c.json.challenge,
    captcha_signature: c.json.signature,
    captcha_answer: m[2] === '+' ? Number(m[1]) + Number(m[3]) : Number(m[1]) * Number(m[3]),
  };
}

console.log('\n\x1b[1mWorker + D1 (adaptateur et shim HTTP)\x1b[0m');

/* 1. Santé générale */
const health = await call('GET', '/api/public/config');
check('Configuration publique servie par le Worker', health.status === 200 && health.json.site_name === 'BTC ROBINET');
check('Aucun secret exposé', !JSON.stringify(health.json).toLowerCase().includes('api_key'));

/* 2. Inscription */
const reg = await call('POST', '/api/auth/register', {
  username: 'worker_user', email: 'worker@example.com', password: 'MotDePasse123',
  payout_address: 'worker@faucetpay.io', ...(await captcha()),
});
check('Inscription via Worker (PBKDF2 Web Crypto)', reg.status === 201, JSON.stringify(reg.json).slice(0, 140));
const csrf = reg.json.csrf;
check('Cookie de session émis avec Secure', (cookieJar.btr_session || '').length > 20);

/* 3. Réclamation */
const claim = await call('POST', '/api/faucet/claim', { nonce: 'w-1', ...(await captcha()) }, { 'X-CSRF-Token': csrf });
check('Réclamation créditée (INSERT conditionnel + index unique)', claim.status === 200 && claim.json.amount_sats >= 25, JSON.stringify(claim.json).slice(0, 160));
check('Solde mis à jour', claim.json.balance_sats === claim.json.amount_sats);

/* 4. Anti-double : 6 requêtes simultanées (course) */
const caps = await Promise.all(Array.from({ length: 6 }, () => captcha()));
const racing = await Promise.all(caps.map((c, i) =>
  call('POST', '/api/faucet/claim', { nonce: `w-race-${i}`, ...c }, { 'X-CSRF-Token': csrf })
));
const successes = racing.filter((r) => r.status === 200).length;
const claimCount = await d1.prepare('SELECT COUNT(*) AS n FROM claims').first();
check('6 réclamations simultanées → 1 seul crédit (index unique claim_slot)', successes === 0 || successes === 1, `succès=${successes}`);
check('Une seule réclamation en base', claimCount.n === 1, `count=${claimCount.n}`);

/* 5. Retrait simulé */
await d1.prepare('UPDATE users SET balance_sats = 400 WHERE username = ?').bind('worker_user').run();
const withdraw = await call('POST', '/api/payouts/withdraw', { amount_sats: 100, idempotency_key: 'w-idem-1' }, { 'X-CSRF-Token': csrf });
check('Retrait simulé via Worker', withdraw.status === 200 && withdraw.json.payout.status === 'simulated', JSON.stringify(withdraw.json).slice(0, 160));
const again = await call('POST', '/api/payouts/withdraw', { amount_sats: 100, idempotency_key: 'w-idem-1' }, { 'X-CSRF-Token': csrf });
const bal = await d1.prepare('SELECT balance_sats FROM users WHERE username = ?').bind('worker_user').first();
check('Rejeu de la clé d\'idempotence : aucun second débit', bal.balance_sats === 300, `solde=${bal.balance_sats}`);

/* 6. Shortlink (validation signée, délai minimal) */
await d1.prepare(`INSERT INTO partners (name, type, network_url, cpm_usd, revenue_share) VALUES ('Demo', 'shortlink', '', 2, 60)`).run();
await d1.prepare(`INSERT INTO shortlinks (partner_id, title, target_url, reward_sats, daily_limit) VALUES (1, 'Demo', '', 10, 5)`).run();
await d1.prepare(`INSERT INTO settings (key, value) VALUES ('modules', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`)
  .bind(JSON.stringify({ faucet: true, shortlinks: true, ptc: false, offerwalls: false, referral: true })).run();
const slStart = await call('POST', '/api/shortlinks/1/start', {}, { 'X-CSRF-Token': csrf });
check('Démarrage shortlink via Worker', slStart.status === 200 && slStart.json.redirect_url.includes('/shortlink/return'));
const returnPath = new URL(slStart.json.redirect_url).pathname + new URL(slStart.json.redirect_url).search;
const tooEarly = await call('GET', returnPath);
check('Retour immédiat refusé (délai minimal)', /erreur=/.test(tooEarly.headers.get('location') || ''));

/* 7. Page privée protégée par le Worker */
cookieJar = {};
const privatePage = await call('GET', '/dashboard');
check('Page privée sans session → redirection', privatePage.status === 302);

/* 8. Correctifs issus des tests dans le VRAI runtime Cloudflare (workerd) */
const { splitSqlStatements } = require('../src/lib/d1.js');

// 8a. Découpage du schéma : D1 n'accepte qu'une instruction par appel et coupe
//     sur les retours à la ligne. Le découpage doit produire des instructions
//     complètes, y compris pour les CREATE TABLE multilignes.
const statements = splitSqlStatements(schemaSql);
check('Schéma découpé en instructions complètes', statements.length > 20, `${statements.length} instructions`);
check('CREATE TABLE complet (pas tronqué à la 1re ligne)',
  statements.some((s) => /CREATE TABLE IF NOT EXISTS users \(/i.test(s) && /\)\s*$/m.test(s)));
check('Aucune instruction vide ou commentaire seul', statements.every((s) => s.length > 5 && !s.startsWith('--')));
check('Points-virgules internes préservés (chaînes)', statements.every((s) => (s.match(/'/g) || []).length % 2 === 0));

// 8b. Configuration chargeable SANS fs / path / __dirname (runtime Workers).
const VMO_MODULE = require('node:module');
const originalLoad = VMO_MODULE._load;
let configWithoutFs;
try {
  VMO_MODULE._load = function (request, parent, isMain) {
    if (request === 'node:fs' || request === 'node:path') throw new Error('module indisponible (simulation Workers)');
    return originalLoad.call(this, request, parent, isMain);
  };
  delete require.cache[require.resolve('../src/lib/config.js')];
  configWithoutFs = require('../src/lib/config.js');
  check('config.js charge sans fs/path (Worker)', typeof configWithoutFs.buildConfig === 'function');
  const cfg = configWithoutFs.buildConfig({ SESSION_SECRET: 'x'.repeat(40), SITE_NAME: 'Test' });
  check('Configuration Worker construite sans disque', cfg.runtime === 'worker' && cfg.dbPath === '');
} finally {
  VMO_MODULE._load = originalLoad;
  delete require.cache[require.resolve('../src/lib/config.js')];
}

// 8c. Pages embarquées servies par l'application (pas de disque en Worker).
const embeddedApp = createApp({
  config: buildConfig({ ...env, CAPTCHA_MODE: 'off' }),
  db: new D1Adapter(new D1Simulator(':memory:')),
  schemaSql,
  publicDir: '',
  pages: { 'index.html': '<!DOCTYPE html><title>Embarquée</title>', 'login.html': '<!DOCTYPE html><title>Connexion</title>' },
});
await embeddedApp.init();
const embeddedPage = await handleToResponse(new Request(BASE + '/'), embeddedApp);
const embeddedHtml = await embeddedPage.text();
check('Page servie depuis le bundle embarqué', embeddedPage.status === 200 && embeddedHtml.includes('Embarquée'));
check('Page privée reste protégée sans session', (await handleToResponse(new Request(BASE + '/dashboard'), embeddedApp)).status === 302);

d1.close();
console.log(`\n${'='.repeat(60)}`);
console.log(`WORKER + D1 : ${passed} réussi(s), ${failed} échec(s)`);
console.log(`${'='.repeat(60)}\n`);
fs.writeFileSync(
  path.join(ROOT, 'docs', 'TEST-REPORT-WORKER.json'),
  JSON.stringify({ generated_at: new Date().toISOString(), suite: 'worker', summary: { passed, failed }, results: workerResults }, null, 2)
);
process.exit(failed === 0 ? 0 : 1);
