/**
 * Test de bout en bout dans le VRAI runtime Cloudflare (`workerd`), avec une
 * vraie base D1 et le binaire Wrangler — le plus proche d'un déploiement réel
 * que l'on puisse faire sans compte Cloudflare.
 *
 * Ce que ce test attrape et que les simulations Node ne voient pas :
 *   - `__dirname`/`fs`/`path` indisponibles dans le runtime Workers ;
 *   - `D1Database.exec()` qui coupe l'entrée sur les retours à la ligne ;
 *   - la liaison ASSETS qui sert les pages privées en court-circuitant le Worker ;
 *   - l'absence de disque (pages HTML non servables).
 *
 * Lancement :
 *   npm run test:workerd          (installe wrangler au premier lancement)
 *
 * Le test est autonome : il copie le projet dans un dossier temporaire, crée une
 * base D1 locale, démarre `wrangler dev`, exécute le parcours puis nettoie tout.
 * Aucun compte Cloudflare, aucune requête réseau sortante vers Cloudflare.
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const { hashPassword } = require('../src/lib/security.js');

// Port aléatoire : évite tout conflit avec un autre test ou un serveur déjà lancé.
const PORT = Number(process.env.WORKERD_PORT || 8800 + Math.floor(Math.random() * 800));
const BASE = `http://127.0.0.1:${PORT}`;
const ADMIN_LOGIN = 'admin_workerd';
const ADMIN_PASSWORD = 'AdminWorkerd2026!';

let passed = 0;
let failed = 0;
const workerdResults = [];
const check = (name, ok, info = '') => {
  workerdResults.push({ name, ok, info: String(info || '') });
  if (ok) { passed++; console.log(`  \x1b[32m✔\x1b[0m ${name}${info ? ' — ' + info : ''}`); }
  else { failed++; console.log(`  \x1b[31m✘\x1b[0m ${name}${info ? ' — ' + info : ''}`); }
};
const ok = (name, okValue, info = '') => check(name, okValue, info);

/* -------------------------------------------------------------------- */
/*  Préparation de la copie de travail                                   */
/* -------------------------------------------------------------------- */

const WORK = fs.mkdtempSync(path.join(os.tmpdir(), 'workerd-e2e-'));

function run(cmd, args, opts = {}) {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, { cwd: WORK, stdio: ['ignore', 'pipe', 'pipe'], ...opts });
    let out = '';
    child.stdout.on('data', (d) => { out += d.toString(); });
    child.stderr.on('data', (d) => { out += d.toString(); });
    child.on('close', (code) => resolve({ code, out }));
  });
}

function copyProject() {
  const skip = new Set(['node_modules', '.git', 'data', '.wrangler', 'test', 'coverage']);
  fs.cpSync(ROOT, WORK, {
    recursive: true,
    filter: (src) => !skip.has(path.basename(src)),
  });
}

function prepareWranglerToml() {
  const file = path.join(WORK, 'wrangler.toml');
  let toml = fs.readFileSync(file, 'utf8');
  toml = toml.replace(/^database_id = .*$/m, 'database_id = "00000000-0000-0000-0000-000000000000"');
  // Mode local : captcha arithmétique, cookies non Secure (http://127.0.0.1).
  toml = toml.replace(/^CAPTCHA_MODE = .*$/m, 'CAPTCHA_MODE = "math"');
  toml = toml.replace(/^COOKIE_SECURE = .*$/m, 'COOKIE_SECURE = "false"');
  fs.writeFileSync(file, toml, 'utf8');
}

function waitForServer(timeoutMs = 90000) {
  const started = Date.now();
  return new Promise((resolve, reject) => {
    const tick = async () => {
      try {
        const res = await fetch(`${BASE}/api/public/config`);
        if (res.status === 200) return resolve(true);
      } catch { /* pas encore prêt */ }
      if (Date.now() - started > timeoutMs) return reject(new Error('workerd ne répond pas dans le délai imparti'));
      setTimeout(tick, 500);
    };
    tick();
  });
}

/* -------------------------------------------------------------------- */
/*  Client HTTP avec cookies                                             */
/* -------------------------------------------------------------------- */

function makeClient() {
  const jar = {};
  return {
    jar,
    async call(method, urlPath, body, headers = {}) {
      const h = { ...headers };
      const cookie = Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
      if (cookie) h.Cookie = cookie;
      let payload;
      if (body !== undefined) {
        h['Content-Type'] = 'application/json';
        payload = JSON.stringify(body);
      }
      const res = await fetch(BASE + urlPath, { method, headers: h, body: payload, redirect: 'manual' });
      const setCookies = res.headers.getSetCookie
        ? res.headers.getSetCookie()
        : (res.headers.get('set-cookie') ? [res.headers.get('set-cookie')] : []);
      for (const c of setCookies) {
        const pair = c.split(';')[0];
        const i = pair.indexOf('=');
        jar[pair.slice(0, i)] = pair.slice(i + 1);
      }
      const text = await res.text();
      let json = null;
      try { json = JSON.parse(text); } catch { /* HTML */ }
      return { status: res.status, json, text, headers: res.headers };
    },
  };
}

async function captcha(client) {
  const c = await client.call('GET', '/api/auth/captcha');
  const m = /(\d+)\s*([+×])\s*(\d+)/.exec(c.json.question);
  return {
    captcha_challenge: c.json.challenge,
    captcha_signature: c.json.signature,
    captcha_answer: m[2] === '+' ? Number(m[1]) + Number(m[3]) : Number(m[1]) * Number(m[3]),
  };
}

/* -------------------------------------------------------------------- */
/*  Parcours                                                             */
/* -------------------------------------------------------------------- */

let wrangler = null;

async function main() {
  console.log('\n\x1b[1mworkerd + D1 réelle (runtime Cloudflare)\x1b[0m');

  copyProject();
  prepareWranglerToml();

  // Dépendances du projet (better-sqlite3 non requis ici, mais install léger).
  const install = await run('npm', ['install', '--omit=dev', '--no-audit', '--no-fund']);
  if (install.code !== 0) {
    console.log('  (installation npm ignorée : ' + install.out.split('\n').slice(-2).join(' ') + ')');
  }

  const schema = await run('npx', ['--yes', 'wrangler', 'd1', 'execute', 'btc-robinet', '--local', '--file=db/schema.sql']);
  check('Schéma appliqué à une vraie base D1 (wrangler d1 execute)', schema.code === 0, schema.code === 0 ? '' : schema.out.slice(-300));

  // Compte administrateur inséré directement dans la base D1 locale.
  const hash = await hashPassword(ADMIN_PASSWORD);
  const sql = `INSERT INTO users (username, email, password_hash, payout_address, referral_code, role, status)\n` +
    `VALUES ('${ADMIN_LOGIN}', '${ADMIN_LOGIN}@example.com', '${hash}', '${ADMIN_LOGIN}@faucetpay.io', 'WRKDR01', 'admin', 'active');\n`;
  const sqlFile = path.join(WORK, 'admin.sql');
  fs.writeFileSync(sqlFile, sql, 'utf8');
  const adminInsert = await run('npx', ['--yes', 'wrangler', 'd1', 'execute', 'btc-robinet', '--local', `--file=${sqlFile}`]);
  check('Administrateur créé dans D1', adminInsert.code === 0);

  // Démarrage du Worker dans le vrai runtime.
  wrangler = spawn('npx', ['--yes', 'wrangler', 'dev', '--local', '--port', String(PORT), '--ip', '127.0.0.1'], {
    cwd: WORK,
    stdio: ['ignore', 'pipe', 'pipe'],
    detached: true, // groupe de processus dédié → arrêt propre de workerd
    env: { ...process.env, SESSION_SECRET: 'workerd-e2e-session-secret-32-chars-minimum' },
  });
  let workerLog = '';
  wrangler.stdout.on('data', (d) => { workerLog += d.toString(); });
  wrangler.stderr.on('data', (d) => { workerLog += d.toString(); });

  try {
    await waitForServer();
  } catch (err) {
    console.log('  --- journaux workerd ---');
    console.log(workerLog.split('\n').slice(-25).join('\n'));
    throw err;
  }
  check('Le Worker démarre dans workerd', true);

  /* --- 1. Pages publiques et protection des pages privées --- */
  const anon = makeClient();
  ok('Accueil servi par le Worker', (await anon.call('GET', '/')).status === 200);
  ok('Connexion accessible', (await anon.call('GET', '/login')).status === 200);
  const dash = await anon.call('GET', '/dashboard');
  ok('/dashboard redirige vers /login sans session', dash.status === 302 && /\/login/.test(dash.headers.get('location') || ''));
  const adminPage = await anon.call('GET', '/admin');
  ok('/admin protégé sans session', adminPage.status === 302);
  ok('Feuille de style servie (liaison ASSETS)', (await anon.call('GET', '/css/style.css')).status === 200);

  /* --- 2. Inscription + robinet + anti-double --- */
  const member = makeClient();
  const name = 'wk' + Date.now().toString().slice(-7);
  const reg = await member.call('POST', '/api/auth/register', {
    username: name, email: `${name}@example.com`, password: 'MotDePasse123',
    payout_address: `${name}@faucetpay.io`, ...(await captcha(member)),
  });
  ok('Inscription (PBKDF2 dans workerd)', reg.status === 201, `status ${reg.status}`);
  const csrf = reg.json.csrf;

  const claim = await member.call('POST', '/api/faucet/claim', { nonce: `n-${Date.now()}`, ...(await captcha(member)) }, { 'X-CSRF-Token': csrf });
  ok('Réclamation créditée', claim.status === 200 && claim.json.amount_sats > 0, `${claim.json.amount_sats} sats`);
  const again = await member.call('POST', '/api/faucet/claim', { nonce: `n2-${Date.now()}`, ...(await captcha(member)) }, { 'X-CSRF-Token': csrf });
  ok('Double réclamation immédiate refusée', again.status === 429, `code ${again.json.code || again.status}`);

  const me = await member.call('GET', '/api/me');
  ok('Solde crédité', me.json.user.balance_sats > 0, `${me.json.user.balance_sats} sats`);

  /* --- 3. Retraits : refus si insuffisant --- */
  const below = await member.call('POST', '/api/payouts/withdraw', { amount_sats: 1 }, { 'X-CSRF-Token': csrf });
  ok('Retrait sous le minimum refusé', below.json.ok === false);
  const tooMuch = await member.call('POST', '/api/payouts/withdraw', { amount_sats: 500 }, { 'X-CSRF-Token': csrf });
  ok('Retrait refusé si solde insuffisant', tooMuch.json.ok === false, tooMuch.json.code || '');
  const verify = await member.call('POST', '/api/payouts/verify-address', { address: 'abc@faucetpay.io' }, { 'X-CSRF-Token': csrf });
  ok('Vérification adresse FaucetPay (simulation)', verify.status === 200 && verify.json.ok !== false);

  /* --- 4. Administration --- */
  const admin = makeClient();
  const login = await admin.call('POST', '/api/auth/login', { login: ADMIN_LOGIN, password: ADMIN_PASSWORD });
  ok('Connexion administrateur sur D1', login.status === 200);
  const adminCsrf = (await admin.call('GET', '/api/me')).json.csrf;
  const overview = await admin.call('GET', '/api/admin/overview');
  ok('Tableau de bord administrateur', overview.status === 200 && !!overview.json.stats);
  const settings = await admin.call('POST', '/api/admin/settings', { faucet_reward_sats: 30 }, { 'X-CSRF-Token': adminCsrf });
  ok('Récompense modifiable par l\'admin', settings.status === 200 && settings.json.ok !== false);
  const finance = await admin.call('GET', '/api/admin/finance');
  ok('Calculateur de rentabilité', finance.status === 200);
  ok('Page /admin accessible à l\'admin', (await admin.call('GET', '/admin')).status === 200);
  ok('Page /admin refusée au membre', (await member.call('GET', '/admin')).status === 302);

  /* --- 5. Modules --- */
  for (const mod of ['shortlinks', 'ptc', 'offerwalls']) {
    const r = await member.call('GET', `/api/${mod}`);
    ok(`Module ${mod} inactif par défaut`, r.status === 200 && r.json.enabled === false);
  }
  const partner = (await admin.call('POST', '/api/admin/partners', {
    name: 'Réseau workerd', type: 'offerwall', network_url: 'https://offreur.test/wall',
    callback_secret: 'secret-workerd', revenue_share: 70,
  }, { 'X-CSRF-Token': adminCsrf })).json;
  for (const mod of ['shortlinks', 'ptc', 'offerwalls']) {
    await admin.call('POST', `/api/admin/modules/${mod}/on`, {}, { 'X-CSRF-Token': adminCsrf });
  }
  const ow = await member.call('GET', '/api/offerwalls');
  const tx = `tx-${Date.now()}`;
  const sig = crypto.createHmac('sha256', 'secret-workerd').update(`${ow.json.token}${tx}0.02`).digest('hex');
  const cb = await member.call('GET', `/api/offerwalls/${partner.id}/callback?user_id=${ow.json.token}&transaction_id=${tx}&amount=0.02&status=1&offer_name=Test&signature=${sig}`);
  ok('Callback offerwall signé crédité', cb.status === 200 && cb.json.credited_sats > 0, `${cb.json.credited_sats} sats`);
  const cb2 = await member.call('GET', `/api/offerwalls/${partner.id}/callback?user_id=${ow.json.token}&transaction_id=${tx}&amount=0.02&status=1&offer_name=Test&signature=${sig}`);
  ok('Callback rejoué : aucun second paiement', cb2.json.duplicate === true && cb2.json.credited_sats === 0);

  /* --- 6. Déconnexion --- */
  await member.call('POST', '/api/auth/logout', {}, { 'X-CSRF-Token': csrf });
  ok('Déconnexion : tableau de bord de nouveau protégé', (await member.call('GET', '/dashboard')).status === 302);

  // Aucune erreur fatale dans les journaux du runtime.
  const fatal = /__dirname is not defined|incomplete input|D1_EXEC_ERROR|Uncaught/i.test(workerLog);
  check('Aucune erreur fatale dans les journaux workerd', !fatal, fatal ? workerLog.split('\n').filter((l) => /ERROR|Uncaught/.test(l)).slice(0, 2).join(' ') : '');
}

/* -------------------------------------------------------------------- */
/*  Exécution et nettoyage                                               */
/* -------------------------------------------------------------------- */

try {
  await main();
} catch (err) {
  failed++;
  console.log(`  \x1b[31m✘\x1b[0m Erreur pendant le test : ${err && err.message}`);
} finally {
  if (wrangler) {
    // `npx` lance wrangler puis workerd : on tue tout le groupe de processus,
    // sinon workerd garde le port et le test suivant échoue.
    try { process.kill(-wrangler.pid, 'SIGTERM'); } catch { wrangler.kill('SIGTERM'); }
    await new Promise((r) => setTimeout(r, 1500));
    try { process.kill(-wrangler.pid, 'SIGKILL'); } catch { /* déjà arrêté */ }
  }
  fs.rmSync(WORK, { recursive: true, force: true });
  try {
    fs.writeFileSync(
      path.join(ROOT, 'docs', 'TEST-REPORT-WORKERD.json'),
      JSON.stringify({ generated_at: new Date().toISOString(), suite: 'workerd', runtime: 'workerd (Cloudflare) + D1 locale', summary: { passed, failed }, results: workerdResults }, null, 2)
    );
  } catch { /* le rapport n'est pas bloquant */ }
  console.log(`\n${'='.repeat(60)}`);
  console.log(`WORKERD + D1 RÉELLE : ${passed} réussi(s), ${failed} échec(s)`);
  console.log(`${'='.repeat(60)}\n`);
  process.exit(failed === 0 ? 0 : 1);
}
